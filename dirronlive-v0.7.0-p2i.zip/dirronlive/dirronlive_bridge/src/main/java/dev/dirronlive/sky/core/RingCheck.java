package dev.dirronlive.sky.core;

/**
 * Пролёт через кольцо по отрезку «прошлая позиция → текущая». На большой
 * скорости игрок за тик пролетает несколько блоков, поэтому проверка точки
 * пропустила бы кольцо — проверяем пересечение отрезка с плоскостью кольца.
 *
 * <p>Засчитывается только пролёт по направлению кольца (с задней стороны
 * на переднюю). Если отрезок начинается ровно на плоскости, это продолжение
 * прошлого пересечения — его не считаем второй раз.
 */
public final class RingCheck {
    private RingCheck() {}

    public enum Result { NONE, HIT, MISS, BACKWARD }

    /** Запас к радиусу на тело игрока в полёте. */
    public static final double BODY = 0.3;
    /** Пролёт плоскости дальше {@code radius × MISS_FACTOR} — не промах, а просто полёт мимо. */
    public static final double MISS_FACTOR = 3.0;

    public static Result cross(V3 from, V3 to, Ring ring) {
        return cross(from, to, ring, 1);
    }

    /** {@code scale} — множитель радиуса («Узкий проход» сужает кольца). */
    public static Result cross(V3 from, V3 to, Ring ring, double scale) {
        V3 c = ring.center(), n = ring.normal();
        double radius = ring.radius() * scale;
        double d0 = from.sub(c).dot(n);
        double d1 = to.sub(c).dot(n);
        boolean forward = d0 < 0 && d1 >= 0;
        boolean backward = d0 > 0 && d1 <= 0;
        if (!forward && !backward) return Result.NONE;
        double t = d0 / (d0 - d1);
        V3 x = from.lerp(to, t);
        double dist = x.sub(c).length();
        if (forward) {
            if (dist <= radius + BODY) return Result.HIT;
            return dist <= ring.radius() * MISS_FACTOR + BODY ? Result.MISS : Result.NONE;
        }
        return dist <= ring.radius() * MISS_FACTOR ? Result.BACKWARD : Result.NONE;
    }
}
