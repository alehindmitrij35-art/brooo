package dev.dirronlive.parkour.world;

import dev.dirronlive.parkour.map.Mood;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.network.packet.s2c.play.GameStateChangeS2CPacket;
import net.minecraft.network.packet.s2c.play.WorldTimeUpdateS2CPacket;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;

/**
 * Своя погода и время суток у каждого игрока второй карты (по его локации).
 * Мир остаётся ясным днём; игроку шлются только пакеты времени и погоды,
 * поэтому у двух игроков в разных локациях — разное небо.
 */
public final class Atmosphere {
    private final Map<UUID, Mood> shown = new HashMap<>();
    private final Map<UUID, Integer> rooms = new HashMap<>();
    /** После перезахода или возрождения игрок — новый объект: погоду шлём заново. */
    private final Map<UUID, ServerPlayerEntity> entities = new HashMap<>();
    private final Random random = new Random();
    /** Сколько раз игроку показали новую погоду (для проверок). */
    public int changes;

    public Mood shown(ServerPlayerEntity player) {
        return shown.get(player.getUuid());
    }

    public void forget(UUID id) {
        shown.remove(id);
        rooms.remove(id);
        entities.remove(id);
    }

    /** Каждый такт сервера, для игрока в комнате [room] второй карты. */
    public void tick(ServerWorld world, ServerPlayerEntity player, int room, int serverTicks) {
        Mood mood = Mood.forRoom(2, room);
        if (mood == null) return;
        UUID id = player.getUuid();
        if (entities.put(id, player) != player) shown.remove(id);
        Mood before = shown.get(id);
        boolean changed = before == null || !before.equals(mood);
        if (changed) {
            changes++;
            shown.put(id, mood);
            if (before == null || (before.rain() > 0) != (mood.rain() > 0)) {
                player.networkHandler.sendPacket(new GameStateChangeS2CPacket(
                        mood.rain() > 0 ? GameStateChangeS2CPacket.RAIN_STARTED : GameStateChangeS2CPacket.RAIN_STOPPED, 0f));
            }
        }
        // Сервер раз в секунду рассылает своё время — сразу после него шлём своё.
        if (changed || serverTicks % 20 == 0) {
            player.networkHandler.sendPacket(new WorldTimeUpdateS2CPacket(world.getTime(), mood.timeOfDay(), false));
        }
        if (changed || serverTicks % 100 == 0) {
            player.networkHandler.sendPacket(new GameStateChangeS2CPacket(GameStateChangeS2CPacket.RAIN_GRADIENT_CHANGED, mood.rain()));
            player.networkHandler.sendPacket(new GameStateChangeS2CPacket(GameStateChangeS2CPacket.THUNDER_GRADIENT_CHANGED, mood.thunder()));
        }
        Integer lastRoom = rooms.put(id, room);
        if (mood.lightning() && serverTicks % 20 == 7 && random.nextInt(mood.darkness() ? 6 : 10) == 0) {
            // Молния вдали — только вспышка и гром, без огня и урона.
            LightningEntity bolt = EntityType.LIGHTNING_BOLT.create(world);
            if (bolt != null) {
                double a = random.nextDouble() * Math.PI * 2, d = 28 + random.nextInt(30);
                bolt.refreshPositionAfterTeleport(player.getX() + Math.cos(a) * d, 80, player.getZ() + Math.sin(a) * d);
                bolt.setCosmetic(true);
                world.spawnEntity(bolt);
            }
        }
        if (mood.darkness()) {
            // Последняя тьма: каждые 30 секунд на 10 секунд накатывает «Тьма».
            if (serverTicks % 600 == 0 || (lastRoom != null && lastRoom != room)) {
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 200, 0, true, false, false));
            }
            // Сердцебиение и жуткие звуки за спиной.
            if (serverTicks % 40 == 0) player.playSoundToPlayer(SoundEvents.ENTITY_WARDEN_HEARTBEAT, SoundCategory.AMBIENT, 0.8f, 0.9f);
            if (serverTicks % 20 == 13 && random.nextInt(12) == 0) {
                switch (random.nextInt(4)) {
                    case 0 -> player.playSoundToPlayer(SoundEvents.ENTITY_WARDEN_NEARBY_CLOSEST, SoundCategory.AMBIENT, 0.7f, 0.8f);
                    case 1 -> player.playSoundToPlayer(SoundEvents.BLOCK_SCULK_SHRIEKER_SHRIEK, SoundCategory.AMBIENT, 0.35f, 0.7f);
                    case 2 -> player.playSoundToPlayer(SoundEvents.AMBIENT_CAVE.value(), SoundCategory.AMBIENT, 0.9f, 0.8f);
                    default -> player.playSoundToPlayer(SoundEvents.ENTITY_WARDEN_AMBIENT, SoundCategory.AMBIENT, 0.5f, 0.7f);
                }
            }
        }
    }
}
