/// 14 оверлеев для TikTok LIVE Studio / OBS. `slug` — часть постоянной
/// ссылки: http://127.0.0.1:8777/overlay/<slug>.
enum OverlayKind {
  topLikers('top-likers', 'Топ лайкеров', 'Рейтинг зрителей по личным лайкам за эфир'),
  topDonors('top-donors', 'Топ донатеров', 'Рейтинг по сумме подарков в монетах TikTok'),
  bestGift('best-gift', 'Лучший подарок', 'Самый дорогой подарок за штуку, иконка и ник'),
  bestCombo('best-combo', 'Лучшее комбо', 'Самая длинная серия: «Alex · Роза ×47»'),
  streamTime('stream-time', 'Время в эфире', 'Сколько идёт трансляция'),
  goal('goal', 'Цель трансляции', 'Шкала и остаток до цели'),
  giftMenu('gift-menu', 'Меню подарков', 'Иконки и привязки: «Роза → Толчок»'),
  parkourProgress('parkour-progress', 'Прогресс паркура', 'Комната из 100 и рекорд забега'),
  viewerAction('viewer-action', 'Действие зрителя', 'Что сделал подарок после ответа игры'),
  giftBattle('gift-battle', 'Гифт-батл', 'Два подарка, счёт и двухцветная полоса'),
  chatVote('chat-vote', 'Голосование чата', 'Зрители пишут 1 или 2'),
  challenge('challenge', 'Карточка испытания', 'Задача на эфир и её итог'),
  roomAttempts('room-attempts', 'Попытки на комнате', 'Номер комнаты и попытки'),
  skyRift('sky-rift', 'Небесный разлом', 'Сектор из 6, кольца, время, ошибки и эффекты зрителей');

  const OverlayKind(this.slug, this.title, this.description);

  final String slug;
  final String title;
  final String description;

  static OverlayKind? bySlug(String slug) {
    for (final k in values) {
      if (k.slug == slug) return k;
    }
    return null;
  }
}

/// Тип цели трансляции.
enum GoalType {
  newFollowers('newFollowers', 'Новые подписчики за эфир'),
  totalFollowers('totalFollowers', 'Всего подписчиков'),
  anyGifts('anyGifts', 'Любые подарки (штук)'),
  specificGift('specificGift', 'Конкретный подарок (штук)');

  const GoalType(this.id, this.label);

  final String id;
  final String label;

  static GoalType fromId(Object? id) {
    for (final t in values) {
      if (t.id == id) return t;
    }
    return anyGifts;
  }
}
