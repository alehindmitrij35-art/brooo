package dev.dirronlive.sky.core;

import dev.dirronlive.bridge.MiniJson;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Трасса режима «Небесный разлом» целиком: сектора с кольцами, зоны помощи,
 * площадка ожидания, финиш, тренировка и правила. Хранится в JSON рядом с
 * миром ({@code dirron_sky/track.json}), поэтому кольца можно двигать и
 * менять без пересборки мода.
 */
public final class Track {
    public enum OnMiss { ERROR, CHECKPOINT }

    public record Spot(V3 pos, float yaw) {}

    public final String id;
    public final String name;
    public final int version;
    public final List<Sector> sectors;
    public final List<Ring> rings;
    public final List<Zone> zones;
    public final Spot lobby;
    public final Spot finish;
    public final Checkpoint trainingStart;
    public final List<Ring> training;
    public final V3 min, max;
    /** Ниже этой высоты — падение, возврат на контрольную точку. */
    public final double minY;
    /** Предел скорости, блоков за тик (≈ ×20 блоков в секунду). */
    public final double speedCap;
    public final int protectionTicks;
    public final OnMiss onMiss;

    private final SpatialGrid<Zone> zoneGrid = new SpatialGrid<>();
    private final SpatialGrid<Ring> ringGrid = new SpatialGrid<>();

    public Track(String id, String name, int version, List<Sector> sectors, List<Zone> zones, Spot lobby, Spot finish,
                 Checkpoint trainingStart, List<Ring> training, V3 min, V3 max, double minY, double speedCap,
                 int protectionTicks, OnMiss onMiss) {
        this.id = id;
        this.name = name;
        this.version = version;
        this.sectors = List.copyOf(sectors);
        List<Ring> all = new ArrayList<>();
        for (Sector s : this.sectors) all.addAll(s.rings());
        this.rings = List.copyOf(all);
        this.zones = List.copyOf(zones);
        this.lobby = lobby;
        this.finish = finish == null ? lobby : finish;
        this.trainingStart = trainingStart;
        this.training = training == null ? List.of() : List.copyOf(training);
        this.min = min;
        this.max = max;
        this.minY = minY;
        this.speedCap = speedCap;
        this.protectionTicks = protectionTicks;
        this.onMiss = onMiss;
        for (Zone z : this.zones) zoneGrid.add(z.min(), z.max(), z);
        for (Ring r : this.rings) {
            V3 e = new V3(r.radius() + 1, r.radius() + 1, r.radius() + 1);
            ringGrid.add(r.center().sub(e), r.center().add(e), r);
        }
    }

    public int ringCount() {
        return rings.size();
    }

    public Sector sectorOf(Ring ring) {
        return sectors.get(ring.sector());
    }

    public boolean isLastInSector(Ring ring) {
        return sectorOf(ring).last() == ring.order();
    }

    public List<Zone> zonesAt(V3 p) {
        return zoneGrid.at(p);
    }

    public SpatialGrid<Ring> ringGrid() {
        return ringGrid;
    }

    public boolean inside(V3 p) {
        return p.x() >= min.x() && p.x() <= max.x() && p.z() >= min.z() && p.z() <= max.z()
                && p.y() >= minY && p.y() <= max.y();
    }

    // ------------------------------------------------------------ проверка

    /** Проблемы трассы понятными словами; пустой список — трасса в порядке. */
    public List<String> problems() {
        List<String> out = new ArrayList<>();
        if (sectors.isEmpty()) out.add("нет секторов");
        int expected = 0;
        for (Sector s : sectors) {
            String sn = "сектор " + (s.index() + 1);
            if (s.index() != sectors.indexOf(s)) out.add(sn + ": неверный номер");
            V3 toFirst = s.rings().get(0).center().sub(s.checkpoint().pos());
            if (toFirst.dot(s.rings().get(0).normal()) <= 0) out.add(sn + ": контрольная точка не перед первым кольцом");
            if (!inside(s.checkpoint().pos())) out.add(sn + ": контрольная точка за границей трассы");
            if (s.checkpoint().speed() <= 0 || s.checkpoint().speed() > speedCap) out.add(sn + ": скорость возврата вне 0…предел");
            for (Ring r : s.rings()) {
                if (r.order() != expected) out.add(sn + ": кольцо " + r.order() + " не по порядку");
                if (r.sector() != s.index()) out.add(sn + ": кольцо " + r.order() + " из другого сектора");
                if (r.radius() < 1.5) out.add("кольцо " + (r.order() + 1) + ": радиус меньше 1.5");
                if (!inside(r.center())) out.add("кольцо " + (r.order() + 1) + ": за границей трассы");
                expected++;
            }
        }
        for (int i = 1; i < rings.size(); i++) {
            double d = rings.get(i).center().distance(rings.get(i - 1).center());
            if (d > 140) out.add("кольца " + i + "→" + (i + 1) + ": слишком далеко (" + Math.round(d) + " блоков)");
            if (d < 6) out.add("кольца " + i + "→" + (i + 1) + ": слишком близко");
        }
        if (!rings.isEmpty() && rings.get(rings.size() - 1).kind() != Ring.Kind.FINISH) out.add("последнее кольцо не финишное");
        if (speedCap <= 0.5) out.add("предел скорости слишком мал");
        return out;
    }

    // ---------------------------------------------------------------- JSON

    public String toJson() {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", id);
        m.put("name", name);
        m.put("version", version);
        m.put("speedCap", speedCap);
        m.put("protectionSeconds", protectionTicks / 20.0);
        m.put("onMiss", onMiss == OnMiss.CHECKPOINT ? "checkpoint" : "error");
        m.put("minY", minY);
        m.put("bounds", Map.of("min", vec(min), "max", vec(max)));
        m.put("lobby", spot(lobby));
        m.put("finish", spot(finish));
        List<Object> ss = new ArrayList<>();
        for (Sector s : sectors) {
            Map<String, Object> sm = new LinkedHashMap<>();
            sm.put("name", s.name());
            sm.put("checkpoint", cp(s.checkpoint()));
            List<Object> rs = new ArrayList<>();
            for (Ring r : s.rings()) rs.add(ring(r));
            sm.put("rings", rs);
            ss.add(sm);
        }
        m.put("sectors", ss);
        List<Object> zs = new ArrayList<>();
        for (Zone z : zones) {
            Map<String, Object> zm = new LinkedHashMap<>();
            zm.put("kind", "lift");
            zm.put("min", vec(z.min()));
            zm.put("max", vec(z.max()));
            zm.put("strength", z.strength());
            zs.add(zm);
        }
        m.put("zones", zs);
        if (trainingStart != null) {
            List<Object> ts = new ArrayList<>();
            for (Ring r : training) ts.add(ring(r));
            m.put("training", Map.of("checkpoint", cp(trainingStart), "rings", ts));
        }
        return MiniJson.write(m);
    }

    static List<Object> vec(V3 v) {
        return List.of(round(v.x()), round(v.y()), round(v.z()));
    }

    static double round(double d) {
        return Math.round(d * 1000) / 1000.0;
    }

    static Map<String, Object> spot(Spot s) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("pos", vec(s.pos()));
        m.put("yaw", (double) s.yaw());
        return m;
    }

    static Map<String, Object> cp(Checkpoint c) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("pos", vec(c.pos()));
        m.put("yaw", round(c.yaw()));
        m.put("pitch", round(c.pitch()));
        m.put("speed", c.speed());
        return m;
    }

    static Map<String, Object> ring(Ring r) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("pos", vec(r.center()));
        m.put("normal", vec(r.normal()));
        m.put("radius", r.radius());
        m.put("kind", r.kind().name().toLowerCase());
        if (r.boost() > 0) m.put("boost", r.boost());
        return m;
    }

    /** @throws IllegalArgumentException если JSON не похож на трассу */
    public static Track fromJson(String json) {
        Map<String, Object> m = MiniJson.parseObject(json);
        double cap = num(m.get("speedCap"), 2.4);
        List<Sector> sectors = new ArrayList<>();
        int order = 0;
        for (Object so : list(m.get("sectors"))) {
            Map<String, Object> sm = map(so);
            int si = sectors.size();
            List<Ring> rings = new ArrayList<>();
            for (Object ro : list(sm.get("rings"))) rings.add(ring(map(ro), order++, si));
            sectors.add(new Sector(si, str(sm.get("name"), "Сектор " + (si + 1)), cp(map(sm.get("checkpoint"))), rings));
        }
        List<Zone> zones = new ArrayList<>();
        for (Object zo : list(m.get("zones"))) {
            Map<String, Object> zm = map(zo);
            zones.add(new Zone(Zone.Kind.LIFT, v(zm.get("min")), v(zm.get("max")), num(zm.get("strength"), 0.08)));
        }
        Checkpoint ts = null;
        List<Ring> training = new ArrayList<>();
        if (m.get("training") instanceof Map<?, ?> tm) {
            Map<String, Object> t = map(tm);
            ts = cp(map(t.get("checkpoint")));
            int o = 0;
            for (Object ro : list(t.get("rings"))) training.add(ring(map(ro), o++, 0));
        }
        Map<String, Object> b = map(m.get("bounds"));
        return new Track(str(m.get("id"), "track"), str(m.get("name"), "Трасса"), (int) num(m.get("version"), 1),
                sectors, zones, spot(map(m.get("lobby"))), m.get("finish") == null ? null : spot(map(m.get("finish"))),
                ts, training, v(b.get("min")), v(b.get("max")), num(m.get("minY"), 0), cap,
                (int) Math.round(num(m.get("protectionSeconds"), 3) * 20),
                "checkpoint".equals(m.get("onMiss")) ? OnMiss.CHECKPOINT : OnMiss.ERROR);
    }

    static Ring ring(Map<String, Object> r, int order, int sector) {
        Ring.Kind kind = switch (str(r.get("kind"), "normal")) {
            case "boost" -> Ring.Kind.BOOST;
            case "finish" -> Ring.Kind.FINISH;
            default -> Ring.Kind.NORMAL;
        };
        return new Ring(order, sector, v(r.get("pos")), v(r.get("normal")), num(r.get("radius"), 4), kind,
                num(r.get("boost"), 0));
    }

    static Checkpoint cp(Map<String, Object> c) {
        return new Checkpoint(v(c.get("pos")), (float) num(c.get("yaw"), 0), (float) num(c.get("pitch"), 0),
                num(c.get("speed"), 0.8));
    }

    static Spot spot(Map<String, Object> s) {
        return new Spot(v(s.get("pos")), (float) num(s.get("yaw"), 0));
    }

    @SuppressWarnings("unchecked")
    static Map<String, Object> map(Object o) {
        if (o instanceof Map<?, ?> m) return (Map<String, Object>) m;
        throw new IllegalArgumentException("ожидался объект");
    }

    static List<?> list(Object o) {
        if (o == null) return List.of();
        if (o instanceof List<?> l) return l;
        throw new IllegalArgumentException("ожидался массив");
    }

    static V3 v(Object o) {
        List<?> l = list(o);
        if (l.size() != 3) throw new IllegalArgumentException("ожидались три координаты");
        return new V3(num(l.get(0), 0), num(l.get(1), 0), num(l.get(2), 0));
    }

    static double num(Object o, double def) {
        return o instanceof Number n ? n.doubleValue() : def;
    }

    static String str(Object o, String def) {
        return o instanceof String s && !s.isBlank() ? s : def;
    }
}
