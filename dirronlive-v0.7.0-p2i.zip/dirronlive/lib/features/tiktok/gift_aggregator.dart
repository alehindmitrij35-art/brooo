import 'dart:async';
import 'dart:collection';

import '../../core/events/event_source.dart';
import '../../core/events/gift_event.dart';

/// Превращает сырые подарки коннектора в события Dirronlive.
///
/// * Обычный подарок (не серийный) публикуется сразу, одним событием.
/// * Серия (giftType 1 в TikTok: зритель жмёт «Розу» подряд) приходит
///   промежуточными событиями с растущим repeatCount и последним с
///   repeatEnd. Здесь все они становятся шагами одной записи (общий
///   comboId), а итог — «Роза ×5». В игру серия уходит один раз — по
///   окончании (это решает доставка, глядя на `comboActive: false`).
/// * Если конец серии не пришёл (обрыв связи), серия завершается сама
///   через [finalizeAfter] после последнего события.
/// * Повторы отсекаются по ID сообщения TikTok и по ID серии (groupId).
///   Две самостоятельные серии одного зрителя — разные groupId — разные
///   записи.
class TikTokGiftAggregator {
  TikTokGiftAggregator({
    required void Function(GiftEvent event) publish,
    DateTime Function() clock = DateTime.now,
    this.finalizeAfter = const Duration(seconds: 15),
  })  : _publish = publish,
        _clock = clock;

  final void Function(GiftEvent event) _publish;
  final DateTime Function() _clock;
  final Duration finalizeAfter;

  final Map<String, _Streak> _open = {};
  final LinkedHashSet<String> _seen = LinkedHashSet<String>();
  int _anonymousSeries = 0;

  int get openStreaks => _open.length;

  void add(Map<String, Object?> raw) {
    final msgId = _string(raw['msgId']);
    if (msgId != null && !_remember('msg:$msgId')) return; // повтор сообщения

    final viewer = viewerName(raw);
    final giftName = translateGiftName(_string(raw['giftName']) ?? 'Подарок');
    final userKey = _string(raw['userId']) ?? _string(raw['uniqueId']) ?? viewer;
    final giftId = _giftId(raw['giftId']);
    final giftKey = giftId ?? giftName;
    final image = _image(raw['giftImage']);
    final avatar = _image(raw['avatar']);
    final diamonds = raw['diamondCount'] is num ? (raw['diamondCount']! as num).toInt() : 0;
    final countRaw = raw['repeatCount'];
    final count = countRaw is num && countRaw >= 1 ? countRaw.toInt() : 1;
    final ended = raw['repeatEnd'] == true;

    // Всё с одним groupId — один подарок: и серия ×15, ×16, ×17 (итог ×17,
    // а не 15 + 16 + 17), и пара сообщений «идёт» + «закончилось» ×1
    // (итог ×1, а не 2). Шаги сразу уходят в игру нарастающим итогом.
    final streakable = raw['streakable'] == true || _string(raw['groupId']) != null;
    if (!streakable) {
      // Одиночный подарок завершён сразу.
      if (msgId == null) {
        final key = 'single:$userKey:$giftKey:${_string(raw['createTime'])}';
        if (!_remember(key)) return;
      }
      _publish(GiftEvent(
        id: generateEventId(),
        createdAt: _clock(),
        source: EventSource.tiktok,
        viewerName: viewer,
        giftName: giftName,
        count: count,
        giftId: giftId,
        viewerId: userKey,
        giftImage: image,
        diamonds: diamonds,
        sourceKey: msgId != null ? 'msg:$msgId' : 'single:$userKey:$giftKey:${_string(raw['createTime'])}',
        viewerAvatar: avatar,
      ));
      return;
    }

    final groupId = _string(raw['groupId']);
    final key = groupId != null
        ? 'group:$userKey:$giftKey:$groupId'
        : _openSeriesKey(userKey, giftKey);
    if (_seen.contains(key)) return; // серия уже завершена — поздний повтор

    final streak = _open.putIfAbsent(
      key,
      () => _Streak(
        comboId: 'tiktok-${generateEventId()}',
        userKey: userKey,
        giftKey: giftKey,
        viewer: viewer,
        giftName: giftName,
        giftId: giftId,
        image: image,
        diamonds: diamonds,
        sourceKey: groupId != null ? key : null,
        avatar: avatar,
      ),
    );
    final grew = count > streak.count;
    if (grew) streak.count = count;
    streak.timer?.cancel();

    if (ended) {
      _finish(key);
      return;
    }
    streak.timer = Timer(finalizeAfter, () => _finish(key));
    if (grew) _emit(streak, active: true);
  }

  /// Завершить все незаконченные серии (отключение, конец эфира).
  void flushAll() {
    for (final key in _open.keys.toList()) {
      _finish(key);
    }
  }

  void dispose() {
    for (final streak in _open.values) {
      streak.timer?.cancel();
    }
    _open.clear();
  }

  void _finish(String key) {
    final streak = _open.remove(key);
    if (streak == null) return;
    streak.timer?.cancel();
    _remember(key);
    _emit(streak, active: false);
  }

  void _emit(_Streak streak, {required bool active}) {
    _publish(GiftEvent(
      id: generateEventId(),
      createdAt: _clock(),
      source: EventSource.tiktok,
      viewerName: streak.viewer,
      giftName: streak.giftName,
      count: streak.count,
      comboId: streak.comboId,
      comboActive: active,
      giftId: streak.giftId,
      viewerId: streak.userKey,
      giftImage: streak.image,
      diamonds: streak.diamonds,
      sourceKey: streak.sourceKey ?? streak.comboId,
      viewerAvatar: streak.avatar,
    ));
  }

  static String? _image(Object? value) =>
      value is String && value.startsWith('http') ? value : null;

  static String? _giftId(Object? value) {
    final id = _string(value);
    return id == null || id == 'unknown' ? null : id;
  }

  /// Без groupId: продолжаем открытую серию того же зрителя и подарка
  /// или начинаем новую.
  String _openSeriesKey(String userKey, String giftKey) {
    for (final entry in _open.entries) {
      final s = entry.value;
      if (s.userKey == userKey && s.giftKey == giftKey) return entry.key;
    }
    return 'series:$userKey:$giftKey:${_anonymousSeries++}';
  }

  /// `true`, если ключ новый.
  bool _remember(String key) {
    if (!_seen.add(key)) return false;
    if (_seen.length > 5000) _seen.remove(_seen.first);
    return true;
  }

  static String? _string(Object? value) {
    if (value == null) return null;
    final text = '$value'.trim();
    return text.isEmpty || text == '0' ? null : text;
  }

  /// Ник зрителя: отображаемое имя, иначе @логин.
  static String viewerName(Map<String, Object?> raw) {
    final nickname = _string(raw['nickname']);
    if (nickname != null) return nickname;
    final uniqueId = _string(raw['uniqueId']);
    if (uniqueId != null) return '@$uniqueId';
    return 'Зритель';
  }
}

class _Streak {
  _Streak({
    required this.comboId,
    required this.userKey,
    required this.giftKey,
    required this.viewer,
    required this.giftName,
    this.giftId,
    this.image,
    this.diamonds = 0,
    this.sourceKey,
    this.avatar,
  });

  final String comboId;
  final String? avatar;
  final String? giftId;
  final String? image;
  final int diamonds;
  final String? sourceKey;
  final String userKey;
  final String giftKey;
  final String viewer;
  final String giftName;
  int count = 0;
  Timer? timer;
}

/// Русские названия популярных подарков TikTok; остальные — как есть.
String translateGiftName(String name) => _giftNames[name] ?? name;

const _giftNames = <String, String>{
  'Rose': 'Роза',
  'Finger Heart': 'Сердечко',
  'Heart Me': 'Сердце',
  'Hand Hearts': 'Сердце руками',
  'Doughnut': 'Пончик',
  'Ice Cream Cone': 'Мороженое',
  'Perfume': 'Духи',
  'Lion': 'Лев',
  'Galaxy': 'Галактика',
  'Universe': 'Вселенная',
  'Sunglasses': 'Очки',
  'Corgi': 'Корги',
  'Rocket': 'Ракета',
};
