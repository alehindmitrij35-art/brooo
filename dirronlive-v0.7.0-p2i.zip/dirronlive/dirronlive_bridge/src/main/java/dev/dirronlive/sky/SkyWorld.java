package dev.dirronlive.sky;

import dev.dirronlive.sky.core.Checkpoint;
import dev.dirronlive.sky.core.Forces;
import dev.dirronlive.sky.core.Ring;
import dev.dirronlive.bridge.BridgeProtocol;
import dev.dirronlive.sky.core.Sector;
import dev.dirronlive.sky.core.SkyEffects;
import dev.dirronlive.sky.core.SkyRun;
import dev.dirronlive.sky.core.SkyStatus;
import dev.dirronlive.sky.core.Track;
import dev.dirronlive.sky.core.V3;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LightningEntity;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.UnbreakableComponent;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerAbilities;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.WorldSavePath;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.GameRules;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Режим «Небесный разлом» в открытом мире: трасса из файла
 * {@code dirron_sky/track.json}, заезды игроков, возвраты, пауза и
 * надписи над хотбаром. Кольца проверяются на сервере по отрезку движения,
 * а поправки скорости (потоки, эффекты, предел) — у игрока каждый тик, без
 * пакетов (см. {@link SkyClient}).
 */
public final class SkyWorld {
    public static final Logger LOG = LoggerFactory.getLogger("Dirron Sky");
    public static final String TRACK_FILE = "dirron_sky/track.json";

    private static final Map<MinecraftServer, SkyWorld> INSTANCES = new ConcurrentHashMap<>();

    /** Для программы: состояние заезда игрока. Можно читать из любого потока. */
    public static volatile SkyStatus lastStatus = SkyStatus.ABSENT;

    /** Для клиента: что применять к полёту в этом тике. */
    public record ClientView(UUID player, boolean flying, Track track, Forces forces, int nextRing, double ringScale,
                             List<SkyEffects.Gate> gates, boolean training) {
        public static final ClientView OFF = new ClientView(null, false, null, Forces.NONE, 0, 1, List.of(), false);
    }

    public static volatile ClientView view = ClientView.OFF;

    public record Result(boolean ok, String text) {}

    /** Игрок в заезде. */
    static final class Pilot {
        SkyRun run;
        boolean training;
        V3 prev;
        boolean teleported = true;
        double lastSpeed;
        V3 holdPos;
        float holdYaw, holdPitch;
        V3 pauseDir = new V3(0, 0, 1);
        long finishAt = -1;
        long lastWrongWay = -1000;
        final SkyEffects effects = new SkyEffects();
        /** Последние 10 секунд полёта для «Временного разлома»: x y z vx vy vz. */
        final java.util.ArrayDeque<double[]> history = new java.util.ArrayDeque<>();
    }

    static final int HISTORY = 200;

    public final MinecraftServer server;
    public final ServerWorld world;
    public final SkyState state;
    private Track track;
    private Track trainingTrack;
    private String problem = "";
    private final Map<UUID, Pilot> pilots = new HashMap<>();
    private final java.util.Set<UUID> greeted = new java.util.HashSet<>();
    /** Куда отправлять ответы на действия (по id события), пока они не завершены. */
    private final Map<String, Consumer<String>> listeners = new java.util.LinkedHashMap<>(64, 0.75f, false) {
        @Override
        protected boolean removeEldestEntry(Map.Entry<String, Consumer<String>> eldest) {
            return size() > 400;
        }
    };
    private long tick;

    private SkyWorld(MinecraftServer server) {
        this.server = server;
        this.world = server.getOverworld();
        this.state = SkyState.get(world);
    }

    public static SkyWorld get(MinecraftServer server) {
        return INSTANCES.computeIfAbsent(server, SkyWorld::new);
    }

    public static void forget(MinecraftServer server) {
        INSTANCES.remove(server);
        lastStatus = SkyStatus.ABSENT;
        view = ClientView.OFF;
    }

    /** Игрок сейчас в заезде (паркур в это время его не трогает). */
    public static boolean isPilot(MinecraftServer server, UUID id) {
        SkyWorld sw = INSTANCES.get(server);
        if (sw == null) return false;
        Pilot p = sw.pilots.get(id);
        return p != null && p.run.phase() != SkyRun.Phase.IDLE;
    }

    // ------------------------------------------------------------- трасса

    public Path trackPath() {
        return server.getSavePath(WorldSavePath.ROOT).resolve(TRACK_FILE).normalize();
    }

    /** Загрузить трассу из файла мира. Без файла — в этом мире режима нет. */
    public void load() {
        Path path = trackPath();
        track = null;
        trainingTrack = null;
        problem = "";
        if (!Files.isRegularFile(path)) {
            if (state.built) problem = "нет файла " + TRACK_FILE;
            return;
        }
        try {
            setTrack(Track.fromJson(Files.readString(path, StandardCharsets.UTF_8)));
        } catch (IOException | RuntimeException e) {
            problem = "трасса не читается: " + e.getMessage();
            LOG.warn("Dirron Sky: {}", problem);
        }
    }

    /** Поставить трассу (после загрузки или постройки карты). */
    public void setTrack(Track t) {
        List<String> problems = t.problems();
        if (!problems.isEmpty()) {
            problem = problems.get(0) + (problems.size() > 1 ? " (и ещё " + (problems.size() - 1) + ")" : "");
            LOG.warn("Dirron Sky: проблемы трассы: {}", problems);
        } else {
            problem = "";
        }
        track = t;
        trainingTrack = training(t);
        pilots.clear();
        LOG.info("Dirron Sky: трасса «{}» — секторов {}, колец {}, зон {}", t.name, t.sectors.size(), t.ringCount(),
                t.zones.size());
    }

    /** Сохранить трассу в мир (постройка карты). */
    public void install(Track t) throws IOException {
        Path path = trackPath();
        Files.createDirectories(path.getParent());
        Files.writeString(path, t.toJson(), StandardCharsets.UTF_8);
        state.built = true;
        state.markDirty();
        setTrack(t);
    }

    public Track track() {
        return track;
    }

    /** Свободное место для карты в чужом мире (команда /sky build). */
    public static final int FALLBACK_X = -600_000, FALLBACK_Y = 0, FALLBACK_Z = -600_000;

    /** Построить «Небесные острова» с началом в (bx, by, bz) и поставить трассу. */
    public int build(int bx, int by, int bz) throws IOException {
        dev.dirronlive.sky.map.SkyIslands.Layout layout = dev.dirronlive.sky.map.SkyIslands.generate(bx, by, bz);
        net.minecraft.util.math.BlockPos.Mutable pos = new net.minecraft.util.math.BlockPos.Mutable();
        Map<String, net.minecraft.block.BlockState> parsed = new HashMap<>();
        int count = 0;
        for (Map.Entry<Long, String> e : layout.blueprint().blocks().entrySet()) {
            long k = e.getKey();
            pos.set(dev.dirronlive.parkour.map.Blueprint.keyX(k), dev.dirronlive.parkour.map.Blueprint.keyY(k),
                    dev.dirronlive.parkour.map.Blueprint.keyZ(k));
            net.minecraft.block.BlockState st = parsed.computeIfAbsent(e.getValue(), b -> {
                net.minecraft.block.BlockState x = dev.dirronlive.parkour.world.ParkourWorld.parseState(b);
                return x != null ? x : net.minecraft.block.Blocks.STONE.getDefaultState();
            });
            world.setBlockState(pos, st, net.minecraft.block.Block.NOTIFY_LISTENERS | net.minecraft.block.Block.FORCE_STATE);
            count++;
        }
        install(layout.track());
        configureWorld();
        return count;
    }

    public boolean ready() {
        return track != null && problem.isEmpty();
    }

    /** Тренировочный круг — отдельная маленькая трасса из одного сектора. */
    static Track training(Track t) {
        if (t.trainingStart == null || t.training.isEmpty()) return null;
        List<Ring> rings = new ArrayList<>();
        for (int i = 0; i < t.training.size(); i++) {
            Ring r = t.training.get(i);
            boolean last = i == t.training.size() - 1;
            rings.add(new Ring(i, 0, r.center(), r.normal(), r.radius(), last ? Ring.Kind.FINISH : r.kind(), r.boost()));
        }
        Sector s = new Sector(0, "Тренировка", t.trainingStart, rings);
        return new Track(t.id + "_training", "Тренировка", t.version, List.of(s), t.zones, t.lobby, t.lobby, null, null,
                t.min, t.max, t.minY, t.speedCap, t.protectionTicks, Track.OnMiss.ERROR);
    }

    // ------------------------------------------------------------ команды

    public Result command(ServerPlayerEntity player, String cmd) {
        if (track == null) return new Result(false, problem.isEmpty()
                ? "В этом мире нет трассы «Небесный разлом». Откройте мир DirronSky" : "Трасса не готова: " + problem);
        Pilot pilot = pilots.get(player.getUuid());
        switch (cmd) {
            case "start", "restart" -> {
                return start(player, false);
            }
            case "training" -> {
                if (trainingTrack == null) return new Result(false, "На этой трассе нет тренировки");
                return start(player, true);
            }
            case "pause" -> {
                if (pilot == null || !pilot.run.pause()) return new Result(false, "Пауза — только во время полёта");
                pilot.pauseDir = directionOf(player);
                hold(player, pilot, body(player), player.getYaw(), player.getPitch());
                say(player, Text.literal("ПАУЗА").formatted(Formatting.YELLOW, Formatting.BOLD), "время остановлено");
                publish(player, pilot);
                return new Result(true, "Пауза");
            }
            case "resume" -> {
                if (pilot == null || pilot.run.phase() != SkyRun.Phase.PAUSED) return new Result(false, "Заезд не на паузе");
                handle(player, pilot, pilot.run.resume());
                publish(player, pilot);
                return new Result(true, "Продолжаем через 3 секунды");
            }
            case "checkpoint" -> {
                if (pilot == null || pilot.run.phase() != SkyRun.Phase.RUNNING) return new Result(false, "Заезд не идёт");
                handle(player, pilot, pilot.run.toCheckpoint());
                return new Result(true, "Возврат на контрольную точку");
            }
            case "stop", "finish" -> {
                if (pilot == null) return new Result(false, "Заезд не начат");
                stop(player, pilot);
                return new Result(true, "Заезд остановлен");
            }
            default -> {
                return new Result(false, "Неизвестная команда: " + cmd);
            }
        }
    }

    Result start(ServerPlayerEntity player, boolean training) {
        Track t = training ? trainingTrack : track;
        Pilot pilot = pilots.computeIfAbsent(player.getUuid(), k -> new Pilot());
        if (pilot.run == null || pilot.run.track != t) {
            pilot.run = new SkyRun(t);
            if (!training) pilot.run.setBestTicks(state.best(player.getUuid()));
        }
        pilot.training = training;
        pilot.finishAt = -1;
        apply(player, pilot, pilot.effects.reset("заезд перезапущен"));
        pilot.history.clear();
        handle(player, pilot, pilot.run.start());
        Checkpoint cp = pilot.run.checkpoint();
        hold(player, pilot, cp.pos(), cp.yaw(), cp.pitch());
        publish(player, pilot);
        return new Result(true, training ? "Тренировка: старт через 3 секунды" : "Старт через 3 секунды");
    }

    void stop(ServerPlayerEntity player, Pilot pilot) {
        apply(player, pilot, pilot.effects.reset("заезд остановлен"));
        pilot.run.stop();
        release(player, false);
        teleport(player, track.lobby.pos(), track.lobby.yaw(), 0);
        pilot.teleported = true;
        say(player, Text.literal("Заезд остановлен").formatted(Formatting.GRAY), "");
        publish(player, pilot);
    }

    // ---------------------------------------------------------------- тики

    public void tick() {
        tick++;
        if (track == null) {
            if (state.built || !problem.isEmpty()) lastStatus = statusWithout("preparing");
            return;
        }
        enableCheats();
        ServerPlayerEntity first = null;
        for (ServerPlayerEntity player : world.getPlayers()) {
            if (player.isSpectator()) continue;
            // Для программы и клиента важен тот, кто сейчас летит.
            Pilot pp = pilots.get(player.getUuid());
            if (first == null || (pp != null && pp.run.active() && !isActive(first))) first = player;
            if (state.built && greeted.add(player.getUuid()) && !pilots.containsKey(player.getUuid())) {
                welcome(player);
            }
            Pilot pilot = pilots.get(player.getUuid());
            if (pilot != null) tickPilot(player, pilot);
        }
        if (first == null) {
            view = ClientView.OFF;
            lastStatus = statusWithout("ready");
            return;
        }
        Pilot p = pilots.get(first.getUuid());
        if (p == null) {
            // Без заезда — кольца видны как подсказка маршрута.
            view = state.built ? new ClientView(first.getUuid(), false, track, Forces.NONE, 0, 1, List.of(), false)
                    : ClientView.OFF;
            lastStatus = statusWithout(ready() ? "ready" : "preparing");
        } else {
            view = new ClientView(first.getUuid(), p.run.phase() == SkyRun.Phase.RUNNING, p.run.track, forces(first, p),
                    p.run.nextRing(), p.run.ringScale(), p.effects.gates(), p.training);
            if (tick % 5 == 0) publish(first, p);
        }
    }

    boolean isActive(ServerPlayerEntity player) {
        Pilot p = pilots.get(player.getUuid());
        return p != null && p.run.active();
    }

    /** Силы эффектов, которые сейчас действуют на полёт игрока. */
    public Forces forcesFor(ServerPlayerEntity player) {
        Pilot p = pilots.get(player.getUuid());
        return p == null ? Forces.NONE : forces(player, p);
    }

    /** Силы от эффектов зрителей (этап «Действия»). */
    Forces forces(ServerPlayerEntity player, Pilot pilot) {
        if (pilot.run.phase() != SkyRun.Phase.RUNNING) return Forces.NONE;
        return pilot.effects.forces(pilot.run.protection() > 0);
    }

    void tickPilot(ServerPlayerEntity player, Pilot pilot) {
        SkyRun run = pilot.run;
        SkyRun.Phase phase = run.phase();
        V3 cur = body(player);
        if (phase == SkyRun.Phase.COUNTDOWN || phase == SkyRun.Phase.RESUMING || phase == SkyRun.Phase.PAUSED) {
            // Висим на месте: отсчёт или пауза.
            if (pilot.holdPos != null && cur.distance(pilot.holdPos) > 1.0) {
                teleportBody(player, pilot.holdPos, pilot.holdYaw, pilot.holdPitch);
                pilot.teleported = true;
            }
        }
        if (phase == SkyRun.Phase.FINISHED && pilot.finishAt >= 0 && tick >= pilot.finishAt) {
            pilot.finishAt = -1;
            release(player, false);
            teleport(player, track.finish.pos(), track.finish.yaw(), 0);
            pilot.teleported = true;
        }
        double speed = pilot.prev == null || pilot.teleported ? 0 : cur.distance(pilot.prev);
        boolean crashed = !pilot.teleported && pilot.lastSpeed > 0.6 && speed < pilot.lastSpeed * 0.35;
        boolean ground = player.isOnGround() || player.isTouchingWater() || player.isInLava();
        V3 from = pilot.prev;
        boolean jumped = pilot.teleported;
        SkyRun.Sample sample = new SkyRun.Sample(from, cur, jumped, ground, crashed);
        pilot.prev = cur;
        pilot.lastSpeed = speed;
        pilot.teleported = false;
        handle(player, pilot, run.tick(sample));
        boolean running = run.phase() == SkyRun.Phase.RUNNING;
        if (running && !jumped && !pilot.teleported) {
            Vec3d v = player.getVelocity();
            pilot.history.addLast(new double[] {cur.x(), cur.y(), cur.z(), v.x, v.y, v.z});
            while (pilot.history.size() > HISTORY) pilot.history.removeFirst();
        }
        if (pilot.teleported) pilot.history.clear();
        apply(player, pilot, pilot.effects.tick(running, run.protection() > 0, jumped || pilot.teleported, from, cur,
                context(player, pilot)));
        run.setRingScale(pilot.effects.ringScale());
        if (run.phase() == SkyRun.Phase.RUNNING && run.ticks() % 20 == 0) {
            say(player, progressLine(pilot), "");
        }
    }

    void handle(ServerPlayerEntity player, Pilot pilot, List<SkyRun.Event> events) {
        SkyRun run = pilot.run;
        for (SkyRun.Event e : events) {
            switch (e.type()) {
                case COUNTDOWN -> {
                    say(player, Text.literal("Старт через " + e.value()).formatted(Formatting.LIGHT_PURPLE, Formatting.BOLD), "");
                    sound(player, SoundEvents.BLOCK_NOTE_BLOCK_PLING.value(), 0.7f, 1.0f);
                }
                case LAUNCH -> {
                    Checkpoint cp = run.checkpoint();
                    launch(player, pilot, cp.pos(), cp.direction(), cp.speed());
                    say(player, Text.literal("ЛЕТИМ!").formatted(Formatting.LIGHT_PURPLE, Formatting.BOLD),
                            pilot.training ? "тренировка" : run.track.sectors.get(0).name());
                    sound(player, SoundEvents.BLOCK_NOTE_BLOCK_PLING.value(), 0.8f, 2.0f);
                }
                case RESUME -> {
                    launch(player, pilot, pilot.holdPos, pilot.pauseDir, run.checkpoint().speed());
                    say(player, Text.literal("Продолжаем").formatted(Formatting.LIGHT_PURPLE), "");
                }
                case RING -> {
                    float pitch = 0.9f + 0.1f * Math.min(8, run.ringInSector());
                    sound(player, SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 0.6f, pitch);
                    say(player, progressLine(pilot), "");
                }
                case BOOST -> {
                    boost(player, run.track.rings.get(e.value()));
                    sound(player, SoundEvents.ENTITY_FIREWORK_ROCKET_LAUNCH, 0.8f, 1.2f);
                    say(player, Text.literal("Ускорение!").formatted(Formatting.AQUA, Formatting.BOLD), "");
                }
                case MISS -> {
                    sound(player, SoundEvents.BLOCK_NOTE_BLOCK_BASS.value(), 0.8f, 0.6f);
                    say(player, Text.literal(e.value() < 0 ? "Мимо ворот" : "Промах").formatted(Formatting.RED, Formatting.BOLD),
                            "ошибок " + run.errors());
                }
                case SHIELD -> {
                    sound(player, SoundEvents.ITEM_TOTEM_USE, 0.5f, 1.4f);
                    say(player, Text.literal("Ангел-хранитель спас").formatted(Formatting.GOLD, Formatting.BOLD),
                            "ошибка не засчитана");
                    apply(player, pilot, pilot.effects.endEarly(SkyEffects.Kind.GUARDIAN, "щит сработал"));
                }
                case WRONG_WAY -> {
                    if (tick - pilot.lastWrongWay > 40) {
                        pilot.lastWrongWay = tick;
                        say(player, Text.literal("Не та сторона").formatted(Formatting.GOLD),
                                "кольцо проходят по стрелке");
                    }
                }
                case SECTOR -> {
                    sound(player, SoundEvents.ENTITY_PLAYER_LEVELUP, 0.6f, 1.3f);
                    say(player, Text.literal("Сектор " + (e.value() + 1) + " / " + run.track.sectors.size())
                                    .formatted(Formatting.LIGHT_PURPLE, Formatting.BOLD),
                            run.track.sectors.get(e.value()).name());
                }
                case FINISH -> {
                    finish(player, pilot);
                    apply(player, pilot, pilot.effects.reset("финиш"));
                }
                case RETURN -> {
                    pilot.history.clear();
                    Checkpoint cp = run.checkpoint();
                    launch(player, pilot, cp.pos(), cp.direction(), cp.speed());
                    sound(player, SoundEvents.ENTITY_ENDERMAN_TELEPORT, 0.5f, 1.2f);
                    say(player, Text.literal("Контрольная точка").formatted(Formatting.YELLOW, Formatting.BOLD),
                            reasonText(e.reason()) + " · ошибок " + run.errors());
                }
                default -> {}
            }
        }
        if (!events.isEmpty()) publish(player, pilot);
    }

    static String reasonText(String reason) {
        return switch (reason) {
            case "crash" -> "врезался";
            case "ground" -> "касание земли";
            case "void" -> "упал";
            case "bounds" -> "за границей трассы";
            case "miss" -> "промах";
            case "manual" -> "по команде";
            default -> reason;
        };
    }

    void finish(ServerPlayerEntity player, Pilot pilot) {
        SkyRun run = pilot.run;
        boolean record = false;
        if (!pilot.training) {
            long old = state.best(player.getUuid());
            if (old == 0 || run.ticks() < old) {
                state.setBest(player.getUuid(), run.ticks());
                record = old != 0;
            }
        }
        pilot.finishAt = tick + 60;
        sound(player, SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, 0.7f, 1.0f);
        String sub = time(run.ticks()) + " · ошибок " + run.errors() + (record ? " · РЕКОРД" : "");
        say(player, Text.literal(pilot.training ? "ТРЕНИРОВКА ПРОЙДЕНА" : "ФИНИШ").formatted(Formatting.GREEN, Formatting.BOLD), sub);
        player.sendMessage(Text.literal((pilot.training ? "Тренировка: " : "Небесный разлом: ") + sub)
                .formatted(Formatting.LIGHT_PURPLE), false);
    }

    Text progressLine(Pilot pilot) {
        SkyRun run = pilot.run;
        return Text.empty()
                .append(Text.literal("Сектор " + (run.sector() + 1) + "/" + run.track.sectors.size()).formatted(Formatting.LIGHT_PURPLE))
                .append(Text.literal(" · ").formatted(Formatting.DARK_GRAY))
                .append(Text.literal("кольцо " + run.ringInSector() + "/" + run.ringsInSector()).formatted(Formatting.WHITE))
                .append(Text.literal(" · ").formatted(Formatting.DARK_GRAY))
                .append(Text.literal(time(run.ticks())).formatted(Formatting.WHITE))
                .append(Text.literal(" · ").formatted(Formatting.DARK_GRAY))
                .append(Text.literal("ошибок " + run.errors()).formatted(run.errors() == 0 ? Formatting.GREEN : Formatting.GOLD));
    }

    public static String time(long ticks) {
        long ms = ticks * 50;
        return String.format(Locale.ROOT, "%d:%02d.%d", ms / 60000, (ms / 1000) % 60, (ms / 100) % 10);
    }

    void welcome(ServerPlayerEntity player) {
        teleport(player, track.lobby.pos(), track.lobby.yaw(), 0);
        ensureElytra(player);
        player.sendMessage(Text.literal("Небесный разлом: старт — кнопкой в Dirronlive или /sky start, тренировка — /sky training")
                .formatted(Formatting.LIGHT_PURPLE), false);
    }

    // ------------------------------------------------------------- движение

    /** Центр тела в полёте (позиция — это ноги). */
    static V3 body(ServerPlayerEntity player) {
        return new V3(player.getX(), player.getY() + 0.3, player.getZ());
    }

    static V3 directionOf(ServerPlayerEntity player) {
        Vec3d v = player.getVelocity();
        V3 d = new V3(v.x, v.y, v.z);
        if (d.length() < 0.2) d = V3.look(player.getYaw(), player.getPitch());
        return d.normalize();
    }

    /** Висеть на месте (отсчёт, пауза): полёт как в творческом, без урона. */
    void hold(ServerPlayerEntity player, Pilot pilot, V3 pos, float yaw, float pitch) {
        pilot.holdPos = pos;
        pilot.holdYaw = yaw;
        pilot.holdPitch = pitch;
        PlayerAbilities a = player.getAbilities();
        a.allowFlying = true;
        a.flying = true;
        a.invulnerable = true;
        player.sendAbilitiesUpdate();
        player.stopFallFlying();
        teleportBody(player, pos, yaw, pitch);
        pilot.teleported = true;
    }

    /** Полёт с точки в направлении {@code dir} с безопасной скоростью. */
    void launch(ServerPlayerEntity player, Pilot pilot, V3 pos, V3 dir, double speed) {
        PlayerAbilities a = player.getAbilities();
        player.interactionManager.getGameMode().setAbilities(a);
        a.flying = false;
        a.invulnerable = true;
        player.sendAbilitiesUpdate();
        ensureElytra(player);
        float[] angles = V3.angles(dir);
        teleportBody(player, pos, angles[0], angles[1]);
        player.startFallFlying();
        V3 v = dir.normalize().mul(speed);
        player.setVelocity(v.x(), v.y(), v.z());
        player.velocityModified = true;
        player.fallDistance = 0;
        pilot.teleported = true;
        pilot.lastSpeed = 0;
    }

    /** Ускорение кольца: скорость не меньше {@code boost}, направление ближе к оси кольца. */
    void boost(ServerPlayerEntity player, Ring ring) {
        Vec3d v = player.getVelocity();
        V3 cur = new V3(v.x, v.y, v.z);
        V3 dir = cur.normalize().lerp(ring.normal(), 0.6).normalize();
        double speed = Math.min(track.speedCap, Math.max(cur.length(), ring.boost()));
        V3 nv = dir.mul(speed);
        player.setVelocity(nv.x(), nv.y(), nv.z());
        player.velocityModified = true;
    }

    /** Вернуть обычные способности режима игры (полёт, урон). */
    void release(ServerPlayerEntity player, boolean keepInvulnerable) {
        PlayerAbilities a = player.getAbilities();
        player.interactionManager.getGameMode().setAbilities(a);
        if (keepInvulnerable) a.invulnerable = true;
        player.sendAbilitiesUpdate();
    }

    void teleportBody(ServerPlayerEntity player, V3 body, float yaw, float pitch) {
        teleport(player, body.add(0, -0.3, 0), yaw, pitch);
    }

    void teleport(ServerPlayerEntity player, V3 feet, float yaw, float pitch) {
        player.stopRiding();
        player.teleport(world, feet.x(), feet.y(), feet.z(), yaw, pitch);
        player.setVelocity(Vec3d.ZERO);
        player.velocityModified = true;
        player.fallDistance = 0;
    }

    static void ensureElytra(ServerPlayerEntity player) {
        ItemStack chest = player.getEquippedStack(EquipmentSlot.CHEST);
        if (chest.isOf(Items.ELYTRA)) {
            if (!chest.contains(DataComponentTypes.UNBREAKABLE)) chest.set(DataComponentTypes.UNBREAKABLE, new UnbreakableComponent(false));
            return;
        }
        if (!chest.isEmpty()) {
            ItemStack old = chest.copy();
            if (!player.getInventory().insertStack(old)) player.dropItem(old, false);
        }
        ItemStack elytra = new ItemStack(Items.ELYTRA);
        elytra.set(DataComponentTypes.UNBREAKABLE, new UnbreakableComponent(false));
        player.equipStack(EquipmentSlot.CHEST, elytra);
    }

    // ------------------------------------------------------------ надписи

    /** Одна компактная строка над хотбаром. */
    static void say(ServerPlayerEntity player, Text title, String sub) {
        Text line = sub == null || sub.isBlank() ? title
                : Text.empty().append(title).append(Text.literal(" · ").formatted(Formatting.GRAY))
                        .append(Text.literal(sub).formatted(Formatting.WHITE));
        player.sendMessage(line, true);
    }

    static void sound(ServerPlayerEntity player, SoundEvent sound, float volume, float pitch) {
        player.playSoundToPlayer(sound, SoundCategory.PLAYERS, volume, pitch);
    }

    void enableCheats() {
        if (!state.built) return;
        var players = server.getPlayerManager();
        if (players.areCheatsAllowed()) return;
        players.setCheatsAllowed(true);
        for (ServerPlayerEntity player : players.getPlayerList()) players.sendCommandTree(player);
    }

    /** Правила мира для полёта: день, без мобов и урона от падения. */
    public void configureWorld() {
        GameRules rules = world.getGameRules();
        rules.get(GameRules.DO_DAYLIGHT_CYCLE).set(false, server);
        rules.get(GameRules.DO_WEATHER_CYCLE).set(false, server);
        rules.get(GameRules.DO_MOB_SPAWNING).set(false, server);
        rules.get(GameRules.FALL_DAMAGE).set(false, server);
        rules.get(GameRules.DO_IMMEDIATE_RESPAWN).set(true, server);
        rules.get(GameRules.KEEP_INVENTORY).set(true, server);
        rules.get(GameRules.ANNOUNCE_ADVANCEMENTS).set(false, server);
        rules.get(GameRules.DO_FIRE_TICK).set(false, server);
        world.setTimeOfDay(6000);
        world.setWeather(1_000_000, 0, false, false);
        if (track != null) world.setSpawnPos(net.minecraft.util.math.BlockPos.ofFloored(
                track.lobby.pos().x(), track.lobby.pos().y(), track.lobby.pos().z()), track.lobby.yaw());
    }

    // ----------------------------------------------------------- состояние

    void publish(ServerPlayerEntity player, Pilot pilot) {
        lastStatus = status(player, pilot);
    }

    /** Состояние заезда этого игрока (для программы и проверок). */
    public SkyStatus statusFor(ServerPlayerEntity player) {
        Pilot p = pilots.get(player.getUuid());
        return p == null ? statusWithout(ready() ? "ready" : "preparing") : status(player, p);
    }

    SkyStatus status(ServerPlayerEntity player, Pilot pilot) {
        SkyRun run = pilot.run;
        return new SkyStatus(ready() ? "ready" : "preparing", run.phase().name().toLowerCase(Locale.ROOT),
                pilot.training, Math.min(run.sector() + 1, run.track.sectors.size()), run.track.sectors.size(),
                run.ringInSector(), run.ringsInSector(), run.nextRing(), run.track.ringCount(), run.ticks() * 50,
                run.errors(), run.misses(), run.crashes(), pilot.training ? 0 : state.best(player.getUuid()) * 50,
                run.countdownSeconds(), run.protection() > 0, pilot.effects.status(), pilot.effects.queued(), problem);
    }

    SkyStatus statusWithout(String map) {
        int sectors = track == null ? 0 : track.sectors.size();
        int total = track == null ? 0 : track.ringCount();
        return new SkyStatus(map, "idle", false, 0, sectors, 0, 0, 0, total, 0, 0, 0, 0, 0, 0, false, List.of(), 0, problem);
    }

    // ------------------------------------------------------------ действия

    /** Действие зрителя: в очередь эффектов, ответы — в {@code reply} по мере выполнения. */
    public void action(ServerPlayerEntity player, BridgeProtocol.SkyAction a, Consumer<String> reply) {
        if (track == null) {
            reply.accept(BridgeProtocol.skyAck(a.id(), a.action(), "rejected", "в этом мире нет трассы"));
            return;
        }
        Pilot pilot = pilots.get(player.getUuid());
        boolean canRun = pilot != null && pilot.run.active();
        boolean flying = canRun && pilot.run.phase() == SkyRun.Phase.RUNNING && pilot.run.protection() == 0;
        SkyEffects.Request r = new SkyEffects.Request(a.id(), a.action(), a.strength(), a.seconds(), a.cooldown(),
                a.repeat(), a.test() ? "" : a.viewerName(), a.test());
        if (pilot == null) {
            pilot = new Pilot();
            pilot.run = new SkyRun(track);
            SkyEffects.Result res = pilot.effects.submit(r, false, false, null);
            for (SkyEffects.Ack ack : res.acks) {
                reply.accept(BridgeProtocol.skyAck(ack.id(), ack.action(), ack.state(),
                        "rejected".equals(ack.state()) ? "заезд не идёт — нажмите «Старт»" : ack.reason()));
            }
            return;
        }
        listeners.put(a.id(), reply);
        apply(player, pilot, pilot.effects.submit(r, canRun, flying, context(player, pilot)));
        publish(player, pilot);
    }

    SkyEffects.Context context(ServerPlayerEntity player, Pilot pilot) {
        Vec3d v = player.getVelocity();
        Track t = pilot.run.track;
        int n = pilot.run.nextRing();
        return new SkyEffects.Context(body(player), new V3(v.x, v.y, v.z),
                n < t.ringCount() ? t.rings.get(n) : null, n + 1 < t.ringCount() ? t.rings.get(n + 1) : null);
    }

    void apply(ServerPlayerEntity player, Pilot pilot, SkyEffects.Result result) {
        if (result.isEmpty()) return;
        for (SkyEffects.Ack ack : result.acks) {
            Consumer<String> to = listeners.get(ack.id());
            if (to != null) {
                to.accept(BridgeProtocol.skyAck(ack.id(), ack.action(), ack.state(), ack.reason()));
                if ("finished".equals(ack.state()) || "rejected".equals(ack.state())) listeners.remove(ack.id());
            }
        }
        for (SkyEffects.Cue cue : result.cues) {
            switch (cue.type()) {
                case STARTED -> {
                    SkyEffects.Active a = pilot.effects.active().stream().filter(x -> x.kind == cue.kind()).findFirst().orElse(null);
                    String from = a == null || a.viewer.isEmpty() ? "" : "от " + a.viewer;
                    say(player, Text.literal(cue.kind().title).formatted(color(cue.kind()), Formatting.BOLD), from);
                    sound(player, cue.kind().tier == SkyEffects.Tier.EXPENSIVE ? SoundEvents.BLOCK_BEACON_ACTIVATE
                            : SoundEvents.ENTITY_PHANTOM_FLAP, 0.7f, 1.2f);
                }
                case LIGHTNING -> lightning(player, cue.vector());
                case REWIND -> rewind(player, pilot, (int) cue.value());
                case SHIELD_ON -> pilot.run.setShield(true);
                case SHIELD_OFF -> pilot.run.setShield(false);
                case GATE_PASS -> sound(player, SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, 0.9f, 1.6f);
                case GATE_MISS -> handle(player, pilot, List.of(pilot.run.penalty("slalom")));
                default -> {}
            }
        }
        publish(player, pilot);
    }

    static Formatting color(SkyEffects.Kind kind) {
        return switch (kind.tier) {
            case CHEAP -> Formatting.AQUA;
            case MEDIUM -> Formatting.LIGHT_PURPLE;
            case EXPENSIVE -> Formatting.GOLD;
        };
    }

    /** Молния-декорация сбоку (без огня и урона); «меньше вспышек» — только звук. */
    void lightning(ServerPlayerEntity player, V3 gust) {
        sound(player, SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, 0.35f, 1.1f);
        if (SkyConfig.settings.reduceFlashes()) return;
        V3 side = gust == null || gust.lengthSq() == 0 ? new V3(1, 0, 0) : gust.normalize();
        double dist = 24 + world.random.nextInt(12);
        LightningEntity bolt = EntityType.LIGHTNING_BOLT.create(world);
        if (bolt == null) return;
        bolt.setCosmetic(true);
        bolt.refreshPositionAfterTeleport(player.getX() + side.x() * dist, player.getY() - 6, player.getZ() + side.z() * dist);
        world.spawnEntity(bolt);
    }

    /** «Временной разлом»: назад на {@code seconds} секунд полёта, с той же скоростью. */
    void rewind(ServerPlayerEntity player, Pilot pilot, int seconds) {
        int back = seconds * 20;
        if (pilot.history.size() < 20) {
            say(player, Text.literal("Временной разлом").formatted(Formatting.GOLD, Formatting.BOLD), "некуда отматывать");
            return;
        }
        double[] h = null;
        int skip = Math.max(0, pilot.history.size() - back);
        int i = 0;
        for (double[] x : pilot.history) {
            if (i++ == skip) {
                h = x;
                break;
            }
        }
        if (h == null) return;
        V3 vel = new V3(h[3], h[4], h[5]);
        double speed = Math.max(pilot.run.checkpoint().speed(), Math.min(track.speedCap, vel.length()));
        launch(player, pilot, new V3(h[0], h[1], h[2]), vel.length() < 0.1 ? directionOf(player) : vel, speed);
        pilot.history.clear();
        sound(player, SoundEvents.BLOCK_RESPAWN_ANCHOR_DEPLETE.value(), 0.8f, 0.7f);
        say(player, Text.literal("Временной разлом").formatted(Formatting.GOLD, Formatting.BOLD),
                "назад на " + seconds + " с");
    }

    public List<String> journal(ServerPlayerEntity player) {
        Pilot p = pilots.get(player.getUuid());
        return p == null ? List.of() : p.effects.journal();
    }

    // ---------------------------------------------------------- для тестов

    public SkyRun run(ServerPlayerEntity player) {
        Pilot p = pilots.get(player.getUuid());
        return p == null ? null : p.run;
    }

    /** Один тик заезда игрока (в проверках, где нет обычного хода времени). */
    public void tickPlayer(ServerPlayerEntity player) {
        Pilot p = pilots.get(player.getUuid());
        if (p != null) tickPilot(player, p);
    }

    public long now() {
        return tick;
    }
}
