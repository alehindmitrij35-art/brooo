package dev.dirronlive.parkour.map;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Детерминированный генератор комнат «Dirron Parkour: 100 комнат».
 *
 * <p>Маршрут идёт вдоль +X. Ограничения прыжков (проверяются тестами):
 * воздух между краями ≤ 3 блока на той же высоте или вниз, ≤ 2 — на +1 вверх;
 * подъём больше чем на 1 блок — только через батут из слизи.
 */
public final class RoomGenerator {
    private RoomGenerator() {}

    /** Плоскость крупного номера комнаты (смещение по X от начала комнаты). */
    static final int NUMBER_X = 20;

    public static RoomPlan generate(int number, int ox, int oy, int oz) {
        return generate(1, number, ox, oy, oz);
    }

    /** [variant]: 1 — Dirron Parkour (10 тем по 10), 2 — Dirron Parkour 2 (6 локаций по 15 и «Разлом»). */
    public static RoomPlan generate(int variant, int number, int ox, int oy, int oz) {
        if (number < 1 || number > ParkourLayout.ROOMS) {
            throw new IllegalArgumentException("Комната " + number);
        }
        Gen g = new Gen(variant == 2 ? 2 : 1, number, ox, oy, oz);
        if (number == ParkourLayout.ROOMS) {
            g.finalRoom();
        } else {
            g.regularRoom();
        }
        g.clearOverhead();
        return g.finishPlan();
    }

    /** Механики отрезков маршрута. */
    enum Move { JUMP, RING, DESCENT, RUNWAY, BOUNCE, FORK, BEAM, WALKWAY, CLIMB,
        /** Подъём по лестнице на стене. */
        LADDER,
        /** Дорожка из песка душ (ноги вязнут) и прыжок с неё. */
        SOUL_SAND,
        /** Прыжок под низким потолком. */
        HEAD_HITTER,
        /** Прыжок за угол: прямо — стена, цель по диагонали. */
        CORNER,
        /** Цепочка точных прыжков на блок 1×1: вверх, ровно, вниз. */
        CHAIN,
        /** Вертикальный подъём зигзагом по 1×1. */
        TOWER,
        /** Разгон по льду и длинный прыжок через 4 блока. */
        SPRINT,
        /** Развилка: безопасный обход или рискованная срезка по столбикам. */
        RISKY }

    /** Приёмы «Разлома» (91–99). */
    static final Move[] RIFT_MOVES = {Move.CHAIN, Move.TOWER, Move.HEAD_HITTER, Move.SPRINT, Move.SOUL_SAND,
        Move.CORNER, Move.RISKY, Move.BOUNCE, Move.LADDER, Move.CHAIN};

    private static final class Gen {
        final int variant;
        final int number;
        final int ox, oy, oz;
        final Theme theme;
        final Random rnd;
        final double difficulty;
        final double local;
        /** 0 — знакомство с механиками, 1 — точность и цепочки, 2 — подъёмы, разгон, срезки. */
        final int tier;
        final boolean finale;
        final Blueprint bp = new Blueprint();
        final List<Platform> platforms = new ArrayList<>();
        final List<Theme> platformThemes = new ArrayList<>();
        final List<int[]> bridge = new ArrayList<>();
        final List<int[]> shortcut = new ArrayList<>();
        final List<int[]> eyes = new ArrayList<>();
        int bridgeFrom = -1;
        /** Воздух над платформами: сюда декор не ставится. */
        final java.util.Set<Long> reserved = new java.util.HashSet<>();
        /** Блоки окружения (не маршрут) — для проверки, что они не мешают прыжкам. */
        final java.util.Set<Long> decorKeys = new java.util.HashSet<>();
        /** Сейчас ставится окружение (а не стены/потолки маршрута). */
        boolean scenery;
        /** Потолки «прыжка под потолком»: x, y, z, номер платформы, с которой прыгают. */
        final List<int[]> ceilings = new ArrayList<>();

        /**
         * Убрать потолки, которые оказались на пути другого прыжка (маршрут
         * вернулся к этому месту выше или ниже). Путь прыжка — отрезок между
         * ближайшими краями, по высоте от ног до головы.
         */
        void clearForeignCeilings() {
            for (int[] c : ceilings) {
                for (int i = 1; i < platforms.size(); i++) {
                    Platform a = platforms.get(i - 1), b = platforms.get(i);
                    if (a.index() == c[3]) continue;
                    if (onPath(a, b, c[0], c[1], c[2]) || onPath(platforms.get(Math.max(0, i - 2)), b, c[0], c[1], c[2])) {
                        bp.remove(c[0], c[1], c[2]);
                        break;
                    }
                }
            }
        }

        static double clamp(double v, double lo, double hi) {
            return Math.max(lo, Math.min(hi, v));
        }

        static boolean onPath(Platform a, Platform b, int x, int y, int z) {
            int y0 = Math.min(a.y(), b.y()) + 1, y1 = Math.max(a.y(), b.y()) + 2;
            if (y < y0 || y > y1) return false;
            double ax = clamp(b.centerX(), a.x0(), a.x1() + 1), az = clamp(b.centerZ(), a.z0(), a.z1() + 1);
            double bx = clamp(a.centerX(), b.x0(), b.x1() + 1), bz = clamp(a.centerZ(), b.z0(), b.z1() + 1);
            for (int i = 0; i <= 20; i++) {
                double t = i / 20.0;
                if ((int) Math.floor(ax + (bx - ax) * t) == x && (int) Math.floor(az + (bz - az) * t) == z) return true;
            }
            return false;
        }

        Gen(int variant, int number, int ox, int oy, int oz) {
            this.variant = variant;
            this.number = number;
            this.ox = ox;
            this.oy = oy;
            this.oz = oz;
            this.theme = Theme.forRoom(variant, number);
            if (variant == 2) {
                // Своё «зерно»: комнаты не повторяют первую карту.
                this.rnd = new Random(number * 7919L + 104729L + 15_485_863L);
                // Сложность растёт внутри локации (15 комнат) и по всей карте.
                this.local = number > 90 ? (number - 91) / 8.0 : ((number - 1) % Theme.SECOND_SPAN) / 14.0;
                this.difficulty = 0.6 * ((number - 1) / 99.0) + 0.4 * local;
                // Вторая часть сложнее первой: разминка только 5 комнат,
                // средний уровень до 20-й, дальше — самый сложный.
                this.tier = number <= 5 ? 0 : (number <= 20 ? 1 : 2);
                // Последняя комната каждой локации — смесь всех пройденных локаций.
                this.finale = number <= 90 && number % Theme.SECOND_SPAN == 0;
            } else {
                this.rnd = new Random(number * 7919L + 104729L);
                // Сложность растёт и внутри десятки, и по всей карте.
                this.local = ((number - 1) % 10) / 9.0;
                this.difficulty = 0.6 * ((number - 1) / 99.0) + 0.4 * local;
                // Разминка — только первые 20 комнат; последние 80 заметно сложнее.
                this.tier = number <= 20 ? 0 : (number <= 50 ? 1 : 2);
                this.finale = number % 10 == 0;
            }
        }

        Platform last() {
            return platforms.get(platforms.size() - 1);
        }

        // ------------------------------------------------------------ комнаты

        void regularRoom() {
            addPlatform(ox, oz - 2, ox + 4, oz + 2, oy, Platform.Kind.START, theme);
            // Два прямых прыжка в начале каждой комнаты: первая платформа
            // хорошо заметна, а между ними — размеченный разрыв для «Моста».
            jump(theme, 2, 0, 3, Platform.Kind.FIRST);
            jump(theme, 3, 0, sizeFor(), Platform.Kind.NORMAL);
            bridgeFrom = 1;

            if (theme == Theme.AMETHYST && !finale) {
                // Сначала обычные приёмы своего уровня сложности, в конце —
                // спираль вокруг кристальной шахты. У каждой комнаты своя:
                // направление, шаг, радиус и число ступеней.
                int moves = tier == 2 ? 4 + (int) Math.round(local * 2) : 3;
                for (int i = 0; i < moves; i++) move(tierMove(pickMove(theme, i), i), theme);
                spiral(theme, 7 + (int) Math.round(difficulty * 4) + (tier == 2 ? 2 : 0));
            } else {
                int moves = switch (tier) {
                    case 0 -> 5 + (int) Math.round(local);
                    case 1 -> 8 + (int) Math.round(local * 2);
                    default -> 9 + (int) Math.round(local * 3);
                };
                // «Разлом» (91–99): самые длинные комнаты.
                if (theme == Theme.RIFT) moves = 11 + (int) Math.round(local * 3);
                // Вторая часть: комнаты длиннее (ширину всё равно держит клетка).
                if (variant == 2) moves += 3;
                for (int i = 0; i < moves; i++) {
                    // Вторая карта: комната не шире своей клетки (на финиш и края — запас).
                    if (variant == 2 && last().x1() - ox > ParkourLayout.SPACING - 42) break;
                    Theme segmentTheme = !finale ? theme
                            : variant == 2 ? Theme.SECOND[i % Math.max(1, number / Theme.SECOND_SPAN)]
                            : Theme.values()[i % 9];
                    move(tierMove(pickMove(segmentTheme, i), i), segmentTheme);
                }
            }
            finish(theme);
            if (variant == 2) clearForeignCeilings();
            scenery = true;
            themeDecor();
            islands();
            scenery = false;
            number(theme);
        }

        /** Верх воды океана (мир — тёплый океан, вода до y=79). */
        static final int SEA_TOP = 79;

        /** Тематическое окружение в океане по обе стороны трассы. */
        void islands() {
            int minX = Integer.MAX_VALUE, maxX = Integer.MIN_VALUE;
            for (Platform p : platforms) {
                minX = Math.min(minX, p.x0());
                maxX = Math.max(maxX, p.x1());
            }
            int count = 3 + rnd.nextInt(2);
            for (int i = 0; i < count; i++) {
                int r = 3 + rnd.nextInt(2);
                // Внутри длины трассы с запасом на радиус: комната не шире своей клетки.
                int lo = minX + r + 2, hi = Math.max(lo, maxX - r - 3);
                int x = lo + (hi - lo) * i / Math.max(1, count - 1);
                int z = oz + (i % 2 == 0 ? 1 : -1) * (12 + rnd.nextInt(5));
                scenery(x, z, r);
            }
        }

        /** Круглый островок: верх [top], под ним [fill] до воды. */
        void disk(int cx, int cz, int r, int y, String top, String fill) {
            for (int dx = -r; dx <= r; dx++) {
                for (int dz = -r; dz <= r; dz++) {
                    if (Math.sqrt(dx * dx + dz * dz) > r + 0.3) continue;
                    decor(cx + dx, y - 1, cz + dz, fill);
                    decor(cx + dx, y, cz + dz, top);
                }
            }
        }

        /** Холм-конус: от воды вверх, сужаясь. */
        void mound(int cx, int cz, int r, int h, String outer, String inner) {
            for (int k = 0; k < h; k++) {
                int rr = Math.max(0, r - (k * r) / Math.max(1, h));
                for (int dx = -rr; dx <= rr; dx++) {
                    for (int dz = -rr; dz <= rr; dz++) {
                        double d = Math.sqrt(dx * dx + dz * dz);
                        if (d > rr + 0.3) continue;
                        decor(cx + dx, SEA_TOP + k, cz + dz, d > rr - 1 ? outer : inner);
                    }
                }
            }
        }

        void scenery(int x, int z, int r) {
            int y = SEA_TOP + 1;
            switch (theme) {
                case NEON -> {
                    // Небоскрёб из воды: чёрные этажи, неоновые полосы, огни на крыше.
                    int h = 10 + rnd.nextInt(8);
                    String glass = rnd.nextBoolean() ? "minecraft:cyan_stained_glass" : "minecraft:magenta_stained_glass";
                    for (int k = 0; k < h; k++) {
                        for (int dx = 0; dx < 3; dx++) {
                            for (int dz = 0; dz < 3; dz++) {
                                decor(x + dx, SEA_TOP + k, z + dz, k % 3 == 2 ? glass : "minecraft:black_concrete");
                            }
                        }
                    }
                    decor(x + 1, SEA_TOP + h, z + 1, "minecraft:sea_lantern");
                    decor(x + 1, SEA_TOP + h + 1, z + 1, "minecraft:end_rod[facing=up]");
                }
                case CORAL -> {
                    disk(x, z, r, SEA_TOP, "minecraft:sand", "minecraft:sand");
                    String[] coral = {"minecraft:brain_coral_block", "minecraft:tube_coral_block",
                            "minecraft:fire_coral_block", "minecraft:horn_coral_block", "minecraft:bubble_coral_block"};
                    for (int i = 0; i < 6; i++) {
                        int dx = rnd.nextInt(2 * r - 1) - r + 1, dz = rnd.nextInt(2 * r - 1) - r + 1;
                        int h = 1 + rnd.nextInt(3);
                        for (int k = 0; k < h; k++) decor(x + dx, y + k, z + dz, coral[rnd.nextInt(coral.length)]);
                    }
                    decor(x, y, z, "minecraft:sea_pickle[pickles=4,waterlogged=false]");
                }
                case HONEY -> {
                    disk(x, z, r, SEA_TOP, "minecraft:grass_block", "minecraft:dirt");
                    String[] flowers = {"minecraft:dandelion", "minecraft:poppy", "minecraft:cornflower",
                            "minecraft:oxeye_daisy", "minecraft:allium"};
                    for (int dx = -r + 1; dx < r; dx++) {
                        for (int dz = -r + 1; dz < r; dz++) {
                            if (rnd.nextInt(3) == 0) decor(x + dx, y, z + dz, flowers[rnd.nextInt(flowers.length)]);
                        }
                    }
                    for (int k = 0; k < 4; k++) decor(x, y + k, z, "minecraft:oak_log");
                    for (int dx = -2; dx <= 2; dx++) {
                        for (int dz = -2; dz <= 2; dz++) {
                            if (Math.abs(dx) + Math.abs(dz) <= 3) decor(x + dx, y + 4, z + dz, "minecraft:oak_leaves[persistent=true]");
                        }
                    }
                    decor(x, y + 5, z, "minecraft:oak_leaves[persistent=true]");
                    decor(x + 1, y + 2, z, "minecraft:bee_nest[facing=east]");
                }
                case ICE -> {
                    // Айсберг: синий лёд внизу, плотный выше, снежная шапка.
                    int h = 5 + rnd.nextInt(5);
                    mound(x, z, r + 1, h, "minecraft:packed_ice", "minecraft:blue_ice");
                    decor(x, SEA_TOP + h, z, "minecraft:snow_block");
                    decor(x, SEA_TOP + h + 1, z, "minecraft:snow[layers=3]");
                }
                case SLIME -> {
                    disk(x, z, r, SEA_TOP, "minecraft:mud", "minecraft:mud");
                    for (int i = 0; i < 4; i++) {
                        decor(x + rnd.nextInt(3) - 1, y + i / 2, z + rnd.nextInt(3) - 1, "minecraft:slime_block");
                    }
                    decor(x, y + 2, z, "minecraft:verdant_froglight");
                    for (int i = 0; i < 6; i++) {
                        decor(x + rnd.nextInt(2 * r + 5) - r - 2, SEA_TOP + 1, z + r + 1 + rnd.nextInt(3), "minecraft:lily_pad");
                    }
                }
                case RASPBERRY -> {
                    disk(x, z, r, SEA_TOP, "minecraft:grass_block", "minecraft:dirt");
                    for (int dx = -r + 1; dx < r; dx++) {
                        for (int dz = -r + 1; dz < r; dz++) {
                            if (rnd.nextInt(3) == 0) decor(x + dx, y, z + dz, "minecraft:sweet_berry_bush[age=3]");
                        }
                    }
                    // Сакура.
                    for (int k = 0; k < 5; k++) decor(x, y + k, z, "minecraft:cherry_log");
                    for (int dx = -2; dx <= 2; dx++) {
                        for (int dz = -2; dz <= 2; dz++) {
                            for (int dy = 0; dy <= 1; dy++) {
                                if (Math.abs(dx) + Math.abs(dz) + dy <= 3) {
                                    decor(x + dx, y + 5 + dy, z + dz, "minecraft:cherry_leaves[persistent=true]");
                                }
                            }
                        }
                    }
                }
                case FORGE -> {
                    // Вулкан: базальт, жерло из магмы с огоньком.
                    int h = 6 + rnd.nextInt(4);
                    mound(x, z, r + 1, h, "minecraft:basalt", "minecraft:blackstone");
                    decor(x, SEA_TOP + h - 1, z, "minecraft:magma_block");
                    decor(x, SEA_TOP + h, z, "minecraft:shroomlight");
                    decor(x, SEA_TOP + h + 1, z, "minecraft:campfire[lit=true]");
                }
                case AMETHYST -> {
                    int h = 4 + rnd.nextInt(3);
                    mound(x, z, r, h, "minecraft:calcite", "minecraft:smooth_basalt");
                    for (int i = 0; i < 4; i++) {
                        int dx = rnd.nextInt(3) - 1, dz = rnd.nextInt(3) - 1;
                        decor(x + dx, SEA_TOP + h, z + dz, "minecraft:amethyst_block");
                        decor(x + dx, SEA_TOP + h + 1, z + dz, "minecraft:amethyst_cluster[facing=up]");
                    }
                }
                case CARNIVAL -> {
                    // Праздничный плот с полосатым шатром.
                    for (int dx = -2; dx <= 2; dx++) {
                        for (int dz = -2; dz <= 2; dz++) decor(x + dx, y, z + dz, "minecraft:spruce_planks");
                    }
                    String a = rnd.nextBoolean() ? "minecraft:red_wool" : "minecraft:blue_wool";
                    for (int k = 0; k < 3; k++) {
                        int rr = 2 - k;
                        for (int dx = -rr; dx <= rr; dx++) {
                            for (int dz = -rr; dz <= rr; dz++) {
                                if (Math.abs(dx) == rr || Math.abs(dz) == rr) {
                                    decor(x + dx, y + 1 + k * 2, z + dz, (dx + dz) % 2 == 0 ? a : "minecraft:white_wool");
                                    decor(x + dx, y + 2 + k * 2, z + dz, (dx + dz) % 2 == 0 ? "minecraft:white_wool" : a);
                                }
                            }
                        }
                    }
                    decor(x, y + 7, z, "minecraft:yellow_wool");
                    decor(x + 2, y + 1, z + 2, "minecraft:lantern");
                }
                case ARENA -> {
                    // Колонна стадиона с прожектором.
                    int h = 9 + rnd.nextInt(5);
                    for (int k = 0; k < h; k++) {
                        String block = (k / 2) % 2 == 0 ? "minecraft:purple_concrete" : "minecraft:lime_concrete";
                        decor(x, SEA_TOP + k, z, block);
                        decor(x + 1, SEA_TOP + k, z, block);
                    }
                    decor(x, SEA_TOP + h, z, "minecraft:sea_lantern");
                    decor(x + 1, SEA_TOP + h, z, "minecraft:sea_lantern");
                }
                // ---- Dirron Parkour 2: окружение локаций (низко над водой, в стороне от трассы).
                case FOREST -> {
                    disk(x, z, r, SEA_TOP, "minecraft:grass_block", "minecraft:dirt");
                    int h = 5 + rnd.nextInt(3);
                    for (int k = 1; k <= h; k++) decor(x, SEA_TOP + k, z, "minecraft:oak_log");
                    for (int dx = -2; dx <= 2; dx++)
                        for (int dz = -2; dz <= 2; dz++)
                            for (int dy = -1; dy <= 1; dy++)
                                if (Math.abs(dx) + Math.abs(dz) + Math.abs(dy) <= 3)
                                    decor(x + dx, SEA_TOP + h + dy, z + dz, "minecraft:oak_leaves[persistent=true]");
                    decor(x + r - 1, SEA_TOP + 1, z, "minecraft:red_mushroom");
                    decor(x - r + 1, SEA_TOP + 1, z, "minecraft:fern");
                    decor(x, SEA_TOP + 1, z + r - 1, "minecraft:lily_of_the_valley");
                }
                case MOUNTAIN -> {
                    shell(x, z, r + 1, 8 + rnd.nextInt(3), "minecraft:stone", "minecraft:stone", 0);
                    decor(x, SEA_TOP + 9, z, "minecraft:snow_block");
                    for (int dx = -1; dx <= 1; dx++)
                        for (int dz = -1; dz <= 1; dz++) decor(x + dx, SEA_TOP + 8, z + dz, "minecraft:snow_block");
                    decor(x + r, SEA_TOP, z, "minecraft:spruce_log");
                    decor(x + r, SEA_TOP + 1, z, "minecraft:spruce_leaves[persistent=true]");
                }
                case DESERT -> {
                    disk(x, z, r, SEA_TOP, "minecraft:sand", "minecraft:sandstone");
                    // Маленькая пирамида.
                    for (int k = 0; k < 4; k++)
                        for (int dx = -3 + k; dx <= 3 - k; dx++)
                            for (int dz = -3 + k; dz <= 3 - k; dz++)
                                decor(x + dx, SEA_TOP + 1 + k, z + dz, k == 3 ? "minecraft:gold_block" : "minecraft:smooth_sandstone");
                    decor(x + r, SEA_TOP + 1, z + 1, "minecraft:cactus");
                    decor(x + r, SEA_TOP + 2, z + 1, "minecraft:cactus");
                }
                case REEF -> {
                    disk(x, z, r, SEA_TOP, "minecraft:sand", "minecraft:sand");
                    String[] coral = {"minecraft:tube_coral_block", "minecraft:brain_coral_block",
                            "minecraft:bubble_coral_block", "minecraft:horn_coral_block"};
                    for (int i = 0; i < 7; i++) {
                        int dx = rnd.nextInt(2 * r - 1) - r + 1, dz = rnd.nextInt(2 * r - 1) - r + 1;
                        int h = 1 + rnd.nextInt(4);
                        for (int k = 0; k < h; k++) decor(x + dx, y + k, z + dz, coral[rnd.nextInt(coral.length)]);
                    }
                    decor(x, y, z, "minecraft:sea_lantern");
                    decor(x, y + 1, z, "minecraft:sea_pickle[pickles=4,waterlogged=false]");
                }
                case NETHER -> {
                    mound(x, z, r, 4 + rnd.nextInt(2), "minecraft:netherrack", "minecraft:netherrack");
                    int h = 4 + rnd.nextInt(5);
                    for (int k = 0; k < h; k++) decor(x + r, SEA_TOP + k, z, "minecraft:basalt[axis=y]");
                    decor(x, SEA_TOP + 5, z, "minecraft:glowstone");
                    decor(x - 1, SEA_TOP + 1, z + 1, "minecraft:crimson_fungus");
                    decor(x + 1, SEA_TOP + 1, z - 1, "minecraft:crimson_roots");
                }
                case END_ISLES -> {
                    disk(x, z, r, SEA_TOP, "minecraft:end_stone", "minecraft:end_stone");
                    int h = 6 + rnd.nextInt(4);
                    for (int k = 1; k <= h; k++) decor(x, SEA_TOP + k, z, "minecraft:obsidian");
                    decor(x, SEA_TOP + h + 1, z, "minecraft:end_rod[facing=up]");
                    decor(x + r - 1, SEA_TOP + 1, z, "minecraft:purpur_pillar");
                    decor(x + r - 1, SEA_TOP + 2, z, "minecraft:end_rod[facing=up]");
                }
                case RIFT -> {
                    mound(x, z, r, 5, "minecraft:obsidian", "minecraft:crying_obsidian");
                    decor(x, SEA_TOP + 5, z, "minecraft:amethyst_block");
                    decor(x, SEA_TOP + 6, z, "minecraft:amethyst_cluster[facing=up]");
                    decor(x + r, SEA_TOP + 1, z, "minecraft:purple_stained_glass");
                    decor(x + r, SEA_TOP + 2, z, "minecraft:purple_stained_glass");
                }
                default -> island(x, z, r);
            }
        }

        void island(int cx, int cz, int r) {
            for (int dx = -r; dx <= r; dx++) {
                for (int dz = -r; dz <= r; dz++) {
                    double d = Math.sqrt(dx * dx + dz * dz);
                    if (d > r + 0.3) continue;
                    decor(cx + dx, SEA_TOP, cz + dz, "minecraft:sand");
                    if (d < r - 1) decor(cx + dx, SEA_TOP + 1, cz + dz, d < 1.2 ? "minecraft:sand" : "minecraft:sandstone");
                }
            }
            // Пальма: изогнутый ствол и крона из листьев джунглей.
            int h = 5 + rnd.nextInt(3);
            int tx = cx, tz = cz;
            for (int k = 1; k <= h; k++) {
                if (k == h / 2) tx += 1;
                decor(tx, SEA_TOP + 1 + k, tz, "minecraft:jungle_log");
            }
            int top = SEA_TOP + 1 + h;
            decor(tx, top + 1, tz, "minecraft:jungle_leaves[persistent=true]");
            for (int[] d : new int[][] {{1, 0}, {-1, 0}, {0, 1}, {0, -1}}) {
                for (int k = 1; k <= 3; k++) {
                    decor(tx + d[0] * k, top - (k == 3 ? 1 : 0), tz + d[1] * k, "minecraft:jungle_leaves[persistent=true]");
                }
            }
            decor(tx, top - 1, tz + 1, "minecraft:cocoa[facing=north,age=2]");
            decor(cx - r + 1, SEA_TOP + 2, cz, "minecraft:lantern");
        }

        Move pickMove(Theme t, int i) {
            boolean even = i % 2 == 0;
            return switch (t) {
                case NEON -> even ? Move.JUMP : Move.RING;
                case CORAL -> even ? Move.RING : Move.JUMP;
                case HONEY -> i % 3 == 1 ? Move.DESCENT : (i % 3 == 2 ? Move.CLIMB : Move.JUMP);
                case ICE -> even ? Move.RUNWAY : Move.JUMP;
                case SLIME -> even ? Move.BOUNCE : Move.CLIMB;
                case RASPBERRY -> i % 4 == 1 ? Move.FORK : Move.JUMP;
                case FORGE -> even ? Move.BEAM : Move.JUMP;
                case AMETHYST -> switch ((i + number) % 4) {
                    case 0 -> Move.CLIMB;
                    case 1 -> Move.JUMP;
                    case 2 -> Move.CORNER;
                    default -> Move.DESCENT;
                };
                case CARNIVAL -> i % 3 == 0 ? Move.WALKWAY : (i % 3 == 1 ? Move.RING : Move.JUMP);
                case ARENA -> Move.values()[(i * 5 + number) % Move.values().length];
                // Вторая карта: у каждой локации свой набор приёмов.
                case FOREST -> switch ((i + number) % 4) {
                    case 0 -> Move.JUMP;
                    case 1 -> Move.LADDER;
                    case 2 -> Move.DESCENT;
                    default -> Move.CORNER;
                };
                case MOUNTAIN -> switch ((i + number) % 4) {
                    case 0 -> Move.CLIMB;
                    case 1 -> Move.RUNWAY;
                    case 2 -> Move.JUMP;
                    default -> Move.TOWER;
                };
                case DESERT -> switch ((i + number) % 4) {
                    case 0 -> Move.SOUL_SAND;
                    case 1 -> Move.JUMP;
                    case 2 -> Move.BEAM;
                    default -> Move.CHAIN;
                };
                case REEF -> switch ((i + number) % 4) {
                    case 0 -> Move.RING;
                    case 1 -> Move.BOUNCE;
                    case 2 -> Move.SPRINT;
                    default -> Move.JUMP;
                };
                case NETHER -> switch ((i + number) % 5) {
                    case 0 -> Move.SOUL_SAND;
                    case 1 -> Move.HEAD_HITTER;
                    case 2 -> Move.BEAM;
                    case 3 -> Move.CHAIN;
                    default -> Move.CORNER;
                };
                case END_ISLES -> switch ((i + number) % 5) {
                    case 0 -> Move.CHAIN;
                    case 1 -> Move.TOWER;
                    case 2 -> Move.CORNER;
                    case 3 -> Move.RISKY;
                    default -> Move.SPRINT;
                };
                // «Разлом»: только трудные приёмы, по кругу, у каждой комнаты свой порядок.
                case RIFT -> RIFT_MOVES[(i + number * 3) % RIFT_MOVES.length];
                // Финал во тьме: самые трудные приёмы, свой порядок.
                case DOOM -> RIFT_MOVES[(i * 3 + 5) % RIFT_MOVES.length];
            };
        }

        /** Средние и последние комнаты получают новые приёмы поверх темы. */
        Move tierMove(Move base, int i) {
            if (tier == 1 && i % 3 == 2) {
                return switch ((i / 3 + number) % 4) {
                    case 0 -> Move.CORNER;
                    case 1 -> Move.LADDER;
                    case 2 -> Move.SOUL_SAND;
                    default -> Move.CHAIN;
                };
            }
            if (tier == 2 && i % 3 == 1) {
                return switch ((i / 3 + number) % 7) {
                    case 0 -> Move.TOWER;
                    case 1 -> Move.SPRINT;
                    case 2 -> Move.RISKY;
                    case 3 -> Move.LADDER;
                    case 4 -> Move.HEAD_HITTER;
                    case 5 -> Move.SOUL_SAND;
                    default -> Move.CHAIN;
                };
            }
            if (tier == 2 && i % 3 == 0 && i > 0) return (i / 3 + number) % 2 == 0 ? Move.HEAD_HITTER : Move.CORNER;
            if (tier == 2 && i % 3 == 2 && base == Move.JUMP) return Move.CORNER;
            if (tier == 0 && (base == Move.BEAM || base == Move.FORK)) return Move.JUMP; // без сложного в начале
            return base;
        }

        void move(Move move, Theme t) {
            // Вторая карта: развилку заменяет рискованная срезка (у развилки одна
            // ветка могла оказаться тупиком), медовая стенка у спуска не ставится.
            if (variant == 2 && move == Move.FORK) move = Move.RISKY;
            switch (move) {
                case JUMP -> jump(t, gapFor(), dyFor(), sizeFor(), Platform.Kind.NORMAL);
                case CLIMB -> jump(t, Math.min(2, gapFor()), 1, sizeFor(), Platform.Kind.NORMAL);
                case RING -> {
                    Platform from = last();
                    Platform to = jump(t, Math.max(2, gapFor()), 0, sizeFor(), Platform.Kind.NORMAL);
                    ring(from, to, t);
                }
                case DESCENT -> {
                    Platform to = jump(t, Math.min(2, gapFor()), -2, Math.max(2, sizeFor()), Platform.Kind.NORMAL);
                    if (variant == 1) honeySlide(to);
                }
                case RUNWAY -> runway(t);
                case BOUNCE -> bounce(t);
                case FORK -> fork(t);
                case BEAM -> beam(t, false);
                case WALKWAY -> beam(t, true);
                case CORNER -> corner(t);
                case CHAIN -> chain(t);
                case TOWER -> tower(t);
                case SPRINT -> sprint(t);
                case RISKY -> risky(t);
                case LADDER -> ladder(t);
                case SOUL_SAND -> soulSand(t);
                case HEAD_HITTER -> headHitter(t);
            }
        }

        /** Лестница: подъём по стене на 3–4 блока на верхнюю площадку. */
        void ladder(Theme t) {
            Platform from = last();
            int h = 3 + (tier == 2 ? 1 : 0);
            int cz = (int) Math.floor(from.centerZ());
            int wallX = from.x1() + 2;
            for (int k = 1; k <= h; k++) {
                bp.set(from.x1() + 1, from.y() + k, cz, "minecraft:ladder[facing=west]");
                reserved.add(Blueprint.key(from.x1() + 1, from.y() + k, cz));
                if (k < h) decor(wallX, from.y() + k, cz, t.edge);
            }
            addPlatform(wallX, cz - 1, wallX + 2, cz + 1, from.y() + h, Platform.Kind.NORMAL, t);
        }

        /** Песок душ: дорожка, на которой ноги вязнут, и прыжок с неё. */
        void soulSand(Theme t) {
            Platform from = last();
            int cz = (int) Math.floor(from.centerZ());
            Platform strip = addPlatform(from.x1() + 2, cz, from.x1() + 5, cz, from.y(), Platform.Kind.RUNWAY, t);
            for (int x = strip.x0(); x <= strip.x1(); x++) bp.set(x, strip.y(), cz, "minecraft:soul_sand");
            jump(t, 2, 0, tier == 2 ? 1 : 2, Platform.Kind.NORMAL);
        }

        /** Прыжок с потолком: над краем — блок, прыгать надо низко и точно. */
        void headHitter(Theme t) {
            Platform from = last();
            for (int z = from.z0(); z <= from.z1(); z++) {
                // Вторая карта: потолок ставится по-настоящему (над платформой воздух держится
                // только на 2 блока — прыжок низкий, но голова проходит).
                if (variant == 2) {
                    bp.set(from.x1(), from.y() + 3, z, t.edge);
                    ceilings.add(new int[] {from.x1(), from.y() + 3, z, from.index()});
                }
                else decor(from.x1(), from.y() + 3, z, t.edge);
            }
            jump(t, 2, 0, sizeFor(), Platform.Kind.NORMAL);
        }

        /** Прыжок за угол: прямо по ходу стоит стена, следующая платформа — по диагонали. */
        void corner(Theme t) {
            Platform from = last();
            int cz = (int) Math.floor(from.centerZ());
            int side = cz <= oz ? 1 : -1;
            int size = tier == 2 ? 1 : 2;
            int x0 = from.x1() + 3;
            int z0 = side > 0 ? from.z1() + (tier == 2 ? 3 : 2) : from.z0() - (tier == 2 ? 3 : 2) - (size - 1);
            z0 = Math.max(oz - 8, Math.min(oz + 8 - (size - 1), z0));
            Platform target = addPlatform(x0, z0, x0 + size - 1, z0 + size - 1, from.y(), Platform.Kind.NORMAL, t);
            // Стена там, куда прыгнул бы игрок напрямую: от края платформы и дальше.
            int wz0 = side > 0 ? from.z0() - 1 : from.z1() + 1;
            int wz1 = side > 0 ? from.z1() : from.z0();
            for (int x = from.x1() + 3; x <= target.x1(); x++) {
                for (int z = Math.min(wz0, wz1); z <= Math.max(wz0, wz1); z++) {
                    for (int y = from.y(); y <= from.y() + 3; y++) decor(x, y, z, t.edge);
                }
            }
            // Выход из угла дальше по ходу.
            jump(t, gapFor() - 1 < 1 ? 1 : gapFor() - 1, 0, sizeFor() + 1, Platform.Kind.NORMAL);
        }

        /** Цепочка из трёх точных прыжков на 1×1: вверх, ровно, вниз. */
        void chain(Theme t) {
            jump(t, 2, 1, 1, Platform.Kind.NORMAL);
            jump(t, tier == 2 ? 3 : 2, 0, 1, Platform.Kind.NORMAL);
            jump(t, 2, -1, tier == 2 ? 1 : 2, Platform.Kind.NORMAL);
        }

        /** Вертикальный подъём зигзагом: 4–6 ступеней +1 на блоках 1×1. */
        void tower(Theme t) {
            int steps = 4 + (int) Math.round(local * 2);
            Platform from = last();
            int y = from.y();
            int x = from.x1() + 2;
            int z = (int) Math.floor(from.centerZ());
            for (int i = 0; i < steps; i++) {
                int dz = (i % 2 == 0) ? 2 : -2;
                int nz = Math.max(oz - 8, Math.min(oz + 8, z + dz));
                y += 1;
                Platform step = addPlatform(x, nz, x, nz, y, Platform.Kind.NORMAL, t);
                // Колонна под ступенью — видно, что это башня.
                for (int yy = y - 1; yy >= y - 3; yy--) decor(step.x0(), yy - 1, step.z0(), t.edge);
                x += 2;
                z = nz;
            }
            jump(t, 2, 0, 2, Platform.Kind.NORMAL);
        }

        /** Разгон по синему льду и прыжок через 4 блока воздуха. */
        void sprint(Theme t) {
            Platform from = last();
            int length = 6 + rnd.nextInt(2);
            int x0 = from.x1() + 2;
            int cz = (int) Math.floor(from.centerZ());
            Platform runway = addPlatform(x0, cz - 1, x0 + length - 1, cz, from.y(), Platform.Kind.RUNWAY, t);
            for (int x = runway.x0(); x <= runway.x1(); x += 2) {
                decor(x, runway.y() + 4, runway.z0() - 1, "minecraft:sea_lantern");
                decor(x, runway.y() + 4, runway.z1() + 1, "minecraft:sea_lantern");
            }
            jump(t, 4, 0, 2, Platform.Kind.NORMAL);
        }

        /**
         * Развилка: безопасный обход из трёх платформ дугой или рискованная
         * срезка напрямую по двум столбикам 1×1 с прыжками на 3 блока.
         */
        void risky(Theme t) {
            Platform from = last();
            int cz = (int) Math.floor(from.centerZ());
            int side = cz <= oz ? 1 : -1;
            int y = from.y();
            // Обход (основной маршрут): две платформы 2×2 дугой в сторону.
            int az0 = side > 0 ? from.z1() + 3 : from.z0() - 4;
            Platform a = addPlatform(from.x1() + 3, az0, from.x1() + 4, az0 + 1, y, Platform.Kind.NORMAL, t);
            Platform b = addPlatform(a.x1() + 3, a.z0() + side * 2, a.x1() + 4, a.z1() + side * 2,
                    y, Platform.Kind.NORMAL, t);
            // Срезка: два столбика 1×1 по прямой, прыжки по 3 блока.
            Platform s1 = addPlatform(from.x1() + 4, cz, from.x1() + 4, cz, y, Platform.Kind.NORMAL, t);
            Platform s2 = addPlatform(s1.x1() + 4, cz, s1.x1() + 4, cz, y, Platform.Kind.NORMAL, t);
            for (Platform pillar : List.of(s1, s2)) {
                for (int yy = y - 2; yy >= y - 5; yy--) decor(pillar.x0(), yy, pillar.z0(), "minecraft:red_concrete");
            }
            // Слияние: площадка, на которую ведут и обход, и срезка.
            int mergeX = b.x1() + 4;
            int z0 = Math.min(Math.min(cz, b.z0()), from.z0());
            int z1 = Math.max(Math.max(cz, b.z1()), from.z1());
            addPlatform(mergeX, z0, mergeX + 1, z1, y, Platform.Kind.NORMAL, t);
        }

        int gapFor() {
            if (variant == 2) {
                // Вторая часть: прыжки шире, в конце — всегда 3 блока воздуха.
                return switch (tier) {
                    case 0 -> 2;
                    case 1 -> rnd.nextInt(3) == 0 ? 2 : 3;
                    default -> 3;
                };
            }
            return switch (tier) {
                case 0 -> 1 + rnd.nextInt(2);
                case 1 -> 2 + rnd.nextInt(2);
                default -> rnd.nextInt(4) == 0 ? 2 : 3;
            };
        }

        int dyFor() {
            if (variant == 2 && tier == 2) {
                // Вторая часть: чаще прыжок вверх на +1 (на 1×1 — самый трудный).
                return switch (rnd.nextInt(5)) {
                    case 0, 1 -> 1;
                    case 2 -> -1;
                    default -> 0;
                };
            }
            int r = rnd.nextInt(tier == 0 ? 8 : (tier == 1 ? 6 : 5));
            return switch (r) {
                case 0 -> 1;
                case 1 -> tier == 0 ? 0 : -1;
                case 2 -> tier == 2 ? 1 : 0;
                default -> 0;
            };
        }

        int sizeFor() {
            if (variant == 2) {
                // Вторая часть: точных приземлений на 1×1 заметно больше.
                return switch (tier) {
                    case 0 -> 3;
                    case 1 -> rnd.nextBoolean() ? 2 : 1;
                    default -> rnd.nextInt(6) == 0 ? 2 : 1;
                };
            }
            return switch (tier) {
                case 0 -> 3;
                case 1 -> local < 0.4 ? 2 : (rnd.nextBoolean() ? 2 : 1);
                default -> rnd.nextInt(3) == 0 ? 2 : 1;
            };
        }

        /** Следующая платформа на расстоянии {@code gap} блоков воздуха по X. */
        Platform jump(Theme t, int gap, int dy, int size, Platform.Kind kind) {
            Platform from = last();
            if (dy > 0) gap = Math.min(gap, 2);
            int y = from.y() + dy;
            int x0 = from.x1() + 1 + gap;
            int x1 = x0 + size - 1;
            int shift = rnd.nextInt(5) - 2;
            int cz = (int) Math.floor(from.centerZ()) + shift;
            cz = Math.max(oz - 7, Math.min(oz + 7, cz));
            int z0 = cz - (size - 1) / 2;
            int z1 = z0 + size - 1;
            // Боковое смещение не должно удлинять прыжок сверх допустимого.
            Platform candidate = new Platform(platforms.size(), x0, z0, x1, z1, y, kind);
            double limit = dy > 0 ? 2.25 : 3.2;
            while (from.airGapTo(candidate) > limit && z0 != (int) Math.floor(from.centerZ()) - (size - 1) / 2) {
                int dir = z0 > from.z0() ? -1 : 1;
                z0 += dir;
                z1 += dir;
                candidate = new Platform(platforms.size(), x0, z0, x1, z1, y, kind);
            }
            return addPlatform(x0, z0, x1, z1, y, kind, t);
        }

        /** Ледяная аркада: длинная дорожка из синего льда для разгона. */
        void runway(Theme t) {
            Platform from = last();
            int length = 5 + rnd.nextInt(3);
            int x0 = from.x1() + 1 + Math.min(2, gapFor());
            int cz = (int) Math.floor(from.centerZ());
            Platform runway = addPlatform(x0, cz - 1, x0 + length - 1, cz, from.y(), Platform.Kind.RUNWAY, t);
            // Арки аркады над дорожкой.
            for (int x = runway.x0(); x <= runway.x1(); x += 3) {
                for (int z = runway.z0() - 1; z <= runway.z1() + 1; z++) {
                    decor(x, runway.y() + 4, z, "minecraft:magenta_stained_glass");
                }
                decor(x, runway.y() + 1, runway.z0() - 2, "minecraft:magenta_stained_glass");
                decor(x, runway.y() + 2, runway.z0() - 2, "minecraft:magenta_stained_glass");
                decor(x, runway.y() + 3, runway.z0() - 2, "minecraft:sea_lantern");
                decor(x, runway.y() + 1, runway.z1() + 2, "minecraft:magenta_stained_glass");
                decor(x, runway.y() + 2, runway.z1() + 2, "minecraft:magenta_stained_glass");
                decor(x, runway.y() + 3, runway.z1() + 2, "minecraft:sea_lantern");
            }
            // Точное торможение: широкая площадка после прыжка с разгона.
            jump(t, 3, 0, 3, Platform.Kind.NORMAL);
        }

        /** Слайм-батут: спрыгнуть на слизь на 3 ниже и отскочить на площадку. */
        void bounce(Theme t) {
            Platform from = last();
            int x0 = from.x1() + 2;
            int cz = (int) Math.floor(from.centerZ());
            addPlatform(x0, cz - 1, x0 + 2, cz + 1, from.y() - 3, Platform.Kind.BOUNCE, t);
            Platform pad = last();
            int lx0 = pad.x1() + 3;
            addPlatform(lx0, cz - 1, lx0 + 1, cz, from.y() - 1, Platform.Kind.NORMAL, t);
            // Стеклянная стенка лаборатории за батутом.
            for (int y = pad.y() - 1; y <= pad.y() + 1; y++) {
                for (int z = pad.z0() - 1; z <= pad.z1() + 1; z++) {
                    decor(pad.x0() - 1, y - 1, z, "minecraft:lime_stained_glass");
                }
            }
        }

        /** Малиновые сады: развилка на два пути, которые сходятся. */
        void fork(Theme t) {
            Platform from = last();
            int cz = (int) Math.floor(from.centerZ());
            int y = from.y();
            int baseX = from.x1() + 3;
            // Левая ветка (в сторону -Z) и правая (+Z): по две платформы.
            Platform l1 = addPlatform(baseX, cz - 4, baseX + 1, cz - 3, y, Platform.Kind.NORMAL, t);
            Platform r1 = addPlatform(baseX, cz + 3, baseX + 1, cz + 4, y + 1, Platform.Kind.NORMAL, t);
            Platform l2 = addPlatform(l1.x1() + 3, cz - 4, l1.x1() + 4, cz - 3, y, Platform.Kind.NORMAL, t);
            Platform r2 = addPlatform(r1.x1() + 3, cz + 3, r1.x1() + 4, cz + 4, y + 1, Platform.Kind.NORMAL, t);
            // Слияние.
            int mx0 = Math.max(l2.x1(), r2.x1()) + 3;
            addPlatform(mx0, cz - 1, mx0 + 2, cz + 1, y, Platform.Kind.NORMAL, t);
            // Цветущие арки над ветками.
            arch(l1, "minecraft:flowering_azalea_leaves[persistent=true]");
            arch(r2, "minecraft:cherry_leaves[persistent=true]");
        }

        void arch(Platform p, String leaves) {
            int top = p.y() + 5;
            for (int z = p.z0() - 1; z <= p.z1() + 1; z++) {
                decor((int) Math.floor(p.centerX()), top, z, leaves);
            }
            for (int y = p.y() + 1; y < top; y++) {
                decor((int) Math.floor(p.centerX()), y, p.z0() - 1, "minecraft:cherry_log");
                decor((int) Math.floor(p.centerX()), y, p.z1() + 1, "minecraft:cherry_log");
            }
        }

        /** Огненная кузница: узкая медная балка (или подвесная дорожка карнавала). */
        void beam(Theme t, boolean suspended) {
            Platform from = last();
            int length = 4 + rnd.nextInt(3);
            int x0 = from.x1() + 1 + Math.min(2, gapFor());
            int z = (int) Math.floor(from.centerZ());
            Platform beam = addPlatform(x0, z, x0 + length - 1, z, from.y(), Platform.Kind.BEAM, t);
            if (suspended) {
                for (int x : new int[] {beam.x0(), beam.x1()}) {
                    for (int y = beam.y() + 3; y <= beam.y() + 6; y++) {
                        decor(x, y, z - 1, "minecraft:chain[axis=y]");
                        decor(x, y, z + 1, "minecraft:chain[axis=y]");
                    }
                    for (int dz = -1; dz <= 1; dz++) {
                        decor(x, beam.y() + 7, z + dz, "minecraft:red_concrete");
                    }
                }
            } else {
                for (int x = beam.x0(); x <= beam.x1(); x += 2) {
                    decor(x, beam.y() - 3, z, "minecraft:furnace[lit=true,facing=north]");
                    decor(x, beam.y() - 4, z, "minecraft:magma_block");
                }
            }
            jump(t, 2, 0, Math.max(2, sizeFor()), Platform.Kind.NORMAL);
        }

        /** Аметистовые пещеры: подъём по спирали вокруг центральной шахты. */
        void spiral(Theme t, int steps) {
            Platform from = last();
            double cx = Math.max(from.x1() + 8, ox + 30);
            double cz = oz;
            // Ступени достаточно близко, чтобы каждая была выше прошлой на 1:
            // за виток спираль поднимается на 6–8 блоков — над головой свободно.
            double radius = 4.0 + (number % 2) * 0.5;
            double angle = Math.PI; // начинаем с ближней к старту стороны
            int turn = (number % 2 == 0 ? 1 : -1) * (44 + (number * 7) % 11);
            // Подход к шахте: ступени, пока до первой точки спирали не останется прыжок.
            approach((int) Math.round(cx + Math.cos(angle) * radius) - 1,
                    (int) Math.round(cz + Math.sin(angle) * radius) - 1, t);
            int y = last().y();
            for (int i = 0; i < steps; i++) {
                int px = (int) Math.round(cx + Math.cos(angle) * radius) - 1;
                int pz = (int) Math.round(cz + Math.sin(angle) * radius) - 1;
                Platform previous = last();
                Platform next = new Platform(platforms.size(), px, pz, px + 1, pz + 1, y + 1, Platform.Kind.NORMAL);
                if (previous.airGapTo(next) > 2.25 || i == 0) {
                    // Первая ступень — с подходом: на той же высоте, если далеко.
                    next = new Platform(platforms.size(), px, pz, px + 1, pz + 1,
                            previous.airGapTo(next) > 2.25 ? y : y + 1, Platform.Kind.NORMAL);
                }
                addPlatform(next.x0(), next.z0(), next.x1(), next.z1(), next.y(), Platform.Kind.NORMAL, t);
                y = next.y();
                angle += Math.toRadians(turn);
            }
            // Центральная шахта из кристаллов.
            int top = y + 6;
            for (int yy = from.y() - 6; yy <= top; yy++) {
                for (int dx = -1; dx <= 1; dx++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        boolean core = dx == 0 && dz == 0;
                        decor((int) cx + dx, yy, (int) cz + dz,
                                core ? "minecraft:pearlescent_froglight"
                                        : (yy % 3 == 0 ? "minecraft:tinted_glass" : "minecraft:amethyst_block"));
                    }
                }
            }
        }

        /** Ступени 2×2 по прямой к точке (tx, tz) на той же высоте (воздух ≤ 2). */
        void approach(int tx, int tz, Theme t) {
            for (int guard = 0; guard < 20; guard++) {
                Platform from = last();
                Platform target = new Platform(-1, tx, tz, tx + 1, tz + 1, from.y(), Platform.Kind.NORMAL);
                if (from.airGapTo(target) <= 2.5) return;
                double dx = target.centerX() - from.centerX();
                double dz = target.centerZ() - from.centerZ();
                double len = Math.hypot(dx, dz);
                double reach = Math.min(len, 4.0);
                int nx = (int) Math.round(from.centerX() + dx / len * reach) - 1;
                int nz = (int) Math.round(from.centerZ() + dz / len * reach) - 1;
                Platform next = new Platform(-1, nx, nz, nx + 1, nz + 1, from.y(), Platform.Kind.NORMAL);
                while (from.airGapTo(next) > 2.2 && reach > 2.5) {
                    reach -= 0.5;
                    nx = (int) Math.round(from.centerX() + dx / len * reach) - 1;
                    nz = (int) Math.round(from.centerZ() + dz / len * reach) - 1;
                    next = new Platform(-1, nx, nz, nx + 1, nz + 1, from.y(), Platform.Kind.NORMAL);
                }
                // Ступень не должна налезать на цель (иначе над ней окажется ступень спирали).
                if (next.airGapTo(target) < 1.0) {
                    if (from.airGapTo(target) <= 3.2) return;
                    reach = Math.max(2.5, len - 3.5);
                    nx = (int) Math.round(from.centerX() + dx / len * reach) - 1;
                    nz = (int) Math.round(from.centerZ() + dz / len * reach) - 1;
                }
                addPlatform(nx, nz, nx + 1, nz + 1, from.y(), Platform.Kind.NORMAL, t);
            }
        }

        void ring(Platform from, Platform to, Theme t) {
            double midX = (from.x1() + 1 + to.x0()) / 2.0;
            int x = (int) Math.floor(midX);
            double cy = from.y() + 2.5;
            double cz = (from.centerZ() + to.centerZ()) / 2.0;
            String a = t == Theme.CARNIVAL ? "minecraft:red_concrete" : t.accent;
            String b = t == Theme.CARNIVAL ? "minecraft:yellow_concrete" : t.main;
            for (int y = (int) cy - 4; y <= (int) cy + 4; y++) {
                for (int z = (int) cz - 4; z <= (int) cz + 4; z++) {
                    double d = Math.hypot(y + 0.5 - cy, z + 0.5 - cz);
                    if (d >= 2.9 && d <= 3.8) {
                        decor(x, y, z, ((y + z) & 1) == 0 ? a : b);
                    }
                }
            }
        }

        void honeySlide(Platform p) {
            int x = p.x0() - 1;
            for (int y = p.y() + 1; y <= p.y() + 3; y++) {
                decor(x, y, p.z0() - 1, "minecraft:honey_block");
            }
        }

        void finish(Theme t) {
            Platform from = last();
            int x0 = from.x1() + 3;
            int cz = (int) Math.floor(from.centerZ());
            Platform f = addPlatform(x0, cz - 1, x0 + 2, cz + 1, from.y(), Platform.Kind.FINISH, t);
            finishGate(f);
        }

        /** Единое оформление выхода: чёрные колонны, лаймовая перекладина, свет. */
        void finishGate(Platform f) {
            int x = (int) Math.floor(f.centerX());
            java.util.function.BiConsumer<int[], String> gate = (pos, block) -> {
                if (!reserved.contains(Blueprint.key(pos[0], pos[1], pos[2]))) bp.set(pos[0], pos[1], pos[2], block);
            };
            for (int y = f.y() + 1; y <= f.y() + 4; y++) {
                gate.accept(new int[] {x, y, f.z0() - 1}, "minecraft:black_concrete");
                gate.accept(new int[] {x, y, f.z1() + 1}, "minecraft:black_concrete");
            }
            for (int z = f.z0() - 1; z <= f.z1() + 1; z++) {
                gate.accept(new int[] {x, f.y() + 5, z}, "minecraft:lime_concrete");
            }
            gate.accept(new int[] {x, f.y() + 5, (int) Math.floor(f.centerZ())}, "minecraft:verdant_froglight");
            gate.accept(new int[] {x, f.y() + 4, f.z0() - 1}, "minecraft:verdant_froglight");
            gate.accept(new int[] {x, f.y() + 4, f.z1() + 1}, "minecraft:verdant_froglight");
        }

        // ------------------------------------------------------- комната 100

        /** Подъём вокруг огромной буквы D; финиш на её вершине виден снизу. */
        void finalRoom() {
            if (variant == 2) {
                darkFinale();
                return;
            }
            addPlatform(ox, oz - 2, ox + 4, oz + 2, oy, Platform.Kind.START, Theme.ARENA);
            jump(Theme.ARENA, 2, 0, 3, Platform.Kind.FIRST);
            jump(Theme.ARENA, 3, 0, 3, Platform.Kind.NORMAL);
            bridgeFrom = 1;
            letterFinale(Theme.ARENA, ox + 30, false);
            // Фиолетово-лаймовая арена вокруг основания.
            for (int x = ox - 2; x <= ox + 34 + 8; x += 2) {
                decor(x, oy - 8, oz - 16, "minecraft:lime_concrete");
                decor(x, oy - 8, oz + 16, "minecraft:purple_concrete");
            }
        }

        /**
         * Финал Dirron Parkour 2 (100) — самая тёмная, страшная и трудная комната:
         * «ворота тьмы» из самых трудных приёмов подряд, затем подъём на 30
         * блоков по спирали из площадок 1×1 вокруг чёрной буквы D.
         */
        void darkFinale() {
            Theme t = Theme.DOOM;
            addPlatform(ox, oz - 2, ox + 4, oz + 2, oy, Platform.Kind.START, t);
            jump(t, 2, 0, 3, Platform.Kind.FIRST);
            jump(t, 3, 0, 2, Platform.Kind.NORMAL);
            bridgeFrom = 1;
            for (int i = 0; i < 14; i++) {
                if (last().x1() - ox > 56) break;
                move(tierMove(pickMove(t, i), i), t);
            }
            letterFinale(t, last().x1() + 12, true);
            clearForeignCeilings();
            scenery = true;
            themeDecor();
            scenery = false;
        }

        /** Буква D, глаза логотипа и спираль к финишу на её вершине. [dark] — финал второй карты. */
        void letterFinale(Theme theme, int letterX, boolean dark) {
            // Буква D в плоскости YZ (лицом к старту), толщина по X.
            int dx0 = letterX, dx1 = letterX + 4;
            int dz0 = oz - 10, dz1 = oz + 10;
            int dy0 = oy - 2, dy1 = oy + 30;
            int width = dz1 - dz0 + 1, height = dy1 - dy0 + 1;
            for (int y = dy0; y <= dy1; y++) {
                for (int z = dz0; z <= dz1; z++) {
                    int u = z - dz0, v = y - dy0;
                    if (letterD(u, v, width, height)) {
                        for (int x = dx0; x <= dx1; x++) {
                            if (dark) bp.set(x, y, z, x == dx0 ? "minecraft:crying_obsidian" : "minecraft:polished_blackstone");
                            else bp.set(x, y, z, x == dx0 ? "minecraft:purple_concrete" : "minecraft:magenta_concrete");
                        }
                    } else if (insideCounter(u, v, width, height)) {
                        bp.set(dx1, y, z, "minecraft:black_concrete"); // тёмная глубина буквы
                    }
                }
            }
            // Глаза логотипа на тёмном фоне внутри D (загораются после финиша).
            int eyeY = oy + 13;
            for (int ez : new int[] {oz - 3, oz + 2}) {
                for (int y = eyeY; y < eyeY + 3; y++) {
                    for (int z = ez - 1; z <= ez + 1; z++) {
                        bp.set(dx1 - 1, y, z, "minecraft:gray_concrete");
                        eyes.add(new int[] {dx1 - 1, y, z});
                    }
                }
            }

            // Подход к букве.
            int rx0 = dx0 - 4, rx1 = dx1 + 3, rz0 = dz0 - 4, rz1 = dz1 + 3;
            while (last().x1() < rx0 - 3) {
                if (dark) jump(theme, 3, 0, 1, Platform.Kind.NORMAL);
                else jump(Theme.ARENA, 2, 0, 2, Platform.Kind.NORMAL);
            }
            // Ступени спирали: 2×2, во тьме — 1×1 (ближе, но точнее).
            int size = dark ? 1 : 2;
            double minStep = dark ? 3.0 : 4.0;
            // Спираль по прямоугольнику вокруг буквы: каждая ступень на 1 выше.
            double perimeter = 2.0 * ((rx1 - rx0) + (rz1 - rz0));
            double t = Math.max(0, rz1 - Math.floor(last().centerZ()));
            boolean rising = true;
            int y = last().y();
            for (int guard = 0; guard < 2000; guard++) {
                double[] p = rectPoint(rx0, rz0, rx1, rz1, t % perimeter);
                t += 1.0;
                int px = (int) Math.floor(p[0]);
                int pz = (int) Math.floor(p[1]);
                Platform previous = last();
                double manhattan = Math.abs(px + 1 - previous.centerX()) + Math.abs(pz + 1 - previous.centerZ());
                if (manhattan < minStep) continue;
                int ny = rising ? y + 1 : y;
                Platform next = new Platform(platforms.size(), px, pz, px + size - 1, pz + size - 1, ny, Platform.Kind.NORMAL);
                if (previous.airGapTo(next) > (ny > previous.y() ? 2.25 : 3.2)) continue;
                Theme style = dark ? theme : Theme.values()[platforms.size() % 10];
                addPlatform(px, pz, px + size - 1, pz + size - 1, ny, Platform.Kind.NORMAL, style);
                y = ny;
                if (y >= dy1) rising = false;
                // На высоте вершины идём до ближней стороны у «ножки» буквы.
                if (!rising && px <= rx0 && pz <= dz0 + 3) break;
            }
            // Ступень у вершины и финиш на верхней перекладине буквы.
            Platform top = last();
            Platform step = addPlatform(dx0 - 2, top.z0(), dx0 - 1, top.z1(), dy1, Platform.Kind.NORMAL, theme);
            Platform f = addPlatform(dx0 + 1, Math.max(dz0, step.z0() - 1), dx0 + 3,
                    Math.max(dz0, step.z0() - 1) + 2, dy1 + 1, Platform.Kind.FINISH, theme);
            finishGate(f);
            number(theme);
        }

        static double[] rectPoint(int x0, int z0, int x1, int z1, double t) {
            double w = x1 - x0, h = z1 - z0;
            // Обход: ближняя к старту сторона (x0) от z1 к z0, дальше по кругу.
            if (t < h) return new double[] {x0, z1 - t};
            t -= h;
            if (t < w) return new double[] {x0 + t, z0};
            t -= w;
            if (t < h) return new double[] {x1, z0 + t};
            t -= h;
            return new double[] {x1 - t, z1};
        }

        static final int STEM = 5;

        /** Правая граница буквы в строке v (u — по ширине, v — снизу). */
        static double outerEdge(int v, int width, int height) {
            double cy = (height - 1) / 2.0, ry = height / 2.0;
            double ny = (v - cy) / ry;
            if (Math.abs(ny) > 1) return STEM;
            return STEM + (width - STEM) * Math.sqrt(Math.max(0, 1 - ny * ny));
        }

        /** Левая граница внутреннего «окна» буквы в строке v. */
        static double innerEdge(int v, int width, int height) {
            double cy = (height - 1) / 2.0, ry = height / 2.0 - 5;
            double ny = (v - cy) / ry;
            if (Math.abs(ny) >= 1) return -1;
            return STEM + (width - STEM - 5) * Math.sqrt(1 - ny * ny);
        }

        /** Пиксель буквы D. */
        static boolean letterD(int u, int v, int width, int height) {
            if (u < STEM) return true;
            double outer = outerEdge(v, width, height);
            if (u >= Math.max(outer, v < 5 || v >= height - 5 ? STEM + (width - STEM) * 0.55 : outer)) return false;
            if (v < 5 || v >= height - 5) return true;
            double inner = innerEdge(v, width, height);
            return inner < 0 || u >= inner;
        }

        /** Внутреннее «окно» буквы (тёмный фон для глаз). */
        static boolean insideCounter(int u, int v, int width, int height) {
            return u >= STEM && v >= 5 && v < height - 5 && !letterD(u, v, width, height)
                    && u < outerEdge(v, width, height);
        }

        // ------------------------------------------------------------- общее

        /** Декор: только в пустоту и не над платформами. */
        void decor(int x, int y, int z, String block) {
            long key = Blueprint.key(x, y, z);
            if (reserved.contains(key) || bp.has(x, y, z)) return;
            bp.set(x, y, z, block);
            if (scenery) decorKeys.add(key);
            // Вторая карта: песок всегда на опоре (иначе при первом входе в мир
            // он осыпается в воду или в пустоту).
            if (variant == 2 && (block.equals("minecraft:sand") || block.equals("minecraft:red_sand")) && !bp.has(x, y - 1, z)) {
                decor(x, y - 1, z, block.equals("minecraft:sand") ? "minecraft:sandstone" : "minecraft:terracotta");
            }
        }

        Platform addPlatform(int x0, int z0, int x1, int z1, int y, Platform.Kind kind, Theme t) {
            Platform p = new Platform(platforms.size(), x0, z0, x1, z1, y, kind);
            platforms.add(p);
            platformThemes.add(t);
            // Над платформой всегда 3 блока воздуха: убираем декор, если он там был.
            for (int x = x0; x <= x1; x++) {
                for (int z = z0; z <= z1; z++) {
                    for (int dy = 1; dy <= 3; dy++) {
                        bp.remove(x, y + dy, z);
                        reserved.add(Blueprint.key(x, y + dy, z));
                    }
                }
            }
            int w = x1 - x0 + 1, d = z1 - z0 + 1;
            boolean bigEnough = w >= 3 && d >= 3;
            for (int x = x0; x <= x1; x++) {
                for (int z = z0; z <= z1; z++) {
                    boolean border = x == x0 || x == x1 || z == z0 || z == z1;
                    String top = switch (kind) {
                        case START -> (x == (x0 + x1) / 2 && z == (z0 + z1) / 2) ? "minecraft:lodestone"
                                : (border ? t.edge : t.main);
                        case FIRST -> border && bigEnough ? "minecraft:white_concrete" : "minecraft:lime_concrete";
                        case RUNWAY -> "minecraft:blue_ice";
                        case BOUNCE -> "minecraft:slime_block";
                        case BEAM -> t == Theme.CARNIVAL ? "minecraft:white_concrete" : "minecraft:waxed_cut_copper";
                        case FINISH -> "minecraft:gold_block";
                        default -> bigEnough && border ? t.edge : t.main;
                    };
                    bp.set(x, y, z, top);
                    String under = bigEnough ? t.main : t.edge;
                    if (kind == Platform.Kind.FINISH || kind == Platform.Kind.FIRST) under = "minecraft:verdant_froglight";
                    bp.set(x, y - 1, z, under);
                }
            }
            // Подсветка снизу — видна издалека и с обычной графикой.
            int cx = (int) Math.floor(p.centerX());
            int cz = (int) Math.floor(p.centerZ());
            if (kind != Platform.Kind.BOUNCE) {
                bp.set(cx, y - 1, cz, t == Theme.FORGE ? "minecraft:furnace[lit=true,facing=north]" : t.light);
            }
            return p;
        }

        /** Крупный номер комнаты над маршрутом, лицом к старту. */
        void number(Theme t) {
            String text = Integer.toString(number);
            int scale = 2;
            int digitWidth = 3 * scale;
            int spacing = 2;
            int total = text.length() * digitWidth + (text.length() - 1) * spacing;
            int zStart = oz - total / 2;
            int yTop = oy + 7 + 5 * scale - 1;
            int x = ox + NUMBER_X;
            for (int i = 0; i < text.length(); i++) {
                int digit = text.charAt(i) - '0';
                int z0 = zStart + i * (digitWidth + spacing);
                for (int col = 0; col < 3; col++) {
                    for (int row = 0; row < 5; row++) {
                        if (!DigitFont.pixel(digit, col, row)) continue;
                        for (int sz = 0; sz < scale; sz++) {
                            for (int sy = 0; sy < scale; sy++) {
                                decor(x, yTop - row * scale - sy, z0 + col * scale + sz, t.light);
                            }
                        }
                    }
                }
            }
        }

        void themeDecor() {
            int minX = Integer.MAX_VALUE, maxX = Integer.MIN_VALUE, minY = Integer.MAX_VALUE;
            for (Platform p : platforms) {
                minX = Math.min(minX, p.x0());
                maxX = Math.max(maxX, p.x1());
                minY = Math.min(minY, p.y());
            }
            if (variant == 2) {
                backdrop(minX, maxX);
                immersion(minX, maxX);
                return;
            }
            switch (theme) {
                case NEON -> {
                    // Улица далеко внизу и вывески по сторонам.
                    for (int x = minX - 2; x <= maxX + 2; x++) {
                        for (int z = oz - 3; z <= oz + 3; z++) {
                            decor(x, minY - 14, z, "minecraft:black_concrete");
                        }
                        if (x % 4 < 2) decor(x, minY - 14, oz, "minecraft:yellow_concrete");
                    }
                    for (int x = minX + 6; x <= maxX; x += 14) {
                        billboard(x, oz - 11, minY + 2, "minecraft:cyan_stained_glass", "minecraft:sea_lantern");
                        billboard(x + 7, oz + 11, minY + 2, "minecraft:magenta_stained_glass", "minecraft:sea_lantern");
                    }
                }
                case CORAL -> pool(minX - 2, maxX + 2, oz - 9, oz + 9, minY - 6);
                case HONEY -> {
                    for (int x = minX; x <= maxX; x++) {
                        for (int y = minY - 4; y <= minY + 6; y++) {
                            decor(x, y, oz - 10, (x + y) % 5 == 0 ? "minecraft:honey_block" : "minecraft:honeycomb_block");
                        }
                    }
                }
                case SLIME -> {
                    for (int x = minX; x <= maxX; x += 5) {
                        for (int y = minY - 2; y <= minY + 5; y++) {
                            decor(x, y, oz - 10, "minecraft:lime_stained_glass");
                            decor(x, y, oz + 10, "minecraft:lime_stained_glass");
                        }
                        decor(x, minY + 6, oz - 10, "minecraft:verdant_froglight");
                        decor(x, minY + 6, oz + 10, "minecraft:verdant_froglight");
                    }
                }
                case FORGE -> {
                    for (int x = minX; x <= maxX; x++) {
                        decor(x, minY - 7, oz, "minecraft:magma_block");
                        if (x % 6 == 0) {
                            for (int y = minY - 6; y <= minY + 6; y++) {
                                decor(x, y, oz - 9, "minecraft:waxed_cut_copper");
                                decor(x, y, oz + 9, "minecraft:waxed_cut_copper");
                            }
                        }
                    }
                }
                case CARNIVAL -> {
                    String[] colors = {"minecraft:red_wool", "minecraft:yellow_wool", "minecraft:light_blue_wool", "minecraft:lime_wool"};
                    int c = 0;
                    for (int x = minX + 4; x <= maxX; x += 9) {
                        balloon(x, minY + 7, oz - 10, colors[c++ % colors.length]);
                        balloon(x + 4, minY + 9, oz + 10, colors[c++ % colors.length]);
                    }
                }
                case ARENA -> {
                    for (int x = minX; x <= maxX; x++) {
                        for (int y = minY - 3; y <= minY + 4; y++) {
                            String block = ((x / 2 + y) & 1) == 0 ? "minecraft:purple_concrete" : "minecraft:lime_concrete";
                            decor(x, y, oz - 11, block);
                            decor(x, y, oz + 11, block);
                        }
                    }
                }
                default -> { }
            }
        }

        /**
         * Dirron Parkour 2: крупное окружение по обе стороны трассы — на 10+
         * блоков в стороне от любой платформы, поэтому прыжкам не мешает.
         */
        void backdrop(int minX, int maxX) {
            int minZ = Integer.MAX_VALUE, maxZ = Integer.MIN_VALUE;
            for (Platform p : platforms) {
                minZ = Math.min(minZ, p.z0());
                maxZ = Math.max(maxZ, p.z1());
            }
            // По очереди слева и справа, примерно раз в 18 блоков: главная деталь и второстепенная.
            int step = 29;
            int k = 0;
            for (int x = minX + 4; x <= maxX - 4; x += step, k++) {
                int side = k % 2 == 0 ? -1 : 1;
                int r = 4 + rnd.nextInt(2);
                int z = side < 0 ? minZ - 10 - r - rnd.nextInt(4) : maxZ + 10 + r + rnd.nextInt(4);
                int fx = Math.min(maxX - r, Math.max(minX + r, x + rnd.nextInt(5) - 2));
                feature(fx, z, r, k % 4 < 2);
            }
        }

        /** Полый холм-конус (снаружи как сплошной, внутри пусто — меньше блоков). */
        void shell(int cx, int cz, int r, int h, String outer, String cap, int capLayers) {
            for (int k = 0; k < h; k++) {
                int rr = Math.max(0, r - (k * r) / Math.max(1, h));
                int nextR = Math.max(0, r - ((k + 1) * r) / Math.max(1, h));
                for (int dx = -rr; dx <= rr; dx++) {
                    for (int dz = -rr; dz <= rr; dz++) {
                        double d = Math.sqrt(dx * dx + dz * dz);
                        if (d > rr + 0.3) continue;
                        // Видимая оболочка: край слоя и то, что не накрыто следующим слоем.
                        if (d <= nextR - 0.7 && k < h - 1) continue;
                        decor(cx + dx, SEA_TOP + k, cz + dz, k >= h - capLayers ? cap : outer);
                    }
                }
            }
        }

        /**
         * Погружение в локацию: вместо океана вокруг — сама локация на ~50 блоков
         * в стороны (в пределах клетки комнаты). Ад — лавовое море, берега из
         * незерака, базальт и светокамень; Энд — обсидиановая «пустота»,
         * шпили и парящие острова; Горы — замёрзшее озеро и заснеженные хребты.
         * Всё дальше 15 блоков от трассы и ниже её — прыжкам не мешает.
         */
        void immersion(int minX, int maxX) {
            if (theme == Theme.DESERT || theme == Theme.RIFT || theme == Theme.DOOM) {
                deepImmersion(minX, maxX);
                return;
            }
            if (theme != Theme.NETHER && theme != Theme.END_ISLES && theme != Theme.MOUNTAIN) return;
            int minZ = Integer.MAX_VALUE, maxZ = Integer.MIN_VALUE;
            for (Platform p : platforms) {
                minZ = Math.min(minZ, p.z0());
                maxZ = Math.max(maxZ, p.z1());
            }
            int x0 = minX - 12, x1 = Math.min(x0 + 128, Math.max(maxX + 12, x0 + 100));
            int mid = (minZ + maxZ) / 2;
            int z0 = mid - 60, z1 = mid + 60;
            String floor = switch (theme) {
                case NETHER -> "minecraft:lava";
                case END_ISLES -> "minecraft:obsidian";
                default -> "minecraft:packed_ice";
            };
            // Пол локации вместо воды (один слой на уровне моря).
            for (int x = x0; x <= x1; x++)
                for (int z = z0; z <= z1; z++) {
                    String f = floor;
                    if (theme == Theme.MOUNTAIN && ((x * 31 + z * 17) & 7) == 0) f = "minecraft:blue_ice";
                    if (theme == Theme.END_ISLES && ((x * 13 + z * 7) % 23) == 0) f = "minecraft:crying_obsidian";
                    decor(x, SEA_TOP, z, f);
                    // Под лавой — незерак: лава не трогает воду под собой (иначе при первом
                    // входе в мир тысячи блоков воды разом превращались бы в камень — лаг).
                    if (theme == Theme.NETHER) decor(x, SEA_TOP - 1, z, "minecraft:netherrack");
                }
            // Крупные формы по обе стороны: от 18 до 55 блоков от трассы.
            int pieces = 7;
            for (int i = 0; i < pieces; i++) {
                int side = i % 2 == 0 ? -1 : 1;
                // Крупные формы (радиус до 15) целиком внутри клетки комнаты.
                int fx = x0 + 16 + (x1 - x0 - 32) * i / (pieces - 1);
                int dist = 20 + rnd.nextInt(26);
                int fz = side < 0 ? minZ - dist : maxZ + dist;
                fz = Math.max(z0 + 16, Math.min(z1 - 16, fz));
                switch (theme) {
                    case NETHER -> {
                        int r = 7 + rnd.nextInt(5);
                        shell(fx, fz, r, 6 + rnd.nextInt(6), "minecraft:netherrack", "minecraft:crimson_nylium", 1);
                        for (int k = 0; k < 18 + rnd.nextInt(10); k++) {
                            decor(fx + r - 2, SEA_TOP + k, fz, k % 6 == 5 ? "minecraft:glowstone" : "minecraft:basalt[axis=y]");
                            decor(fx + r - 1, SEA_TOP + k, fz, "minecraft:polished_basalt[axis=y]");
                        }
                        // Висящий над лавой кусок незерака со светокамнем снизу.
                        int hy = SEA_TOP + 22 + rnd.nextInt(8);
                        for (int dx = -2; dx <= 2; dx++)
                            for (int dz = -2; dz <= 2; dz++)
                                if (dx * dx + dz * dz <= 5) {
                                    decor(fx - r + 2 + dx, hy, fz + dz, "minecraft:netherrack");
                                    if (dx * dx + dz * dz <= 1) decor(fx - r + 2 + dx, hy - 1, fz + dz, "minecraft:glowstone");
                                }
                        decor(fx - 2, SEA_TOP + 1, fz + 1, "minecraft:magma_block");
                        decor(fx + 1, SEA_TOP + 6, fz - 1, "minecraft:crimson_fungus");
                    }
                    case END_ISLES -> {
                        // Шпиль, как на острове дракона.
                        int h = 26 + rnd.nextInt(14);
                        for (int k = 0; k < h; k++)
                            for (int dx = -1; dx <= 1; dx++)
                                for (int dz = -1; dz <= 1; dz++)
                                    if (k < h - 1 || (dx == 0 && dz == 0)) decor(fx + dx, SEA_TOP + k, fz + dz, "minecraft:obsidian");
                        decor(fx, SEA_TOP + h, fz, "minecraft:end_rod[facing=up]");
                        decor(fx, SEA_TOP + h - 1, fz + 1, "minecraft:iron_bars");
                        // Парящий остров эндерняка рядом.
                        int iy = SEA_TOP + 8 + rnd.nextInt(10), ix = fx + (side < 0 ? 7 : -7), r = 4 + rnd.nextInt(3);
                        for (int dx = -r; dx <= r; dx++)
                            for (int dz = -r; dz <= r; dz++) {
                                double d = Math.sqrt(dx * dx + dz * dz);
                                if (d > r + 0.3) continue;
                                decor(ix + dx, iy, fz + dz, "minecraft:end_stone");
                                if (d < r - 1.5) decor(ix + dx, iy - 1, fz + dz, "minecraft:end_stone");
                                if (d < r - 3) decor(ix + dx, iy - 2, fz + dz, "minecraft:end_stone");
                            }
                        decor(ix, iy + 1, fz, "minecraft:chorus_plant");
                        decor(ix, iy + 2, fz, "minecraft:chorus_flower[age=5]");
                    }
                    default -> {
                        // Заснеженный хребет.
                        int r = 10 + rnd.nextInt(6);
                        int h = 22 + rnd.nextInt(14);
                        shell(fx, fz, r, h, rnd.nextBoolean() ? "minecraft:stone" : "minecraft:andesite", "minecraft:snow_block", 7);
                        decor(fx, SEA_TOP + h, fz, "minecraft:snow_block");
                        decor(fx + r + 2, SEA_TOP + 1, fz, "minecraft:spruce_log");
                        decor(fx + r + 2, SEA_TOP + 2, fz, "minecraft:spruce_log");
                        for (int dx = -1; dx <= 1; dx++)
                            for (int dz = -1; dz <= 1; dz++)
                                decor(fx + r + 2 + dx, SEA_TOP + 3, fz + dz, "minecraft:spruce_leaves[persistent=true]");
                        decor(fx + r + 2, SEA_TOP + 4, fz, "minecraft:spruce_leaves[persistent=true]");
                    }
                }
            }
        }


        /** Пустыня/бесплодные земли (31–45), «Разлом» (91–99) и финал во тьме (100). */
        void deepImmersion(int minX, int maxX) {
            int minZ = Integer.MAX_VALUE, maxZ = Integer.MIN_VALUE;
            for (Platform p : platforms) {
                minZ = Math.min(minZ, p.z0());
                maxZ = Math.max(maxZ, p.z1());
            }
            int x0 = minX - 12, x1 = Math.min(x0 + 128, Math.max(maxX + 12, x0 + 100));
            int mid = (minZ + maxZ) / 2;
            int z0 = mid - 60, z1 = mid + 60;
            boolean badlands = theme == Theme.DESERT && number >= 39;
            // Оазис пустыни: вода остаётся, вокруг — трава и пальмы.
            int oasisX = x0 + 30 + rnd.nextInt(Math.max(1, x1 - x0 - 60));
            int oasisZ = rnd.nextBoolean() ? minZ - 34 : maxZ + 34;
            oasisZ = Math.max(z0 + 12, Math.min(z1 - 12, oasisZ));
            boolean oasis = theme == Theme.DESERT && !badlands;
            for (int x = x0; x <= x1; x++)
                for (int z = z0; z <= z1; z++) {
                    int h = (x * 31 + z * 17) & 15;
                    String top, under;
                    switch (theme) {
                        case DESERT -> {
                            if (oasis) {
                                double d = Math.hypot(x - oasisX, z - oasisZ);
                                if (d < 6.5 && !bp.has(x, SEA_TOP + 1, z)) continue; // вода оазиса
                                if (d < 8.5) {
                                    decor(x, SEA_TOP, z, "minecraft:grass_block");
                                    decor(x, SEA_TOP - 1, z, "minecraft:dirt");
                                    continue;
                                }
                            }
                            top = badlands ? (h == 0 ? "minecraft:terracotta" : "minecraft:red_sand")
                                    : (h == 0 ? "minecraft:smooth_sandstone" : "minecraft:sand");
                            under = badlands ? "minecraft:terracotta" : "minecraft:sandstone";
                        }
                        case RIFT -> {
                            top = h == 0 ? "minecraft:crying_obsidian" : (h == 1 ? "minecraft:sculk_catalyst" : "minecraft:sculk");
                            under = "minecraft:deepslate";
                        }
                        default -> { // DOOM
                            int crack = Math.floorMod(x * 7 + z * 3 + (x / 9) * 11, 29);
                            top = crack == 0 ? "minecraft:lava" : (h < 3 ? "minecraft:basalt[axis=y]"
                                    : (h == 3 ? "minecraft:magma_block" : (h == 4 ? "minecraft:soul_soil" : "minecraft:blackstone")));
                            under = "minecraft:blackstone";
                        }
                    }
                    decor(x, SEA_TOP, z, top);
                    // Под песком и лавой — твёрдый слой: песок не осыпается в воду,
                    // лава не превращает воду под собой в камень.
                    decor(x, SEA_TOP - 1, z, under);
                    if (theme == Theme.DOOM && top.equals("minecraft:soul_soil") && ((x + z) & 3) == 0)
                        decor(x, SEA_TOP + 1, z, "minecraft:soul_fire");
                    if (theme == Theme.DESERT && !badlands && h == 7 && ((x ^ z) & 7) == 0)
                        decor(x, SEA_TOP + 1, z, "minecraft:dead_bush");
                }
            if (oasis) {
                for (int k = 0; k < 4; k++) {
                    double a = k * Math.PI / 2 + 0.6;
                    palm((int) Math.round(oasisX + Math.cos(a) * 7.5), (int) Math.round(oasisZ + Math.sin(a) * 7.5), k);
                }
            }
            int pieces = 9;
            for (int i = 0; i < pieces; i++) {
                int side = i % 2 == 0 ? -1 : 1;
                int fx = x0 + 16 + (x1 - x0 - 32) * i / (pieces - 1);
                int dist = 22 + rnd.nextInt(24);
                int fz = side < 0 ? minZ - dist : maxZ + dist;
                fz = Math.max(z0 + 16, Math.min(z1 - 16, fz));
                if (oasis && Math.hypot(fx - oasisX, fz - oasisZ) < 22) fz = side < 0 ? z0 + 16 : z1 - 16;
                switch (theme) {
                    case DESERT -> {
                        if (badlands) {
                            if (i % 3 == 2) hoodoo(fx, fz, 18 + rnd.nextInt(12));
                            else mesa(fx, fz, 8 + rnd.nextInt(6), 14 + rnd.nextInt(14));
                        } else {
                            switch (i % 3) {
                                case 0 -> {
                                    int r = 14 + rnd.nextInt(5);
                                    pyramid(fx, fz, r);
                                    obelisk(fx - r - 5, fz - side * (r - 2), 16 + rnd.nextInt(6));
                                }
                                case 1 -> dune(fx, fz, 12 + rnd.nextInt(4), 9 + rnd.nextInt(5));
                                default -> {
                                    fossil(fx, fz, side);
                                    dune(fx + 4, fz - side * 9, 8, 6);
                                }
                            }
                            if (!bp.has(fx + 12, SEA_TOP + 1, fz + side * 3)) {
                                bp.set(fx + 12, SEA_TOP, fz + side * 3, "minecraft:sand"); // кактус растёт только на песке
                                for (int k = 0; k < 3 + rnd.nextInt(2); k++) decor(fx + 12, SEA_TOP + 1 + k, fz + side * 3, "minecraft:cactus");
                            }
                        }
                    }
                    case RIFT -> {
                        if (i % 2 == 0) crystal(fx, fz, 20 + rnd.nextInt(16), side);
                        fragment(fx + (i % 2 == 0 ? 9 : 0), fz, SEA_TOP + 14 + rnd.nextInt(22), 4 + rnd.nextInt(3), i);
                    }
                    default -> { // DOOM
                        if (i % 2 == 0) blackSpire(fx, fz, 30 + rnd.nextInt(16));
                        else hangingCage(fx, fz, SEA_TOP + 26 + rnd.nextInt(10));
                        if (i % 3 == 1) giantRibs(fx + 6, fz, side);
                    }
                }
            }
            // Если что-то легло на воду оазиса — подводим под это землю.
            if (oasis) {
                for (int x = oasisX - 7; x <= oasisX + 7; x++)
                    for (int z = oasisZ - 7; z <= oasisZ + 7; z++)
                        if (!bp.has(x, SEA_TOP, z) && bp.has(x, SEA_TOP + 1, z)) {
                            bp.set(x, SEA_TOP, z, "minecraft:sandstone");
                            if (scenery) decorKeys.add(Blueprint.key(x, SEA_TOP, z));
                            decor(x, SEA_TOP - 1, z, "minecraft:sandstone");
                        }
            }
        }

        /** Пальма оазиса: наклонный ствол и листья звездой. */
        void palm(int x, int z, int k) {
            int dx = k % 2 == 0 ? 1 : 0, dz = k % 2 == 0 ? 0 : 1;
            int h = 6 + (k % 2);
            int tx = x, tz = z;
            for (int y = 0; y < h; y++) {
                if (y == 3) { tx += dx; tz += dz; }
                decor(tx, SEA_TOP + 1 + y, tz, "minecraft:jungle_log");
            }
            int ty = SEA_TOP + h;
            decor(tx, ty + 1, tz, "minecraft:jungle_leaves[persistent=true]");
            for (int a = 1; a <= 3; a++) {
                int dy = a == 3 ? -1 : 0;
                decor(tx + a, ty + dy, tz, "minecraft:jungle_leaves[persistent=true]");
                decor(tx - a, ty + dy, tz, "minecraft:jungle_leaves[persistent=true]");
                decor(tx, ty + dy, tz + a, "minecraft:jungle_leaves[persistent=true]");
                decor(tx, ty + dy, tz - a, "minecraft:jungle_leaves[persistent=true]");
            }
            decor(tx + 1, ty - 1, tz, "minecraft:cocoa[age=2,facing=west]");
        }

        /** Ступенчатая пирамида фараона из песчаника с золотой вершиной. */
        void pyramid(int cx, int cz, int r) {
            for (int k = 0; k <= r; k++) {
                int hs = r - k;
                String b = k % 3 == 2 ? "minecraft:cut_sandstone" : "minecraft:sandstone";
                for (int dx = -hs; dx <= hs; dx++)
                    for (int dz = -hs; dz <= hs; dz++)
                        if (Math.abs(dx) == hs || Math.abs(dz) == hs || k == r) decor(cx + dx, SEA_TOP + 1 + k, cz + dz, b);
            }
            decor(cx, SEA_TOP + 2 + r, cz, "minecraft:gold_block");
            // Вход с колоннами.
            decor(cx - r, SEA_TOP + 2, cz - 1, "minecraft:chiseled_sandstone");
            decor(cx - r, SEA_TOP + 2, cz + 1, "minecraft:chiseled_sandstone");
            decor(cx - r - 1, SEA_TOP + 1, cz, "minecraft:orange_terracotta");
        }

        /** Обелиск 2×2 из резного песчаника с золотым навершием. */
        void obelisk(int x, int z, int h) {
            for (int k = 1; k <= h; k++) {
                String b = k == h ? "minecraft:gold_block" : k % 4 == 0 ? "minecraft:chiseled_sandstone" : "minecraft:cut_sandstone";
                for (int dx = 0; dx <= 1; dx++)
                    for (int dz = 0; dz <= 1; dz++) decor(x + dx, SEA_TOP + k, z + dz, b);
            }
        }

        /** Сплошной песчаный бархан (песок лежит на песке — не осыпается). */
        void dune(int cx, int cz, int r, int h) {
            for (int dx = -r - 4; dx <= r + 4; dx++)
                for (int dz = -r; dz <= r; dz++) {
                    // Вытянутый по ветру холм с крутым подветренным склоном.
                    double u = dx < 0 ? dx / (double) (r + 4) : dx / (double) r;
                    double d = Math.sqrt(u * u + (dz / (double) r) * (dz / (double) r));
                    if (d >= 1) continue;
                    int top = (int) Math.round(h * (1 - d * d));
                    for (int y = 1; y <= top; y++) decor(cx + dx, SEA_TOP + y, cz + dz, "minecraft:sand");
                }
        }

        /** Окаменелость: хребет и рёбра гигантского скелета из костных блоков. */
        void fossil(int cx, int cz, int side) {
            int len = 18;
            for (int k = 0; k < len; k++) {
                int x = cx - len / 2 + k;
                int sy = SEA_TOP + 2 + (int) Math.round(2 * Math.sin(k / 4.0));
                decor(x, sy, cz, "minecraft:bone_block[axis=x]");
                if (k % 3 == 0 && k > 1 && k < len - 2) {
                    int rib = 6 - Math.abs(k - len / 2) / 3;
                    for (int a = 1; a <= rib; a++) {
                        int y = sy + (int) Math.round(Math.sin(a / (double) rib * Math.PI) * 3) - a / 3;
                        decor(x, Math.max(SEA_TOP + 1, y), cz + a, "minecraft:bone_block[axis=z]");
                        decor(x, Math.max(SEA_TOP + 1, y), cz - a, "minecraft:bone_block[axis=z]");
                    }
                }
            }
            // Череп.
            int hx = cx + len / 2 + 1;
            for (int dx = 0; dx <= 2; dx++)
                for (int dy = 0; dy <= 2; dy++)
                    for (int dz = -1; dz <= 1; dz++)
                        if (!(dx == 2 && dy == 1 && dz != 0)) decor(hx + dx, SEA_TOP + 2 + dy, cz + dz, "minecraft:bone_block");
        }

        static final String[] MESA_STRIPES = {"minecraft:orange_terracotta", "minecraft:terracotta",
            "minecraft:yellow_terracotta", "minecraft:brown_terracotta", "minecraft:white_terracotta",
            "minecraft:red_terracotta", "minecraft:light_gray_terracotta", "minecraft:orange_terracotta"};

        /** Столовая гора бесплодных земель: полосатые стены и плоская вершина. */
        void mesa(int cx, int cz, int r, int h) {
            for (int y = 1; y <= h; y++) {
                // Стены чуть сужаются кверху и «ломаются» уступами.
                double rr = r - (y > h * 2 / 3 ? 1.5 : 0) + ((y / 4) % 2) * 0.6;
                String b = MESA_STRIPES[(y + cz) % MESA_STRIPES.length];
                for (int dx = (int) -rr - 1; dx <= rr + 1; dx++)
                    for (int dz = (int) -rr - 1; dz <= rr + 1; dz++) {
                        double d = Math.sqrt(dx * dx + dz * dz * 1.4);
                        if (d > rr + 0.4) continue;
                        if (d > rr - 1.2 || y == h) decor(cx + dx, SEA_TOP + y, cz + dz, b);
                    }
            }
            for (int dx = -r + 2; dx <= r - 2; dx += 3)
                decor(cx + dx, SEA_TOP + h + 1, cz, rnd.nextBoolean() ? "minecraft:dead_bush" : "minecraft:red_sand");
        }

        /** Тонкая полосатая скала-«худу». */
        void hoodoo(int cx, int cz, int h) {
            for (int y = 1; y <= h; y++) {
                String b = MESA_STRIPES[(y + cx) % MESA_STRIPES.length];
                int w = y > h - 3 ? 2 : (y < 4 ? 2 : 1);
                for (int dx = -w; dx <= w; dx++)
                    for (int dz = -w; dz <= w; dz++)
                        if (dx * dx + dz * dz <= w * w) decor(cx + dx, SEA_TOP + y, cz + dz, b);
            }
        }

        /** Гигантский наклонный кристалл аметиста из скалковой земли «Разлома». */
        void crystal(int cx, int cz, int h, int side) {
            for (int y = 0; y < h; y++) {
                int ox2 = cx + y / 5, oz2 = cz - side * (y / 7);
                int w = y < h - 6 ? 1 : 0;
                for (int dx = -w; dx <= w; dx++)
                    for (int dz = -w; dz <= w; dz++)
                        decor(ox2 + dx, SEA_TOP + 1 + y, oz2 + dz, y % 5 == 4 ? "minecraft:purple_stained_glass" : "minecraft:amethyst_block");
            }
            decor(cx + h / 5, SEA_TOP + 1 + h, cz - side * (h / 7), "minecraft:amethyst_cluster[facing=up]");
            for (int dx = -2; dx <= 2; dx += 4) decor(cx + dx, SEA_TOP + 1, cz + 2, "minecraft:budding_amethyst");
        }

        /**
         * Парящий осколок одной из пройденных локаций: перевёрнутый конус
         * (лес, горы, пустыня, риф, Ад, Энд — по кругу).
         */
        void fragment(int cx, int cz, int y, int r, int k) {
            String[][] worlds = {
                {"minecraft:grass_block", "minecraft:dirt", "minecraft:oak_log"},
                {"minecraft:snow_block", "minecraft:stone", "minecraft:spruce_log"},
                {"minecraft:smooth_sandstone", "minecraft:sandstone", "minecraft:chiseled_sandstone"},
                {"minecraft:prismarine", "minecraft:dark_prismarine", "minecraft:sea_lantern"},
                {"minecraft:crimson_nylium", "minecraft:netherrack", "minecraft:crimson_stem"},
                {"minecraft:end_stone", "minecraft:end_stone", "minecraft:chorus_plant"}};
            String[] w = worlds[Math.floorMod(k + number, worlds.length)];
            for (int depth = 0; depth <= r; depth++) {
                double rr = r - depth * 1.0;
                for (int dx = -r; dx <= r; dx++)
                    for (int dz = -r; dz <= r; dz++)
                        if (dx * dx + dz * dz <= rr * rr + 0.5) decor(cx + dx, y - depth, cz + dz, depth == 0 ? w[0] : w[1]);
            }
            for (int t = 1; t <= 3; t++) decor(cx, y + t, cz, w[2]);
            // Обрывки цепей снизу — осколок «вырван» из своего мира.
            for (int t = 1; t <= 4; t++) decor(cx + 1, y - r - t, cz, "minecraft:chain[axis=y]");
        }

        /** Чёрный шпиль финала с огнём душ на вершине. */
        void blackSpire(int cx, int cz, int h) {
            for (int y = 1; y <= h; y++) {
                int w = y < h / 3 ? 2 : (y < h * 2 / 3 ? 1 : 0);
                String b = y % 7 == 0 ? "minecraft:gilded_blackstone" : (y % 2 == 0 ? "minecraft:basalt[axis=y]" : "minecraft:blackstone");
                for (int dx = -w; dx <= w; dx++)
                    for (int dz = -w; dz <= w; dz++)
                        if (dx * dx + dz * dz <= w * w + 1) decor(cx + dx, SEA_TOP + y, cz + dz, b);
            }
            decor(cx, SEA_TOP + h + 1, cz, "minecraft:soul_soil");
            decor(cx, SEA_TOP + h + 2, cz, "minecraft:soul_fire");
            for (int[] r : new int[][] {{cx + 3, cz}, {cx - 3, cz + 1}}) {
                if (bp.has(r[0], SEA_TOP + 1, r[1])) continue;
                bp.set(r[0], SEA_TOP, r[1], "minecraft:soul_soil"); // роза визера растёт на земле душ
                decor(r[0], SEA_TOP + 1, r[1], "minecraft:wither_rose");
            }
        }

        /** Висящая на цепях клетка с черепом над бездной. */
        void hangingCage(int cx, int cz, int y) {
            for (int dx = -3; dx <= 3; dx++)
                for (int dz = -3; dz <= 3; dz++)
                    if (dx * dx + dz * dz <= 10) decor(cx + dx, y + 8, cz + dz, "minecraft:blackstone");
            for (int t = 1; t <= 4; t++) decor(cx, y + 8 - t, cz, "minecraft:chain[axis=y]");
            for (int dy = 0; dy <= 3; dy++)
                for (int dx = -1; dx <= 1; dx++)
                    for (int dz = -1; dz <= 1; dz++) {
                        boolean wall = Math.abs(dx) == 1 || Math.abs(dz) == 1;
                        if (dy == 0 || dy == 3) decor(cx + dx, y + dy, cz + dz, "minecraft:polished_blackstone");
                        else if (wall) decor(cx + dx, y + dy, cz + dz, "minecraft:iron_bars");
                    }
            decor(cx, y + 1, cz, "minecraft:skeleton_skull[rotation=4]");
            decor(cx, y - 1, cz, "minecraft:soul_lantern[hanging=true]");
        }

        /** Рёбра исполина, торчащие из чёрной земли финала. */
        void giantRibs(int cx, int cz, int side) {
            for (int k = 0; k < 5; k++) {
                int x = cx + k * 3;
                int h = 12 - Math.abs(k - 2) * 2;
                for (int y = 1; y <= h; y++) {
                    int bend = (int) Math.round(Math.sin(y / (double) h * Math.PI / 2) * 5);
                    decor(x, SEA_TOP + y, cz - side * bend, "minecraft:bone_block");
                }
            }
        }

        /** Плоский островок в один слой на уровне воды. */
        void pad(int cx, int cz, int r, String top) {
            for (int dx = -r; dx <= r; dx++)
                for (int dz = -r; dz <= r; dz++)
                    if (Math.sqrt(dx * dx + dz * dz) <= r + 0.3) decor(cx + dx, SEA_TOP, cz + dz, top);
        }

        /** Одна крупная деталь локации; [big] — главная (выше), иначе второстепенная. */
        void feature(int x, int z, int r, boolean big) {
            int y = SEA_TOP + 1;
            switch (theme) {
                case FOREST -> {
                    pad(x, z, r - 1, "minecraft:grass_block");
                    int h = big ? 12 + rnd.nextInt(4) : 7 + rnd.nextInt(3);
                    String log = big ? "minecraft:dark_oak_log" : "minecraft:birch_log";
                    String leaves = big ? "minecraft:dark_oak_leaves[persistent=true]" : "minecraft:birch_leaves[persistent=true]";
                    for (int k = 0; k < h; k++) decor(x, y + k, z, log);
                    int lr = big ? 3 : 2;
                    for (int dx = -lr; dx <= lr; dx++)
                        for (int dz = -lr; dz <= lr; dz++)
                            for (int dy = -2; dy <= 1; dy++)
                                if (dx * dx + dz * dz + dy * dy * 2 <= lr * lr + 1)
                                    decor(x + dx, y + h + dy, z + dz, leaves);
                    decor(x + 2, y, z - 1, "minecraft:brown_mushroom");
                    decor(x - 2, y, z + 1, "minecraft:large_fern[half=lower]");
                    decor(x - 2, y + 1, z + 1, "minecraft:large_fern[half=upper]");
                }
                case MOUNTAIN -> {
                    int h = big ? 13 + rnd.nextInt(3) : 8 + rnd.nextInt(2);
                    shell(x, z, big ? r : r - 2, h, rnd.nextBoolean() ? "minecraft:stone" : "minecraft:andesite", "minecraft:snow_block", 4);
                    decor(x, SEA_TOP + h, z, "minecraft:snow_block");
                }
                case DESERT -> {
                    if (big) {
                        for (int k = 0; k < 12; k++) {
                            String b = k == 11 ? "minecraft:gold_block" : k % 4 == 3 ? "minecraft:chiseled_sandstone" : "minecraft:cut_sandstone";
                            decor(x, y + k, z, b);
                            decor(x + 1, y + k, z, b);
                            decor(x, y + k, z + 1, b);
                            decor(x + 1, y + k, z + 1, b);
                        }
                        pad(x, z, r - 1, "minecraft:sand");
                    } else {
                        dune(x, z, r + 2, 5); // сплошной: песок не висит над пустотой
                        decor(x + r - 1, SEA_TOP + 1, z, "minecraft:dead_bush");
                        for (int k = 0; k < 3; k++) decor(x - r + 1, SEA_TOP + 1 + k, z, "minecraft:cactus");
                    }
                }
                case REEF -> {
                    pad(x, z, r - 1, "minecraft:sand");
                    String[] coral = {"minecraft:tube_coral_block", "minecraft:brain_coral_block",
                            "minecraft:bubble_coral_block", "minecraft:horn_coral_block", "minecraft:fire_coral_block"};
                    int cols = big ? 6 : 4;
                    for (int i = 0; i < cols; i++) {
                        int dx = rnd.nextInt(2 * r - 1) - r + 1, dz = rnd.nextInt(2 * r - 1) - r + 1;
                        int h = big ? 4 + rnd.nextInt(8) : 2 + rnd.nextInt(4);
                        String c = coral[rnd.nextInt(coral.length)];
                        for (int k = 0; k < h; k++) decor(x + dx, y + k, z + dz, c);
                        decor(x + dx, y + h, z + dz, "minecraft:sea_lantern");
                    }
                }
                case NETHER -> {
                    shell(x, z, big ? r : r - 1, big ? 7 : 4, "minecraft:netherrack", "minecraft:crimson_nylium", 1);
                    decor(x, SEA_TOP + (big ? 7 : 4), z, "minecraft:magma_block");
                    if (big) {
                        for (int k = 0; k < 15; k++) {
                            decor(x + r, SEA_TOP + k, z, "minecraft:basalt[axis=y]");
                            decor(x + r, SEA_TOP + k, z + 1, k % 5 == 4 ? "minecraft:glowstone" : "minecraft:polished_basalt[axis=y]");
                        }
                    } else {
                        decor(x - 1, SEA_TOP + 1, z + r - 1, "minecraft:crimson_fungus");
                        decor(x + 1, SEA_TOP + 1, z - r + 1, "minecraft:warped_fungus");
                    }
                }
                case END_ISLES -> {
                    if (big) {
                        for (int k = 0; k < 16; k++) {
                            for (int dx = 0; dx <= 1; dx++)
                                for (int dz = 0; dz <= 1; dz++) decor(x + dx, SEA_TOP + k, z + dz, "minecraft:obsidian");
                        }
                        decor(x, SEA_TOP + 16, z, "minecraft:end_rod[facing=up]");
                        decor(x + 1, SEA_TOP + 16, z + 1, "minecraft:end_rod[facing=up]");
                    } else {
                        // Парящий островок из эндерняка.
                        int fy = SEA_TOP + 6 + rnd.nextInt(4);
                        for (int dx = -r; dx <= r; dx++)
                            for (int dz = -r; dz <= r; dz++) {
                                double d = Math.sqrt(dx * dx + dz * dz);
                                if (d > r + 0.3) continue;
                                decor(x + dx, fy, z + dz, "minecraft:end_stone");
                                if (d < r - 1) decor(x + dx, fy - 1, z + dz, "minecraft:end_stone");
                                if (d < r - 2.5) decor(x + dx, fy - 2, z + dz, "minecraft:end_stone");
                            }
                        decor(x, fy + 1, z, "minecraft:purpur_pillar");
                        decor(x, fy + 2, z, "minecraft:end_rod[facing=up]");
                    }
                }
                case RIFT -> {
                    // Осколки разлома: наклонные столбы обсидиана с аметистом.
                    int h = big ? 14 : 8;
                    for (int k = 0; k < h; k++) {
                        int sx = k / 4;
                        decor(x + sx, SEA_TOP + k, z, k % 3 == 2 ? "minecraft:crying_obsidian" : "minecraft:obsidian");
                        decor(x + sx, SEA_TOP + k, z + 1, "minecraft:obsidian");
                    }
                    decor(x + h / 4, SEA_TOP + h, z, "minecraft:amethyst_block");
                    decor(x + h / 4, SEA_TOP + h + 1, z, "minecraft:amethyst_cluster[facing=up]");
                    pad(x, z, r - 2, "minecraft:obsidian");
                }
                default -> { }
            }
        }

        void billboard(int x, int z, int y, String glass, String light) {
            for (int dx = 0; dx < 6; dx++) {
                for (int dy = 0; dy < 4; dy++) {
                    boolean border = dx == 0 || dx == 5 || dy == 0 || dy == 3;
                    decor(x + dx, y + dy, z, border ? light : glass);
                }
            }
        }

        void balloon(int x, int y, int z, String wool) {
            for (int dx = -2; dx <= 2; dx++) {
                for (int dy = -2; dy <= 2; dy++) {
                    for (int dz = -2; dz <= 2; dz++) {
                        if (dx * dx + dy * dy + dz * dz <= 5) decor(x + dx, y + dy, z + dz, wool);
                    }
                }
            }
            for (int dy = 3; dy <= 6; dy++) decor(x, y - dy, z, "minecraft:chain[axis=y]");
        }

        /** Закрытый бассейн: вода не растекается за борт. */
        void pool(int x0, int x1, int z0, int z1, int y) {
            for (int x = x0; x <= x1; x++) {
                for (int z = z0; z <= z1; z++) {
                    decor(x, y - 1, z, "minecraft:prismarine_bricks");
                    boolean rim = x == x0 || x == x1 || z == z0 || z == z1;
                    decor(x, y, z, rim ? "minecraft:dark_prismarine" : "minecraft:water");
                    if (!rim && (x * 7 + z * 3) % 23 == 0) bp.set(x, y - 1, z, "minecraft:sea_lantern");
                }
            }
        }

        // ------------------------------------------------- точки для действий

        void prepareActionPoints() {
            // Мост: размеченный разрыв между первой платформой и следующей.
            Platform a = platforms.get(bridgeFrom);
            Platform b = platforms.get(bridgeFrom + 1);
            int y = a.y();
            int zA = (int) Math.floor(a.centerZ());
            int zB = (int) Math.floor(b.centerZ());
            int fromX = a.x1() + 1, toX = b.x0() - 1;
            for (int x = fromX; x <= toX; x++) {
                double t = toX == fromX ? 1 : (x - fromX) / (double) (toX - fromX);
                int z = (int) Math.round(zA + (zB - zA) * t);
                for (int dz = 0; dz <= 1; dz++) {
                    if (!bp.has(x, y, z + dz)) bridge.add(new int[] {x, y, z + dz});
                }
            }
            // Метки разрыва: лаймовая полоса под краями обеих платформ.
            for (int z = a.z0(); z <= a.z1(); z++) bp.set(a.x1(), a.y() - 1, z, "minecraft:lime_concrete");
            for (int z = b.z0(); z <= b.z1(); z++) bp.set(b.x0(), b.y() - 1, z, "minecraft:lime_concrete");

            // Срезка: от первой платформы к платформе на 4 позже (не финиш).
            int targetIndex = Math.min(5, platforms.size() - 2);
            Platform from = platforms.get(1);
            Platform to = platforms.get(targetIndex);
            int x0 = (int) Math.floor(from.centerX()), z0 = (int) Math.floor(from.centerZ());
            int x1 = (int) Math.floor(to.centerX()), z1 = (int) Math.floor(to.centerZ());
            int steps = Math.max(Math.abs(x1 - x0), Math.abs(z1 - z0));
            int lastY = from.y();
            int sinceClimb = 0;
            int side = z1 >= z0 ? -3 : 3; // боковая дорожка в стороне от основного маршрута
            for (int i = 1; i < steps; i++) {
                double t = i / (double) steps;
                int x = (int) Math.round(x0 + (x1 - x0) * t);
                double bend = Math.sin(Math.PI * t) * side;
                int z = (int) Math.round(z0 + (z1 - z0) * t + bend);
                int targetY = (int) Math.round(from.y() + (to.y() - from.y()) * t);
                int py = lastY;
                if (targetY > lastY && sinceClimb >= 1) {
                    py = lastY + 1;
                    sinceClimb = 0;
                } else if (targetY < lastY) {
                    py = lastY - 1;
                    sinceClimb = 0;
                } else {
                    sinceClimb++;
                }
                lastY = py;
                if (!bp.has(x, py, z)) shortcut.add(new int[] {x, py, z});
            }
        }

        /**
         * Никаких блоков над головой: над каждой площадкой и над линией каждого
         * прыжка на высоте 3–4 блока (куда достаёт голова в прыжке) убираем всё,
         * что нависает над пустотой. Стены (блок ниже тоже стоит), лестницы,
         * лианы, цепи и сами площадки маршрута не трогаем.
         */
        void clearOverhead() {
            java.util.Set<Long> own = new java.util.HashSet<>();
            for (Platform q : platforms)
                for (int x = q.x0(); x <= q.x1(); x++)
                    for (int z = q.z0(); z <= q.z1(); z++) own.add(Blueprint.key(x, q.y(), z));
            java.util.Set<Long> columns = new java.util.LinkedHashSet<>();
            java.util.Map<Long, Integer> floorY = new java.util.HashMap<>();
            java.util.function.BiConsumer<long[], Integer> add = (xz, y) -> {
                long k = Blueprint.key((int) xz[0], 0, (int) xz[1]);
                columns.add(k);
                floorY.merge(k, y, Math::max);
            };
            for (int i = 0; i < platforms.size(); i++) {
                Platform q = platforms.get(i);
                for (int x = q.x0() - 1; x <= q.x1() + 1; x++)
                    for (int z = q.z0() - 1; z <= q.z1() + 1; z++) add.accept(new long[] {x, z}, q.y());
                if (i + 1 >= platforms.size()) continue;
                Platform n = platforms.get(i + 1);
                for (int s = 0; s <= 24; s++) {
                    double t = s / 24.0;
                    double cx = q.centerX() + (n.centerX() - q.centerX()) * t;
                    double cz = q.centerZ() + (n.centerZ() - q.centerZ()) * t;
                    for (double ex = -0.5; ex <= 0.5; ex += 0.5)
                        for (double ez = -0.5; ez <= 0.5; ez += 0.5)
                            add.accept(new long[] {(long) Math.floor(cx + ex), (long) Math.floor(cz + ez)}, Math.max(q.y(), n.y()));
                }
            }
            for (long c : columns) {
                int x = Blueprint.keyX(c), z = Blueprint.keyZ(c), base = floorY.get(c);
                for (int dy = 2; dy <= 4; dy++) {
                    int y = base + dy;
                    String b = bp.get(x, y, z);
                    if (b == null || own.contains(Blueprint.key(x, y, z))) continue;
                    if (b.contains("ladder") || b.contains("vine") || b.contains("chain")) continue;
                    // Стена или колонна снизу доверху — не потолок.
                    if (bp.has(x, base + 1, z) && bp.has(x, base + 2, z)) continue;
                    bp.remove(x, y, z);
                    decorKeys.remove(Blueprint.key(x, y, z));
                }
            }
        }

        RoomPlan finishPlan() {
            prepareActionPoints();
            int minX = Integer.MAX_VALUE, minY = Integer.MAX_VALUE, minZ = Integer.MAX_VALUE;
            int maxX = Integer.MIN_VALUE, maxY = Integer.MIN_VALUE, maxZ = Integer.MIN_VALUE;
            for (long key : bp.blocks().keySet()) {
                int x = Blueprint.keyX(key), y = Blueprint.keyY(key), z = Blueprint.keyZ(key);
                minX = Math.min(minX, x);
                minY = Math.min(minY, y);
                minZ = Math.min(minZ, z);
                maxX = Math.max(maxX, x);
                maxY = Math.max(maxY, y);
                maxZ = Math.max(maxZ, z);
            }
            int lowest = Integer.MAX_VALUE;
            for (Platform p : platforms) lowest = Math.min(lowest, p.y());
            List<Integer> vanish = new ArrayList<>();
            for (Platform p : platforms) {
                if (p.kind() != Platform.Kind.START && p.kind() != Platform.Kind.FINISH) vanish.add(p.index());
            }
            Platform start = platforms.get(0);
            Platform first = platforms.get(1);
            double sx = start.centerX();
            double sz = start.centerZ();
            float yaw = (float) Math.toDegrees(Math.atan2(-(first.centerX() - sx), first.centerZ() - sz));
            return new RoomPlan(number, theme, platforms, sx, start.y() + 1, sz, yaw, lowest - 5,
                    new int[] {minX, minY, minZ, maxX, maxY, maxZ}, bridge, shortcut, vanish, eyes, bp, decorKeys);
        }
    }
}
