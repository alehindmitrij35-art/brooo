@echo off
rem Dirronlive: builds build\installer\DirronliveSetup-0.5.0.exe on this PC.
rem Needs: Flutter, Visual Studio 2022 (C++ desktop), Inno Setup 6, Node.js 20+.
cd /d "%~dp0"

if not exist windows\runner\main.cpp (
  powershell -ExecutionPolicy Bypass -File tools\setup_windows.ps1 || goto :fail
)
call flutter build windows --release || goto :fail
powershell -ExecutionPolicy Bypass -File tools\bundle_vcruntime.ps1 || goto :fail

set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if not exist "%ISCC%" (
  echo Inno Setup 6 not found. Install it: https://jrsoftware.org/isdl.php
  goto :fail
)
"%ISCC%" installer\dirronlive.iss || goto :fail

echo.
echo DONE: build\installer\DirronliveSetup-0.5.0.exe
explorer build\installer
pause
exit /b 0

:fail
echo.
echo BUILD FAILED
pause
exit /b 1
