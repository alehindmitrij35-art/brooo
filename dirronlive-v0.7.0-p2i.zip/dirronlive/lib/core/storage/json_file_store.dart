import 'dart:convert';
import 'dart:io';

import 'json_store.dart';
import 'storage_exception.dart';

/// JSON-файлы в одной папке. Запись атомарная: сначала во временный
/// файл, затем замена, поэтому сбой посреди записи не портит историю.
class FileJsonStore implements JsonStore {
  FileJsonStore(this.directory);

  final Directory directory;

  @override
  String get location => directory.path;

  File _file(String name) =>
      File('${directory.path}${Platform.pathSeparator}$name');

  @override
  Future<Map<String, Object?>?> read(String name) async {
    final file = _file(name);
    List<int> bytes;
    try {
      if (!await file.exists()) return null;
      bytes = await file.readAsBytes();
    } on FileSystemException catch (e) {
      throw StorageException(
          'Не удалось прочитать файл «$name» (${file.path}): ${_reason(e)}');
    }

    // utf8.decode и jsonDecode бросают FormatException на повреждённых данных.
    var text = utf8.decode(bytes);
    if (text.startsWith('﻿')) text = text.substring(1);
    if (text.trim().isEmpty) return null;

    final decoded = jsonDecode(text);
    if (decoded is! Map<String, Object?>) {
      throw const FormatException('Ожидался JSON-объект');
    }
    return decoded;
  }

  @override
  Future<void> write(String name, Map<String, Object?> data) async {
    final target = _file(name);
    final temp = File('${target.path}.tmp');
    final text = const JsonEncoder.withIndent('  ').convert(data);
    try {
      await directory.create(recursive: true);
      await temp.writeAsString(text, flush: true);
      try {
        await temp.rename(target.path);
      } on FileSystemException {
        // Запасной путь, если замену файла переименованием не дала система.
        await temp.copy(target.path);
        await temp.delete();
      }
    } on FileSystemException catch (e) {
      throw StorageException(
          'Не удалось записать файл «$name» в папку ${directory.path}: '
          '${_reason(e)}');
    }
  }

  @override
  Future<String?> quarantine(String name) async {
    final file = _file(name);
    try {
      if (!await file.exists()) return null;
      final stamp = DateTime.now()
          .toIso8601String()
          .split('.')
          .first
          .replaceAll(':', '-');
      final backupName = '$name.broken-$stamp';
      await file.rename(_file(backupName).path);
      return backupName;
    } on FileSystemException {
      return null;
    }
  }

  static String _reason(FileSystemException e) {
    final osMessage = e.osError?.message.trim();
    if (osMessage != null && osMessage.isNotEmpty) return osMessage;
    return e.message;
  }
}
