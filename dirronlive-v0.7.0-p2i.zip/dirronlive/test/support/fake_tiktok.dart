import 'dart:async';

import 'package:dirronlive/features/tiktok/connector_backend.dart';

/// Подменный коннектор TikTok: тест сам решает, что «присылает» эфир.
class FakeTikTokBackend implements TikTokConnectorBackend {
  final List<FakeTikTokSession> sessions = [];

  FakeTikTokSession get last => sessions.last;

  @override
  TikTokSession start({required String uniqueId, String? apiKey}) {
    final session = FakeTikTokSession(uniqueId, apiKey);
    sessions.add(session);
    return session;
  }
}

class FakeTikTokSession implements TikTokSession {
  FakeTikTokSession(this.uniqueId, this.apiKey);

  final String uniqueId;
  final String? apiKey;
  final StreamController<Map<String, Object?>> _controller =
      StreamController<Map<String, Object?>>();
  bool stopped = false;
  int _msg = 0;

  @override
  Stream<Map<String, Object?>> get messages => _controller.stream;

  void status(String status, {String? kind, String? message}) =>
      _send({
        'type': 'status',
        'status': status,
        if (kind != null) 'kind': kind,
        if (message != null) 'message': message,
      });

  void connected() => status('connected');

  /// Подарок в формате коннектора (normalizeGift в tiktok_connector/lib.mjs).
  void gift({
    String nickname = 'Alex',
    String userId = '42',
    String giftName = 'Rose',
    String giftId = '5655',
    bool streakable = true,
    int repeatCount = 1,
    bool repeatEnd = false,
    String? groupId,
    String? msgId,
  }) =>
      _send({
        'type': 'gift',
        'msgId': msgId ?? 'm${++_msg}-${DateTime.now().microsecondsSinceEpoch}',
        'groupId': groupId,
        'giftId': giftId,
        'giftName': giftName,
        'giftType': streakable ? 1 : 2,
        'streakable': streakable,
        'repeatCount': repeatCount,
        'repeatEnd': repeatEnd,
        'userId': userId,
        'uniqueId': nickname.toLowerCase(),
        'nickname': nickname,
      });

  /// Процесс коннектора завершился.
  Future<void> exit() async {
    if (!_controller.isClosed) await _controller.close();
  }

  void _send(Map<String, Object?> message) {
    if (!_controller.isClosed) _controller.add(message);
  }

  int giftRequests = 0;

  @override
  bool requestGifts() {
    if (stopped) return false;
    giftRequests++;
    return true;
  }

  /// Ответ коннектора с каталогом подарков эфира.
  void catalog(List<Map<String, Object?>> gifts, {String where = 'request'}) =>
      _send({'type': 'gifts', 'source': 'live', 'where': where, 'how': 'fetchAvailableGifts', 'gifts': gifts});

  void catalogError(String message, {String where = 'request'}) => _send({
        'type': 'giftsError',
        'where': where,
        'kind': 'service',
        'message': message,
        'attempts': ['fetchAvailableGifts: $message'],
      });

  @override
  Future<void> stop() async {
    stopped = true;
    // close() после отмены подписки никогда не завершается — не ждём его.
    unawaited(exit());
  }
}
