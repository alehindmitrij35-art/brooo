import '../minecraft/link_protocol.dart';
import '../minecraft/link_state.dart';
import '../parkour/action_catalog.dart';
import '../parkour/gift_catalog.dart';
import '../parkour/parkour_engine.dart';
import '../parkour/parkour_rules.dart';
import '../sky/sky_catalog.dart';
import 'overlay_kind.dart';
import 'overlay_settings.dart';
import 'stream_stats.dart';

/// Всё, из чего строятся оверлеи.
class OverlayInputs {
  const OverlayInputs({
    required this.settings,
    required this.stats,
    required this.link,
    required this.rules,
    required this.catalog,
    required this.now,
  });

  final OverlaySettings settings;
  final StatsState stats;
  final MinecraftLinkState link;
  final List<GiftRule> rules;
  final GiftCatalog catalog;
  final DateTime now;

  bool get test => settings.testMode;
  StatsBucket get bucket => stats.bucket(test);
}

const violet = '#A78BFA';
const coral = '#FF7A90';
const lime = '#A3FF47';
const amber = '#FFC857';

/// Модель отображения оверлея — одна и та же для страницы в TikTok LIVE
/// Studio (JSON → JS) и для предпросмотра в программе.
///
/// Виды: list, hero, goal, timer, battle, vote.
/// У каждого оверлея есть общий «внешний вид» — см. [overlayStyle].
Map<String, Object?> buildOverlayModel(OverlayKind kind, OverlayInputs i) {
  final s = i.settings;
  final b = i.bucket;
  String title(String fallback) {
    final t = s.get<String>(kind, 'title', '');
    return t.trim().isEmpty ? fallback : t.trim();
  }

  final base = <String, Object?>{'slug': kind.slug, 'test': i.test, 'style': overlayStyle(s, kind)};
  switch (kind) {
    case OverlayKind.topLikers:
      return {
        ...base,
        'kind': 'list',
        'title': title('Топ лайкеров'),
        'items': _top(b.likesByViewer, b, s.get(kind, 'count', 5), (v) => '${formatCount(v)} ❤'),
        'empty': 'Лайков пока нет',
      };
    case OverlayKind.topDonors:
      return {
        ...base,
        'kind': 'list',
        'title': title('Топ донатеров'),
        'items': _top(b.coinsByViewer, b, s.get(kind, 'count', 5), (v) => '${formatCount(v)} монет'),
        'empty': 'Подарков пока нет',
      };
    case OverlayKind.bestGift:
      final g = b.bestGift;
      return {
        ...base,
        'kind': 'hero',
        'title': title('Лучший подарок'),
        'icon': g?.image ?? _image(i, g?.giftId),
        'main': g?.giftName ?? 'Ждём подарки',
        'sub': g == null ? '' : '${g.viewer}${g.diamonds > 0 ? ' · ${formatCount(g.diamonds)} монет' : ''}',
      };
    case OverlayKind.bestCombo:
      final g = b.bestCombo;
      return {
        ...base,
        'kind': 'hero',
        'title': title('Лучшее комбо'),
        'icon': g?.image ?? _image(i, g?.giftId),
        'main': g == null ? 'Ждём серию' : '${g.giftName} ×${formatCount(g.count)}',
        'sub': g?.viewer ?? '',
      };
    case OverlayKind.streamTime:
      final manual = s.get<String>(kind, 'manualStart', '');
      final start = _manualStart(manual, i.now) ?? b.startedAt;
      return {
        ...base,
        'kind': 'timer',
        'title': title('В эфире'),
        'startedAtMs': start?.millisecondsSinceEpoch,
        'note': start == null ? 'Укажите время начала в настройках' : '',
      };
    case OverlayKind.goal:
      final type = GoalType.fromId(s.get<String>(kind, 'type', GoalType.anyGifts.id));
      final target = s.get<int>(kind, 'target', 100);
      final giftName = s.get<String>(kind, 'giftName', 'Роза');
      final giftId = s.get<String?>(kind, 'giftId', null);
      final int current = switch (type) {
        GoalType.newFollowers => b.newFollowers,
        GoalType.totalFollowers => (b.followersAtStart ?? 0) + b.newFollowers,
        GoalType.anyGifts => b.giftUnits,
        GoalType.specificGift => b.giftUnitsOf(giftId ?? giftName),
      };
      final left = target - current;
      return {
        ...base,
        'kind': 'goal',
        'title': title(switch (type) {
          GoalType.newFollowers => 'Цель: новые подписчики',
          GoalType.totalFollowers => 'Цель: подписчики',
          GoalType.anyGifts => 'Цель: подарки',
          GoalType.specificGift => 'Цель: $giftName',
        }),
        'icon': type == GoalType.specificGift ? _image(i, giftId) ?? b.giftImages[giftId ?? giftName] : null,
        'current': current,
        'target': target,
        'label': left > 0 ? 'Осталось ${formatCount(left)}' : 'Цель выполнена!',
        'done': left <= 0,
      };
    case OverlayKind.giftMenu:
      return {
        ...base,
        'kind': 'list',
        'title': title('Подарки управляют игрой'),
        'items': [
          for (final r in i.rules)
            if (r.enabled && r.hasGift)
              {
                'icon': r.imageUrl ?? _image(i, r.giftId),
                'name': r.giftName,
                'value': r.actionTitle,
                'color': switch (r.action?.category) {
                  ActionCategory.hindrance => coral,
                  ActionCategory.help => lime,
                  _ => violet,
                },
              },
        ],
        'empty': 'Назначьте подаркам действия',
      };
    case OverlayKind.parkourProgress:
      final p = i.test ? _testParkour : i.link.parkour;
      final best = p.bestSeconds > 0 ? ' · лучшее время ${_clock(p.bestSeconds)}' : '';
      return {
        ...base,
        'kind': 'hero',
        'title': title('Dirron Parkour'),
        'main': p.available ? (p.finished ? 'Паркур пройден!' : 'Комната ${p.room} / 100') : 'Ждём мир паркура',
        'sub': p.available ? 'Рекорд: комната ${p.bestRoom > 0 ? p.bestRoom : p.room}$best' : '',
        'progress': p.available ? (p.finished ? 1.0 : p.room / 100) : 0.0,
      };
    case OverlayKind.viewerAction:
      final a = b.lastAction;
      final streamer = s.streamerName;
      return {
        ...base,
        'kind': 'hero',
        'title': title('Действие зрителя'),
        'main': a == null ? 'Ждём подарки' : _phrase(a, streamer),
        'sub': a == null ? '' : (a.pending ? 'Отсчёт: «${a.actionTitle}»' : a.result),
        'countdownEndMs': a != null && a.pending
            ? a.createdAt.add(Duration(seconds: a.countdownSeconds)).millisecondsSinceEpoch
            : null,
        'accent': a == null ? violet : (a.ok ? lime : coral),
      };
    case OverlayKind.giftBattle:
      final running = s.get(kind, 'running', false);
      final l = b.battleLeft, r = b.battleRight;
      final leftName = s.get<String>(kind, 'leftName', 'Красные');
      final rightName = s.get<String>(kind, 'rightName', 'Синие');
      final status = running
          ? 'Раунд идёт'
          : (l + r == 0 ? 'Раунд не начат' : (l == r ? 'Ничья' : 'Победа: ${l > r ? leftName : rightName}'));
      return {
        ...base,
        'kind': 'battle',
        'title': title('Гифт-батл'),
        'status': status,
        'left': {
          'name': leftName,
          'gift': s.get<String>(kind, 'leftGift', 'Роза'),
          'icon': _image(i, s.get<String?>(kind, 'leftGiftId', null)),
          'score': l,
          'color': coral,
        },
        'right': {
          'name': rightName,
          'gift': s.get<String>(kind, 'rightGift', 'Сердце'),
          'icon': _image(i, s.get<String?>(kind, 'rightGiftId', null)),
          'score': r,
          'color': '#5EC8FF',
        },
      };
    case OverlayKind.chatVote:
      final ones = b.votes.values.where((v) => v == '1').length;
      final twos = b.votes.values.where((v) => v == '2').length;
      final total = ones + twos;
      int pct(int n) => total == 0 ? 0 : (n * 100 / total).round();
      final running = s.get(kind, 'running', false);
      return {
        ...base,
        'kind': 'vote',
        'title': title(s.get<String>(kind, 'question', 'Куда идём дальше?')),
        'status': running ? 'Пишите в чат 1 или 2' : (total == 0 ? 'Голосование не начато' : 'Голосование завершено'),
        'total': total,
        'options': [
          {'key': '1', 'label': s.get<String>(kind, 'option1', 'Вперёд'), 'votes': ones, 'percent': pct(ones)},
          {'key': '2', 'label': s.get<String>(kind, 'option2', 'Назад'), 'votes': twos, 'percent': pct(twos)},
        ],
      };
    case OverlayKind.challenge:
      final status = s.get<String>(kind, 'status', 'active');
      return {
        ...base,
        'kind': 'hero',
        'title': title('Испытание'),
        'main': s.get<String>(kind, 'text', 'Пройти 10 комнат без падений'),
        'sub': switch (status) {
          'done' => 'Выполнено!',
          'failed' => 'Провалено',
          _ => 'В процессе',
        },
        'accent': switch (status) {
          'done' => lime,
          'failed' => coral,
          _ => amber,
        },
      };
    case OverlayKind.roomAttempts:
      final p = i.test ? _testParkour : i.link.parkour;
      return {
        ...base,
        'kind': 'hero',
        'title': title('Попытки'),
        'main': p.available ? 'Комната ${p.room}' : 'Ждём мир паркура',
        'sub': p.available ? 'Попытка ${p.roomFalls + 1}' : '',
      };
    case OverlayKind.skyRift:
      final k = i.test ? _testSky : i.link.sky;
      final a = b.lastAction;
      final notice = a != null && a.actionId.startsWith('sky:') ? '${a.viewerName} · ${a.actionTitle}' : '';
      final ms = k.msAt(i.now);
      return {
        ...base,
        'kind': 'sky',
        'title': title('Небесный разлом'),
        'main': !k.available
            ? 'Ждём мир DirronSky'
            : k.phase == 'finished'
                ? (k.training ? 'Тренировка пройдена' : 'Финиш!')
                : k.training
                    ? 'Тренировка'
                    : 'Сектор ${k.sector < 1 ? 1 : k.sector} / ${k.sectors}',
        'sub': k.available ? (k.paused ? 'Пауза' : 'Кольцо ${k.ring} / ${k.rings}') : '',
        'progress': k.available && k.total > 0 ? (k.passed / k.total).clamp(0.0, 1.0) : 0.0,
        'time': skyClock(ms),
        'runningSince': k.available && k.running ? i.now.millisecondsSinceEpoch - ms : null,
        'errors': k.errors,
        'effects': [
          for (final e in k.effects)
            {
              'title': skyActionById(e.id)?.title ?? e.id,
              'seconds': e.seconds,
              'color': switch (skyActionById(e.id)?.tier) {
                SkyTier.cheap => '#5EEAD4',
                SkyTier.medium => violet,
                SkyTier.expensive => amber,
                null => violet,
              },
            },
        ],
        'queued': k.queued,
        'notice': notice,
        'calm': s.get(kind, 'calm', false),
      };
  }
}

const _testSky = SkyInfo(
  map: 'ready',
  phase: 'running',
  sector: 3,
  sectors: 6,
  ring: 2,
  rings: 7,
  passed: 15,
  total: 43,
  ms: 83400,
  errors: 2,
  effects: [SkyEffectInfo(id: 'crosswind', seconds: 4, viewer: 'Mira'), SkyEffectInfo(id: 'guardian', seconds: 21)],
);

const _testParkour = ParkourInfo(available: true, room: 37, roomFalls: 2, bestRoom: 52, bestSeconds: 751, falls: 14);

List<Map<String, Object?>> _top(Map<String, int> values, StatsBucket b, int count, String Function(int) fmt) {
  final entries = values.entries.toList()..sort((x, y) => y.value.compareTo(x.value));
  return [
    for (var k = 0; k < entries.length && k < count.clamp(1, 10); k++)
      {
        'rank': k + 1,
        'name': b.names[entries[k].key] ?? entries[k].key,
        'value': fmt(entries[k].value),
        // Аватарка зрителя; если её нет — страница покажет первую букву ника.
        'avatar': b.avatars[entries[k].key],
      },
  ];
}

String? _image(OverlayInputs i, String? giftId) => giftId == null ? null : i.catalog.byId(giftId)?.imageUrl;

String _clock(int seconds) {
  final h = seconds ~/ 3600, m = (seconds % 3600) ~/ 60, s = seconds % 60;
  String two(int v) => v.toString().padLeft(2, '0');
  return h > 0 ? '$h:${two(m)}:${two(s)}' : '$m:${two(s)}';
}

/// «ЧЧ:ММ» сегодня (если позже текущего времени — вчера).
DateTime? _manualStart(String text, DateTime now) {
  final m = RegExp(r'^(\d{1,2}):(\d{2})$').firstMatch(text.trim());
  if (m == null) return null;
  final h = int.parse(m.group(1)!), min = int.parse(m.group(2)!);
  if (h > 23 || min > 59) return null;
  var t = DateTime(now.year, now.month, now.day, h, min);
  if (t.isAfter(now)) t = t.subtract(const Duration(days: 1));
  return t;
}

/// Фраза без рода: «Mira отправляет Dirron на уровень 1».
String _phrase(ViewerActionEvent a, String streamer) {
  final v = a.viewerName;
  if (a.pending) return '$v хочет «${a.actionTitle}»';
  if (!a.ok) return '$v: «${a.actionTitle}» не сработало';
  final room = RegExp(r'Комната \d+ → (\d+)').firstMatch(a.result)?.group(1);
  return switch (a.actionId) {
    'to_first_level' => '$v отправляет $streamer на уровень 1',
    'to_last_level' => '$v переносит $streamer на уровень 100',
    'room_back' || 'big_rollback' || 'restart_room' =>
      room != null ? '$v возвращает $streamer на уровень $room' : '$v возвращает $streamer назад',
    'room_forward' => room != null ? '$v переносит $streamer на уровень $room' : '$v переносит $streamer вперёд',
    'push' => '$v толкает $streamer',
    'super_push' => '$v запускает СУПЕР ТОЛЧОК',
    'freeze' => '$v замораживает $streamer',
    'lightning' => '$v бьёт $streamer молнией',
    'shield' => '$v даёт $streamer щит',
    'second_chance' => '$v спасает $streamer от помехи',
    _ => '$v: ${a.actionTitle}',
  };
}

/// Чего не хватает оверлею (для настроек): конкретная причина или `null`.
String? overlayDataIssue(OverlayKind kind, OverlayInputs i) {
  final b = i.stats.live;
  return switch (kind) {
    OverlayKind.topLikers when !b.likesSeen =>
      'Коннектор ещё не прислал лайков в этом эфире. Лайки по зрителям TikTok передаёт только во время '
          'трансляции событием LIKE; если их нет и при активных лайках — TikTok не отдаёт их для этого эфира.',
    OverlayKind.topDonors || OverlayKind.bestGift when b.giftUnits > 0 && !b.pricesSeen =>
      'Подарки пришли без цены: TikTok не передал стоимость, а в каталоге её нет. '
          'Обновите «Каталог подарков» — цены возьмутся оттуда.',
    OverlayKind.streamTime when b.startedAt == null && i.settings.get<String>(kind, 'manualStart', '').isEmpty =>
      'TikTok не прислал время начала трансляции (коннектор подключается к уже идущему эфиру без этих '
          'данных). Укажите время начала вручную.',
    OverlayKind.goal
        when GoalType.fromId(i.settings.get<String>(kind, 'type', '')) == GoalType.totalFollowers &&
            b.followersAtStart == null =>
      'Коннектор не получил число подписчиков стримера — цель «всего подписчиков» считает только '
          'новые подписки этого эфира.',
    OverlayKind.parkourProgress || OverlayKind.roomAttempts => i.link.parkourBlocker,
    OverlayKind.skyRift => i.link.skyBlocker,
    _ => null,
  };
}

/// Рамка оверлея.
enum OverlayFrame {
  card('card', 'С рамкой'),
  plain('plain', 'Без рамки'),
  none('none', 'Без фона');

  const OverlayFrame(this.id, this.label);
  final String id;
  final String label;

  static OverlayFrame fromId(Object? id) =>
      values.firstWhere((f) => f.id == id, orElse: () => OverlayFrame.card);
}

/// Цвета рамки и заголовка на выбор.
const overlayAccents = <String, String>{
  '#A78BFA': 'Фиолетовый',
  '#A3FF47': 'Лайм',
  '#FF7A90': 'Коралл',
  '#4FC3F7': 'Голубой',
  '#FFC857': 'Золото',
  '#FFFFFF': 'Белый',
};

/// Общий внешний вид оверлея: рамка, размер, цвет, прозрачность фона,
/// заголовок и выравнивание. Одинаково для страницы и предпросмотра.
Map<String, Object?> overlayStyle(OverlaySettings s, OverlayKind kind) {
  final accent = s.get<String>(kind, 'accent', '#A78BFA');
  final align = s.get<String>(kind, 'align', 'left');
  return {
    'frame': OverlayFrame.fromId(s.get<String>(kind, 'frame', 'card')).id,
    'scale': s.get<int>(kind, 'scale', 100).clamp(50, 200).toInt(),
    'accent': overlayAccents.containsKey(accent) ? accent : '#A78BFA',
    'bg': s.get<int>(kind, 'bg', 86).clamp(0, 100).toInt(),
    'showTitle': s.get<bool>(kind, 'showTitle', true),
    'align': const ['left', 'center', 'right'].contains(align) ? align : 'left',
  };
}
