package dev.dirronlive.bridge;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.WebSocket;
import java.time.Duration;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

/**
 * WebSocket-клиент мода. Подключается к Dirronlive на 127.0.0.1 и, пока
 * мод работает, сам переподключается после разрыва — порядок запуска игры
 * и программы не важен.
 *
 * <p>Сетевая часть работает в своих потоках; всё, что касается игрока,
 * передаётся в игровой поток через {@link Game#runOnGameThread}.
 * Подтверждение ({@code ack}) отправляется только после того, как подарок
 * показан. Повторный ID подтверждается снова, но не показывается.
 */
public final class BridgeConnection {

    /** То, что мод умеет делать в игре. Реализация для Minecraft — {@code MinecraftGame}. */
    public interface Game {
        /** Можно вызывать из любого потока. */
        boolean isWorldReady();

        void runOnGameThread(Runnable task);

        /** Вызывается в игровом потоке. Возвращает {@code true}, если подарок показан. */
        boolean showGift(BridgeProtocol.Gift gift);

        /**
         * Принять действие паркура (в очередь). Вызывается в игровом потоке;
         * {@code done} вызывается из любого потока: сначала прогресс, в конце —
         * результат с {@code finished == true}. Повтор с тем же {@code total}
         * ничего не добавляет.
         */
        default void runAction(BridgeProtocol.Action action, Consumer<BridgeProtocol.ActionResult> done) {
            done.accept(new BridgeProtocol.ActionResult(false, "Эта версия мода не умеет действия паркура", 0));
        }

        /** Состояние паркура в открытом мире или {@code null}. Можно вызывать из любого потока. */
        default BridgeProtocol.ParkourStatus parkourStatus() {
            return null;
        }

        /** Игровой поток. {@code seconds == 0} — отсчёт отменён, {@code title} — итоговая надпись. */
        default void countdown(BridgeProtocol.Countdown countdown) {}

        /** Сообщение чата TikTok — в чат игры. */
        default void chat(BridgeProtocol.Chat chat) {}

        /** Погода и время в мире. */
        default void world(BridgeProtocol.WorldSettings settings) {}

        /** «Небесный разлом»: команда заезда. Игровой поток; {@code reply} — готовый JSON skyResult. */
        default void skyCommand(BridgeProtocol.SkyCommand command, Consumer<String> reply) {
            reply.accept(BridgeProtocol.skyResult(command.id(), command.cmd(), false, "Эта версия мода не умеет режим полёта"));
        }

        /** Настройки режима полёта. Можно вызывать из любого потока. */
        default void skySettings(BridgeProtocol.SkySettings settings) {}

        /** Действие зрителя в полёте. Игровой поток; {@code reply} — JSON skyAck (может прийти несколько раз). */
        default void skyAction(BridgeProtocol.SkyAction action, Consumer<String> reply) {
            reply.accept(BridgeProtocol.skyAck(action.id(), action.action(), "rejected", "Эта версия мода не умеет режим полёта"));
        }

        /** Состояние режима полёта или {@code null}. Можно вызывать из любого потока. */
        default dev.dirronlive.sky.core.SkyStatus skyStatus() {
            return null;
        }
    }

    private final URI uri;
    private final Game game;
    private final String modVersion;
    private final String minecraftVersion;
    private final long reconnectMillis;
    private final Consumer<String> log;
    private final HttpClient http;
    private final ScheduledExecutorService scheduler;
    private final GiftDeduplicator shown = new GiftDeduplicator(2000);
    private volatile BridgeProtocol.ParkourStatus reportedParkour;
    private volatile dev.dirronlive.sky.core.SkyStatus reportedSky;

    private volatile boolean running;
    private volatile boolean connecting;
    private volatile WebSocket socket;
    private volatile boolean reportedWorldReady;
    private volatile boolean failureLogged;
    private CompletableFuture<Void> sendChain = CompletableFuture.completedFuture(null);

    public BridgeConnection(URI uri, Game game, String modVersion, String minecraftVersion,
                            Duration reconnectDelay, Consumer<String> log) {
        this.uri = uri;
        this.game = game;
        this.modVersion = modVersion;
        this.minecraftVersion = minecraftVersion;
        this.reconnectMillis = Math.max(100, reconnectDelay.toMillis());
        this.log = log;
        this.http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(2)).build();
        this.scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "Dirronlive Bridge");
            t.setDaemon(true);
            return t;
        });
    }

    public static URI defaultUri() {
        int port = Integer.getInteger("dirronlive.port", BridgeProtocol.DEFAULT_PORT);
        return URI.create("ws://127.0.0.1:" + port + "/dirronlive");
    }

    public void start() {
        if (running) return;
        running = true;
        scheduler.scheduleWithFixedDelay(this::ensureConnected, 0, reconnectMillis, TimeUnit.MILLISECONDS);
    }

    public void stop() {
        running = false;
        WebSocket ws = socket;
        socket = null;
        if (ws != null) {
            try {
                ws.sendClose(WebSocket.NORMAL_CLOSURE, "Minecraft закрывается");
            } catch (RuntimeException ignored) {
                // Соединение уже закрыто.
            }
            ws.abort();
        }
        scheduler.shutdownNow();
    }

    public boolean isConnected() {
        return socket != null;
    }

    /** Вызывается каждый игровой тик: сообщает программе о входе в мир и выходе из него. */
    public void onWorldState(boolean ready) {
        if (ready == reportedWorldReady) return;
        reportedWorldReady = ready;
        send(BridgeProtocol.world(ready));
    }

    /** Вызывается каждый тик: сообщает программе комнату и состояние паркура. */
    public void onParkourStatus(BridgeProtocol.ParkourStatus status) {
        if (status == null) status = new BridgeProtocol.ParkourStatus(false, 0, false, 0, 0);
        BridgeProtocol.ParkourStatus last = reportedParkour;
        if (last != null && last.available() == status.available() && last.room() == status.room()
                && last.finished() == status.finished() && last.falls() == status.falls()
                && last.roomFalls() == status.roomFalls() && last.bestRoom() == status.bestRoom()
                && last.queued() == status.queued()
                && Math.abs(last.seconds() - status.seconds()) < 5) {
            return;
        }
        reportedParkour = status;
        send(BridgeProtocol.parkour(status));
    }

    /** Состояние полёта — только при изменении (время — не чаще раза в секунду). */
    public void onSkyStatus(dev.dirronlive.sky.core.SkyStatus status) {
        if (status == null) return;
        if (!status.differs(reportedSky)) return;
        reportedSky = status;
        send(status.toJson());
    }

    private void ensureConnected() {
        if (!running || socket != null || connecting) return;
        connecting = true;
        try {
            http.newWebSocketBuilder()
                    .connectTimeout(Duration.ofSeconds(2))
                    .buildAsync(uri, new Listener())
                    .whenComplete((ws, error) -> {
                        connecting = false;
                        if (error != null) {
                            if (!failureLogged) {
                                failureLogged = true;
                                log.accept("Dirronlive не отвечает на " + uri
                                        + " — жду, пока в программе включат связь с игрой.");
                            }
                        } else if (!running) {
                            ws.abort();
                        }
                    });
        } catch (RuntimeException e) {
            connecting = false;
        }
    }

    private synchronized void send(String text) {
        WebSocket ws = socket;
        if (ws == null) return;
        // Java WebSocket не допускает параллельных отправок — ставим в очередь.
        sendChain = sendChain
                .exceptionally(error -> null)
                .thenCompose(ignored -> ws.sendText(text, true))
                .thenAccept(ignored -> {});
    }

    private void handleText(String text) {
        String type = BridgeProtocol.type(text);
        if ("action".equals(type)) {
            BridgeProtocol.Action action = BridgeProtocol.parseAction(text);
            if (action != null) handleAction(action);
            return;
        }
        if ("skyCommand".equals(type)) {
            BridgeProtocol.SkyCommand c = BridgeProtocol.parseSkyCommand(text);
            if (c == null) return;
            if (!game.isWorldReady()) {
                send(BridgeProtocol.skyResult(c.id(), c.cmd(), false, "Мир не открыт"));
                return;
            }
            game.runOnGameThread(() -> {
                try {
                    game.skyCommand(c, this::send);
                } catch (RuntimeException e) {
                    send(BridgeProtocol.skyResult(c.id(), c.cmd(), false, "Ошибка в моде: " + e.getClass().getSimpleName()));
                }
            });
            return;
        }
        if ("skySettings".equals(type)) {
            BridgeProtocol.SkySettings settings = BridgeProtocol.parseSkySettings(text);
            if (settings != null) game.skySettings(settings);
            return;
        }
        if ("skyAction".equals(type)) {
            BridgeProtocol.SkyAction a = BridgeProtocol.parseSkyAction(text);
            if (a == null) return;
            if (!game.isWorldReady()) {
                send(BridgeProtocol.skyAck(a.id(), a.action(), "rejected", "Мир не открыт"));
                return;
            }
            game.runOnGameThread(() -> {
                try {
                    game.skyAction(a, this::send);
                } catch (RuntimeException e) {
                    send(BridgeProtocol.skyAck(a.id(), a.action(), "rejected", "Ошибка в моде: " + e.getClass().getSimpleName()));
                }
            });
            return;
        }
        if ("world".equals(type)) {
            BridgeProtocol.WorldSettings w = BridgeProtocol.parseWorld(text);
            if (w != null && game.isWorldReady()) game.runOnGameThread(() -> game.world(w));
            return;
        }
        if ("chat".equals(type)) {
            BridgeProtocol.Chat chat = BridgeProtocol.parseChat(text);
            if (chat != null && game.isWorldReady()) game.runOnGameThread(() -> game.chat(chat));
            return;
        }
        if ("countdown".equals(type) || "countdownCancel".equals(type)) {
            BridgeProtocol.Countdown countdown = BridgeProtocol.parseCountdown(text);
            if (countdown != null && game.isWorldReady()) game.runOnGameThread(() -> game.countdown(countdown));
            return;
        }
        BridgeProtocol.Gift gift = BridgeProtocol.parseGift(text);
        if (gift == null) return;
        game.runOnGameThread(() -> deliver(gift));
    }

    private void handleAction(BridgeProtocol.Action action) {
        if (!game.isWorldReady()) {
            send(BridgeProtocol.actionResult(action.id(),
                    new BridgeProtocol.ActionResult(false, "Мир не открыт — действие не выполнено", 0)));
            return;
        }
        game.runOnGameThread(() -> {
            try {
                game.runAction(action, result -> send(BridgeProtocol.actionResult(action.id(), result)));
            } catch (RuntimeException e) {
                send(BridgeProtocol.actionResult(action.id(),
                        new BridgeProtocol.ActionResult(false, "Ошибка в моде: " + e.getClass().getSimpleName(), 0)));
            }
        });
    }

    /** Игровой поток. */
    private void deliver(BridgeProtocol.Gift gift) {
        if (shown.contains(gift.id())) {
            send(BridgeProtocol.ack(gift.id()));
            return;
        }
        if (game.showGift(gift)) {
            shown.remember(gift.id());
            send(BridgeProtocol.ack(gift.id()));
        }
        // Мир не готов — подарок не показан и не подтверждён:
        // программа отметит его «Доставка не подтверждена».
    }

    private void dropped(WebSocket ws, String why) {
        synchronized (this) {
            if (socket != ws) return;
            socket = null;
        }
        failureLogged = false;
        if (running) log.accept("Связь с Dirronlive потеряна (" + why + "), переподключаюсь…");
    }

    private final class Listener implements WebSocket.Listener {
        private final StringBuilder buffer = new StringBuilder();

        @Override
        public void onOpen(WebSocket ws) {
            synchronized (BridgeConnection.this) {
                socket = ws;
                sendChain = CompletableFuture.completedFuture(null);
            }
            failureLogged = false;
            boolean ready = game.isWorldReady();
            reportedWorldReady = ready;
            reportedParkour = null;
            reportedSky = null;
            send(BridgeProtocol.hello(modVersion, minecraftVersion, ready));
            onParkourStatus(game.parkourStatus());
            onSkyStatus(game.skyStatus());
            log.accept("Подключено к Dirronlive (" + uri + ").");
            ws.request(1);
        }

        @Override
        public CompletionStage<?> onText(WebSocket ws, CharSequence data, boolean last) {
            buffer.append(data);
            if (last) {
                String text = buffer.toString();
                buffer.setLength(0);
                handleText(text);
            }
            ws.request(1);
            return null;
        }

        @Override
        public CompletionStage<?> onClose(WebSocket ws, int statusCode, String reason) {
            dropped(ws, "код " + statusCode);
            return null;
        }

        @Override
        public void onError(WebSocket ws, Throwable error) {
            dropped(ws, String.valueOf(error.getMessage()));
        }
    }
}
