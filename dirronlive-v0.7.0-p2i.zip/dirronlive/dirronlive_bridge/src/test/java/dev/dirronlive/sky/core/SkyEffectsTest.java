package dev.dirronlive.sky.core;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import org.junit.jupiter.api.Test;

/** Действия зрителей: лимиты, очередь, повторы, перезарядка, защита, ответы. */
class SkyEffectsTest {
    static final SkyEffects.Context CTX = new SkyEffects.Context(new V3(0, 100, 0), new V3(0, 0, 1.2),
            new Ring(0, 0, new V3(0, 100, 60), new V3(0, 0, 1), 4, Ring.Kind.NORMAL, 0), null);

    static int n;

    static SkyEffects.Request req(String action) {
        return new SkyEffects.Request("e" + (++n), action, 1, 0, 0, "extend", "Mira", false);
    }

    static SkyEffects.Request req(String action, String repeat) {
        return new SkyEffects.Request("e" + (++n), action, 1, 0, 0, repeat, "Mira", false);
    }

    static List<String> states(SkyEffects.Result r) {
        return r.acks.stream().map(SkyEffects.Ack::state).toList();
    }

    static SkyEffects.Result run(SkyEffects fx, int ticks) {
        SkyEffects.Result all = new SkyEffects.Result();
        for (int i = 0; i < ticks; i++) {
            SkyEffects.Result r = fx.tick(true, false, false, null, null, CTX);
            all.acks.addAll(r.acks);
            all.cues.addAll(r.cues);
        }
        return all;
    }

    @Test
    void startsAndFinishes() {
        SkyEffects fx = new SkyEffects();
        SkyEffects.Result r = fx.submit(req("tailwind"), true, true, CTX);
        assertEquals(List.of("accepted", "started"), states(r));
        assertTrue(fx.isActive(SkyEffects.Kind.TAILWIND));
        assertTrue(fx.forces(false).tailwind() > 0);
        assertEquals(Forces.NONE, fx.forces(true), "в защите сил нет");
        SkyEffects.Result end = run(fx, 5 * 20);
        assertEquals(List.of("finished"), states(end));
        assertFalse(fx.isActive(SkyEffects.Kind.TAILWIND));
    }

    @Test
    void sameIdNeverRunsTwice() {
        SkyEffects fx = new SkyEffects();
        SkyEffects.Request r = req("crosswind");
        fx.submit(r, true, true, CTX);
        SkyEffects.Result again = fx.submit(r, true, true, CTX);
        assertEquals(1, again.acks.size());
        assertEquals("started", again.acks.get(0).state());
        assertTrue(again.acks.get(0).reason().contains("повтор"));
        assertEquals(1, fx.active().size());
    }

    @Test
    void movementLimitTwoThenQueue() {
        SkyEffects fx = new SkyEffects();
        fx.submit(req("crosswind"), true, true, CTX);
        fx.submit(req("heavy_wings"), true, true, CTX);
        SkyEffects.Result third = fx.submit(req("turbulence"), true, true, CTX);
        assertEquals(List.of("accepted", "deferred"), states(third));
        assertTrue(third.acks.get(1).reason().contains("эффекта движения"));
        assertEquals(1, fx.queued());
        // Через 5 с ветер закончится — турбулентность стартует сама.
        SkyEffects.Result later = run(fx, 5 * 20);
        assertTrue(states(later).contains("started"));
        assertTrue(fx.isActive(SkyEffects.Kind.TURBULENCE));
        assertEquals(0, fx.queued());
    }

    @Test
    void nonMovementDoesNotCountToMovementLimit() {
        SkyEffects fx = new SkyEffects();
        fx.submit(req("crosswind"), true, true, CTX);
        fx.submit(req("heavy_wings"), true, true, CTX);
        assertEquals(List.of("accepted", "started"), states(fx.submit(req("narrow"), true, true, CTX)));
        assertTrue(fx.ringScale() < 1);
    }

    @Test
    void oneExpensiveAtATime() {
        SkyEffects fx = new SkyEffects();
        assertEquals("started", states(fx.submit(req("guardian"), true, true, CTX)).get(1));
        SkyEffects.Result r = fx.submit(req("slalom"), true, true, CTX);
        assertEquals("deferred", r.acks.get(1).state());
        assertTrue(r.acks.get(1).reason().contains("дорогое"));
    }

    @Test
    void repeatRules() {
        SkyEffects fx = new SkyEffects();
        fx.submit(req("heavy_wings"), true, true, CTX);
        SkyEffects.Result ext = fx.submit(req("heavy_wings", "extend"), true, true, CTX);
        assertEquals("started", ext.acks.get(1).state());
        assertEquals(12, fx.active().get(0).secondsLeft());
        assertEquals("rejected", fx.submit(req("heavy_wings", "ignore"), true, true, CTX).acks.get(1).state());
        assertEquals("deferred", fx.submit(req("heavy_wings", "queue"), true, true, CTX).acks.get(1).state());
    }

    @Test
    void cooldownDefersUntilReady() {
        SkyEffects fx = new SkyEffects();
        fx.submit(new SkyEffects.Request("a", "tailwind", 1, 2, 3, "extend", "", false), true, true, CTX);
        run(fx, 40); // закончился, перезарядка 3 с
        SkyEffects.Result r = fx.submit(new SkyEffects.Request("b", "tailwind", 1, 2, 3, "extend", "", false), true, true, CTX);
        assertEquals("deferred", r.acks.get(1).state());
        assertTrue(r.acks.get(1).reason().startsWith("перезарядка"));
        SkyEffects.Result later = run(fx, 61);
        assertTrue(states(later).contains("started"));
    }

    @Test
    void testIgnoresCooldown() {
        SkyEffects fx = new SkyEffects();
        fx.submit(new SkyEffects.Request("a", "tailwind", 1, 1, 30, "extend", "", false), true, true, CTX);
        run(fx, 20);
        SkyEffects.Result r = fx.submit(new SkyEffects.Request("t", "tailwind", 1, 1, 30, "extend", "", true), true, true, CTX);
        assertEquals("started", r.acks.get(1).state());
    }

    @Test
    void conflictTailwindAndBrake() {
        SkyEffects fx = new SkyEffects();
        fx.submit(req("tailwind"), true, true, CTX);
        SkyEffects.Result r = fx.submit(req("air_brake"), true, true, CTX);
        assertEquals("deferred", r.acks.get(1).state());
        assertTrue(r.acks.get(1).reason().contains("Попутный поток"));
    }

    @Test
    void queueIsBoundedAndExpires() {
        SkyEffects fx = new SkyEffects();
        fx.submit(req("guardian"), true, true, CTX);
        for (int i = 0; i < SkyEffects.MAX_QUEUE; i++) fx.submit(req("slalom", "queue"), true, true, CTX);
        assertEquals(SkyEffects.MAX_QUEUE, fx.queued());
        SkyEffects.Result full = fx.submit(req("storm"), true, true, CTX);
        assertEquals("rejected", full.acks.get(1).state());
        assertEquals("очередь заполнена", full.acks.get(1).reason());
        // Ангел 30 с, ожидание максимум 45 с: часть дождётся, остальные истекут.
        SkyEffects.Result later = run(fx, SkyEffects.QUEUE_TTL + 1);
        assertTrue(later.acks.stream().anyMatch(a -> a.reason().equals("истекло время ожидания")));
        assertTrue(fx.queued() < SkyEffects.MAX_QUEUE);
    }

    @Test
    void notRunningRejectsAndWaitingForFlight() {
        SkyEffects fx = new SkyEffects();
        assertEquals("rejected", fx.submit(req("tailwind"), false, false, CTX).acks.get(1 - 1).state());
        SkyEffects.Result r = fx.submit(req("tailwind"), true, false, CTX);
        assertEquals("deferred", r.acks.get(1).state());
        // Пока защита — не стартует.
        assertTrue(fx.tick(true, true, false, null, null, CTX).acks.isEmpty());
        assertEquals("started", fx.tick(true, false, false, null, null, CTX).acks.get(0).state());
    }

    @Test
    void pauseFreezesEffects() {
        SkyEffects fx = new SkyEffects();
        fx.submit(req("heavy_wings"), true, true, CTX);
        for (int i = 0; i < 500; i++) fx.tick(false, false, false, null, null, CTX);
        assertEquals(6, fx.active().get(0).secondsLeft());
    }

    @Test
    void timeRiftAsksForRewindAndGuardianShield() {
        SkyEffects fx = new SkyEffects();
        SkyEffects.Result r = fx.submit(req("time_rift"), true, true, CTX);
        assertTrue(r.cues.stream().anyMatch(c -> c.type() == SkyEffects.Cue.Type.REWIND && c.value() == 3));
        run(fx, 40);
        SkyEffects.Result g = fx.submit(req("guardian"), true, true, CTX);
        assertTrue(g.cues.stream().anyMatch(c -> c.type() == SkyEffects.Cue.Type.SHIELD_ON));
        SkyEffects.Result used = fx.endEarly(SkyEffects.Kind.GUARDIAN, "щит сработал");
        assertEquals("finished", used.acks.get(0).state());
        assertTrue(used.cues.stream().anyMatch(c -> c.type() == SkyEffects.Cue.Type.SHIELD_OFF));
    }

    @Test
    void slalomGatesPassAndMiss() {
        SkyEffects fx = new SkyEffects();
        fx.submit(req("slalom"), true, true, CTX);
        List<SkyEffects.Gate> gates = fx.gates();
        assertEquals(3, gates.size());
        assertTrue(gates.get(0).ring().center().x() * gates.get(1).ring().center().x() < 0, "влево-вправо");
        // Пролетаем через первые ворота точно, остальные — по центру трассы (мимо).
        V3 g0 = gates.get(0).ring().center();
        SkyEffects.Result a = fx.tick(true, false, false, g0.add(0, 0, -1), g0.add(0, 0, 1), CTX);
        assertTrue(a.cues.stream().anyMatch(c -> c.type() == SkyEffects.Cue.Type.GATE_PASS));
        SkyEffects.Result b = new SkyEffects.Result();
        for (double z = 25; z < 60; z += 3) {
            SkyEffects.Result t = fx.tick(true, false, false, new V3(0, 100, z), new V3(0, 100, z + 3), CTX);
            b.cues.addAll(t.cues);
            b.acks.addAll(t.acks);
        }
        assertEquals(2, b.cues.stream().filter(c -> c.type() == SkyEffects.Cue.Type.GATE_MISS).count());
        assertTrue(states(b).contains("finished"), "слалом закончился, когда все ворота позади");
        assertTrue(fx.gates().isEmpty());
    }

    @Test
    void resetEndsAllAndRejectsQueue() {
        SkyEffects fx = new SkyEffects();
        fx.submit(req("crosswind"), true, true, CTX);
        fx.submit(req("guardian"), true, true, CTX);
        fx.submit(req("storm"), true, true, CTX);
        SkyEffects.Result r = fx.reset("заезд перезапущен");
        assertEquals(List.of("finished", "finished", "rejected"), states(r));
        assertTrue(fx.active().isEmpty());
        assertEquals(0, fx.queued());
        assertFalse(fx.journal().isEmpty());
    }

    @Test
    void unknownActionRejected() {
        SkyEffects fx = new SkyEffects();
        assertEquals("rejected", fx.submit(req("teleport_moon"), true, true, CTX).acks.get(0).state());
    }

    @Test
    void stormGustsAndLightning() {
        SkyEffects fx = new SkyEffects();
        fx.submit(req("storm"), true, true, CTX);
        SkyEffects.Result r = run(fx, 8 * 20);
        assertTrue(r.cues.stream().filter(c -> c.type() == SkyEffects.Cue.Type.LIGHTNING).count() >= 4);
        assertTrue(states(r).contains("finished"));
    }

    @Test
    void shieldForgivesOneCrash() {
        SkyRun run = SkyCoreTest.launched(SkyCoreTest.line(Track.OnMiss.ERROR));
        while (run.protection() > 0) run.tick(SkyCoreTest.fly(new V3(0, 100, 0), new V3(0, 100, 0.5)));
        run.setShield(true);
        List<SkyRun.Event> e = run.tick(new SkyRun.Sample(new V3(0, 100, 1), new V3(0, 100, 1.1), false, false, true));
        assertEquals(SkyRun.EventType.SHIELD, e.get(0).type());
        assertEquals(0, run.crashes());
        assertFalse(run.shield());
    }
}
