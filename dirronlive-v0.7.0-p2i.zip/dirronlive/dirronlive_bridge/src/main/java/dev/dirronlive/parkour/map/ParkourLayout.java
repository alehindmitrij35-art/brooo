package dev.dirronlive.parkour.map;

/**
 * Где на карте стоит каждая комната. Комнаты 10 × 10: строка — тема,
 * столбец — номер внутри десятка. Между комнатами — пустота.
 */
public final class ParkourLayout {
    public static final int ROOMS = 100;
    public static final int SPACING = 140;

    private ParkourLayout() {}

    public static int originX(int baseX, int room) {
        return baseX + ((room - 1) % 10) * SPACING;
    }

    public static int originZ(int baseZ, int room) {
        return baseZ + ((room - 1) / 10) * SPACING;
    }

    /**
     * Dirron Parkour 2: каждая локация — своя «страна» в ряд по X, а между
     * странами по Z больше 1000 блоков пустоты: дальше любой дальности
     * прорисовки (32 чанка = 512 блоков), из одной локации другую не видно.
     */
    public static final int REGION_GAP = 1200;

    /** Номер страны второй карты: 0–5 — локации, 6 — «Разлом», 7 — финал. */
    public static int region(int room) {
        if (room == ROOMS) return 7;
        if (room > 90) return 6;
        return (room - 1) / Theme.SECOND_SPAN;
    }

    /** Место комнаты внутри своей страны. */
    public static int slot(int room) {
        if (room == ROOMS) return 0;
        if (room > 90) return room - 91;
        return (room - 1) % Theme.SECOND_SPAN;
    }

    public static int originX(int variant, int baseX, int room) {
        return variant == 2 ? baseX + slot(room) * SPACING : originX(baseX, room);
    }

    public static int originZ(int variant, int baseZ, int room) {
        return variant == 2 ? baseZ + region(room) * REGION_GAP : originZ(baseZ, room);
    }

    public static RoomPlan plan(int baseX, int baseY, int baseZ, int room) {
        return plan(1, baseX, baseY, baseZ, room);
    }

    /** Комната карты [variant]: 1 — Dirron Parkour, 2 — Dirron Parkour 2 (свои локации и комнаты). */
    public static RoomPlan plan(int variant, int baseX, int baseY, int baseZ, int room) {
        return RoomGenerator.generate(variant, room, originX(variant, baseX, room), baseY, originZ(variant, baseZ, room));
    }
}
