package dev.dirronlive.parkour.world;

import dev.dirronlive.parkour.map.ParkourLayout;
import dev.dirronlive.parkour.map.Platform;
import dev.dirronlive.parkour.map.RoomPlan;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.Registries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.property.Property;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.GameMode;
import net.minecraft.world.GameRules;

/**
 * Карта «Dirron Parkour: 100 комнат» на сервере (во встроенном сервере
 * одиночной игры). Всё здесь выполняется в потоке сервера.
 */
public final class ParkourWorld {
    private static final Map<MinecraftServer, ParkourWorld> INSTANCES = new ConcurrentHashMap<>();

    /** Смещение карты, если её строят в обычном мире командой /parkour build. */
    public static final int FALLBACK_X = 500_000, FALLBACK_Y = 230, FALLBACK_Z = 500_000;

    /** Последний известный статус для моста Dirronlive (читается из потока клиента). */
    public static volatile Status lastStatus = Status.NONE;

    public record Status(boolean available, int room, boolean finished, int falls, long ticks,
                         int roomFalls, int bestRoom, long bestTicks, int queued) {
        public static final Status NONE = new Status(false, 0, false, 0, 0, 0, 0, 0, 0);
    }

    public final MinecraftServer server;
    public final ServerWorld world;
    public final ParkourState state;
    public final TempBlocks temp;
    public final Scheduler scheduler = new Scheduler();
    public final ActionQueue actions = new ActionQueue(this);
    /** Dirron Parkour 2: своя погода и время суток у каждого игрока по его локации. */
    public final Atmosphere atmosphere = new Atmosphere();
    private final Map<Integer, RoomPlan> plans = new HashMap<>();
    private final Map<String, BlockState> parsed = new HashMap<>();
    private final Map<UUID, Session> sessions = new HashMap<>();
    private long tick;

    /** Временное (не сохраняемое) состояние игрока. */
    public static final class Session {
        public BlockPos lastStable;
        public float lastStableYaw;
        public int safetySeconds;
        public final List<Runnable> onLanding = new ArrayList<>();
        public final List<TimedBar> bars = new ArrayList<>();
        public boolean wasOnGround;
        public long freezeUntil;
        ServerBossBar levelBar;
        int shownRoom = -1;
        boolean shownFinished;
    }

    /** Полоса с обратным отсчётом над экраном: «Тяжёлые ботинки — 3.2 с». */
    public static final class TimedBar {
        final ServerBossBar bar;
        final String title;
        final long start, end;
        final String id;

        TimedBar(String id, String title, long start, long end, BossBar.Color color) {
            this.id = id;
            this.title = title;
            this.start = start;
            this.end = end;
            this.bar = new ServerBossBar(Text.literal(title), color, BossBar.Style.PROGRESS);
        }
    }

    private ParkourWorld(MinecraftServer server) {
        this.server = server;
        this.world = server.getOverworld();
        this.state = ParkourState.get(world);
        this.temp = new TempBlocks(this::blueprintState, state);
    }

    public static ParkourWorld get(MinecraftServer server) {
        return INSTANCES.computeIfAbsent(server, ParkourWorld::new);
    }

    public static void forget(MinecraftServer server) {
        INSTANCES.remove(server);
        lastStatus = Status.NONE;
    }

    public long now() {
        return tick;
    }

    // ---------------------------------------------------------------- карта

    public RoomPlan plan(int room) {
        return plans.computeIfAbsent(room, r -> ParkourLayout.plan(state.variant, state.baseX, state.baseY, state.baseZ, r));
    }

    public RoomPlan roomContaining(BlockPos pos) {
        if (!state.built) return null;
        for (int r = 1; r <= ParkourLayout.ROOMS; r++) {
            RoomPlan p = plan(r);
            if (pos.getX() >= p.minX && pos.getX() <= p.maxX && pos.getZ() >= p.minZ && pos.getZ() <= p.maxZ
                    && pos.getY() >= p.minY - 2 && pos.getY() <= p.maxY + 2) {
                return p;
            }
        }
        return null;
    }

    /** «minecraft:furnace[lit=true,facing=north]» → состояние блока. */
    public BlockState parse(String block) {
        return parsed.computeIfAbsent(block, b -> {
            BlockState state = parseState(b);
            return state != null ? state : Blocks.MAGENTA_CONCRETE.getDefaultState();
        });
    }

    /** {@code null}, если такого блока или свойства нет в этой версии Minecraft. */
    public static BlockState parseState(String text) {
        int bracket = text.indexOf('[');
        String id = bracket < 0 ? text : text.substring(0, bracket);
        Identifier identifier = Identifier.tryParse(id);
        if (identifier == null || !Registries.BLOCK.containsId(identifier)) return null;
        Block block = Registries.BLOCK.get(identifier);
        BlockState state = block.getDefaultState();
        if (bracket >= 0 && text.endsWith("]")) {
            for (String pair : text.substring(bracket + 1, text.length() - 1).split(",")) {
                String[] kv = pair.split("=", 2);
                if (kv.length != 2) continue;
                Property<?> property = block.getStateManager().getProperty(kv[0].trim());
                if (property == null) return null;
                BlockState next = withValue(state, property, kv[1].trim());
                if (next == null) return null;
                state = next;
            }
        }
        return state;
    }

    private static <T extends Comparable<T>> BlockState withValue(BlockState state, Property<T> property, String value) {
        for (T candidate : property.getValues()) {
            if (property.name(candidate).equals(value)) return state.with(property, candidate);
        }
        return null;
    }

    /** Как блок выглядит по чертежу карты (воздух, если ничего нет). */
    public BlockState blueprintState(BlockPos pos) {
        RoomPlan p = roomContaining(pos);
        if (p == null) return Blocks.AIR.getDefaultState();
        if (p.number == ParkourLayout.ROOMS && state.eyesLit) {
            for (int[] e : p.eyes) {
                if (e[0] == pos.getX() && e[1] == pos.getY() && e[2] == pos.getZ()) {
                    return Blocks.VERDANT_FROGLIGHT.getDefaultState();
                }
            }
        }
        String block = p.blueprint.get(pos.getX(), pos.getY(), pos.getZ());
        return block == null ? Blocks.AIR.getDefaultState() : parse(block);
    }

    /** Строит одну комнату (используется и при сборке всей карты, и в тестах). */
    public int buildRoom(int room) {
        RoomPlan p = plan(room);
        BlockPos.Mutable pos = new BlockPos.Mutable();
        int count = 0;
        for (Map.Entry<Long, String> e : p.blueprint.blocks().entrySet()) {
            long k = e.getKey();
            pos.set(dev.dirronlive.parkour.map.Blueprint.keyX(k), dev.dirronlive.parkour.map.Blueprint.keyY(k),
                    dev.dirronlive.parkour.map.Blueprint.keyZ(k));
            world.setBlockState(pos, parse(e.getValue()), Block.NOTIFY_LISTENERS | Block.FORCE_STATE);
            count++;
        }
        return count;
    }

    /** Строит всю карту в начале координат базы и настраивает мир. */
    public int buildAll(int baseX, int baseY, int baseZ) {
        state.baseX = baseX;
        state.baseY = baseY;
        state.baseZ = baseZ;
        state.built = true;
        plans.clear();
        int total = 0;
        for (int r = 1; r <= ParkourLayout.ROOMS; r++) total += buildRoom(r);
        if (state.variant == 2) applyBiomes();
        configureWorld();
        state.markDirty();
        return total;
    }

    /** Сколько комнат получили свой биом при последней сборке (для журнала сборки). */
    public int biomesApplied;

    /**
     * Dirron Parkour 2: настоящий биом у каждой комнаты (каждые 15 уровней —
     * свой): небо, туман, цвет травы и воды, частицы и звуки. Биом ставится на
     * всю комнату с запасом 16 блоков по сторонам и на всю высоту полёта.
     */
    public int applyBiomes() {
        var biomes = world.getRegistryManager().get(net.minecraft.registry.RegistryKeys.BIOME);
        int done = 0;
        for (int r = 1; r <= ParkourLayout.ROOMS; r++) {
            String id = dev.dirronlive.parkour.map.Theme.biome(state.variant, r);
            if (id == null) continue;
            var entry = biomes.getEntry(net.minecraft.registry.RegistryKey.of(
                    net.minecraft.registry.RegistryKeys.BIOME, Identifier.of(id)));
            if (entry.isEmpty()) {
                dev.dirronlive.parkour.ParkourMod.LOG.warn("Dirron Parkour 2: нет биома {}", id);
                continue;
            }
            RoomPlan p = plan(r);
            BlockPos from = new BlockPos(p.minX - 16, Math.max(world.getBottomY(), p.minY - 12), p.minZ - 16);
            BlockPos to = new BlockPos(p.maxX + 16, Math.min(world.getTopY() - 1, p.maxY + 40), p.maxZ + 16);
            if (fillBiome(world, from, to, entry.get()) > 0) done++;
            else dev.dirronlive.parkour.ParkourMod.LOG.warn("Dirron Parkour 2: биом комнаты {} не поставлен", r);
        }
        biomesApplied = done;
        return done;
    }

    /**
     * Ставит биом в коробке блоков — как /fillbiome, но сам загружает чанки
     * (команда отказывается работать с чанком, который не «загружен»), и без
     * ограничения на число блоков. Возвращает число изменённых чанков.
     */
    public static int fillBiome(net.minecraft.server.world.ServerWorld world, BlockPos from, BlockPos to,
                                net.minecraft.registry.entry.RegistryEntry<net.minecraft.world.biome.Biome> biome) {
        int minX = Math.min(from.getX(), to.getX()), maxX = Math.max(from.getX(), to.getX());
        int minY = Math.min(from.getY(), to.getY()), maxY = Math.max(from.getY(), to.getY());
        int minZ = Math.min(from.getZ(), to.getZ()), maxZ = Math.max(from.getZ(), to.getZ());
        int bx0 = net.minecraft.world.biome.source.BiomeCoords.fromBlock(minX);
        int bx1 = net.minecraft.world.biome.source.BiomeCoords.fromBlock(maxX);
        int by0 = net.minecraft.world.biome.source.BiomeCoords.fromBlock(minY);
        int by1 = net.minecraft.world.biome.source.BiomeCoords.fromBlock(maxY);
        int bz0 = net.minecraft.world.biome.source.BiomeCoords.fromBlock(minZ);
        int bz1 = net.minecraft.world.biome.source.BiomeCoords.fromBlock(maxZ);
        var sampler = world.getChunkManager().getNoiseConfig().getMultiNoiseSampler();
        java.util.List<net.minecraft.world.chunk.Chunk> changed = new java.util.ArrayList<>();
        for (int cx = minX >> 4; cx <= maxX >> 4; cx++) {
            for (int cz = minZ >> 4; cz <= maxZ >> 4; cz++) {
                final net.minecraft.world.chunk.Chunk chunk = world.getChunk(cx, cz);
                chunk.populateBiomes((x, y, z, noise) ->
                        x >= bx0 && x <= bx1 && y >= by0 && y <= by1 && z >= bz0 && z <= bz1
                                ? biome : chunk.getBiomeForNoiseGen(x, y, z), sampler);
                chunk.setNeedsSaving(true);
                changed.add(chunk);
            }
        }
        // Игрокам рядом — новые биомы сразу (при сборке мира игроков нет).
        world.getChunkManager().chunkLoadingManager.sendChunkBiomePackets(changed);
        return changed.size();
    }

    /** Правила мира для паркура: светлый день, без мобов и урона от падения. */
    public void configureWorld() {
        GameRules rules = world.getGameRules();
        rules.get(GameRules.DO_DAYLIGHT_CYCLE).set(false, server);
        rules.get(GameRules.DO_WEATHER_CYCLE).set(false, server);
        rules.get(GameRules.DO_MOB_SPAWNING).set(false, server);
        rules.get(GameRules.FALL_DAMAGE).set(false, server);
        rules.get(GameRules.DO_IMMEDIATE_RESPAWN).set(true, server);
        rules.get(GameRules.KEEP_INVENTORY).set(true, server);
        rules.get(GameRules.ANNOUNCE_ADVANCEMENTS).set(false, server);
        rules.get(GameRules.DO_FIRE_TICK).set(false, server);
        world.setTimeOfDay(6000);
        world.setWeather(1_000_000, 0, false, false);
        RoomPlan first = plan(1);
        world.setSpawnPos(BlockPos.ofFloored(first.spawnX, first.spawnY, first.spawnZ), first.spawnYaw);
    }

    // --------------------------------------------------------------- игрок

    public PlayerProgress progress(ServerPlayerEntity player) {
        PlayerProgress p = state.progress(player.getUuid());
        if (!p.hasCheckpoint) resetCheckpoint(p);
        return p;
    }

    public Session session(ServerPlayerEntity player) {
        return sessions.computeIfAbsent(player.getUuid(), k -> new Session());
    }

    public void resetCheckpoint(PlayerProgress p) {
        RoomPlan plan = plan(p.room);
        p.cpX = plan.spawnX;
        p.cpY = plan.spawnY;
        p.cpZ = plan.spawnZ;
        p.cpYaw = plan.spawnYaw;
        p.personalCheckpoint = false;
        p.hasCheckpoint = true;
        state.markDirty();
    }

    public void teleportToCheckpoint(ServerPlayerEntity player) {
        PlayerProgress p = progress(player);
        teleport(player, p.cpX, p.cpY, p.cpZ, p.cpYaw);
    }

    public void teleport(ServerPlayerEntity player, double x, double y, double z, float yaw) {
        player.stopRiding();
        player.teleport(world, x, y, z, yaw, 0f);
        player.setVelocity(Vec3d.ZERO);
        player.velocityModified = true;
        player.fallDistance = 0;
    }

    /** Перенос на старт комнаты {@code to} (с обновлением чекпоинта). */
    public void moveToRoom(ServerPlayerEntity player, int to) {
        PlayerProgress p = progress(player);
        int from = p.room;
        to = Math.max(1, Math.min(ParkourLayout.ROOMS, to));
        if (from != to) {
            RoomPlan old = plan(from);
            temp.clear(world, pos -> pos.getX() >= old.minX && pos.getX() <= old.maxX
                    && pos.getZ() >= old.minZ && pos.getZ() <= old.maxZ);
        }
        p.room = to;
        p.finished = false;
        p.roomFalls = 0;
        p.bestRoom = Math.max(p.bestRoom, to);
        resetCheckpoint(p);
        Session s = session(player);
        s.lastStable = null;
        s.onLanding.clear();
        s.safetySeconds = 0;
        teleportToCheckpoint(player);
        RoomPlan plan = plan(to);
        title(player, Text.literal("Комната " + to).formatted(Formatting.LIGHT_PURPLE, Formatting.BOLD),
                Text.literal(plan.theme.title).formatted(Formatting.WHITE));
        updateStatus(player);
    }

    /**
     * Уведомление над хотбаром (одной компактной строкой), а не большим
     * заголовком посреди экрана: «Комната 12 · Лабиринт».
     */
    public void title(ServerPlayerEntity player, Text title, Text subtitle) {
        Text line = subtitle == null || subtitle.getString().isBlank()
                ? title
                : Text.empty().append(title).append(Text.literal(" · ").formatted(Formatting.GRAY)).append(subtitle);
        player.sendMessage(line, true);
    }

    public void actionbar(ServerPlayerEntity player, Text text) {
        player.sendMessage(text, true);
    }

    public void updateStatus(ServerPlayerEntity player) {
        PlayerProgress p = progress(player);
        lastStatus = new Status(state.built, p.room, p.finished, p.falls, p.ticks, p.roomFalls,
                p.bestRoom, p.bestTicks, actions.queued());
        updateLevelBar(player, p);
    }

    /** Индикатор сверху по центру: «УРОВЕНЬ 37 / 100», после финиша — «Паркур пройден!». */
    public void updateLevelBar(ServerPlayerEntity player, PlayerProgress p) {
        Session s = session(player);
        if (!state.built) {
            if (s.levelBar != null) s.levelBar.clearPlayers();
            s.levelBar = null;
            return;
        }
        if (s.levelBar == null) {
            s.levelBar = new ServerBossBar(Text.empty(), BossBar.Color.PURPLE, BossBar.Style.NOTCHED_10);
            s.shownRoom = -1;
        }
        if (!s.levelBar.getPlayers().contains(player)) s.levelBar.addPlayer(player);
        if (s.shownRoom == p.room && s.shownFinished == p.finished) return;
        s.shownRoom = p.room;
        s.shownFinished = p.finished;
        // «ПРОЙДЕНО 37 / 100»: белое слово, лаймовое число, сиреневое «100»;
        // полоса из 10 фиолетовых делений.
        int done = p.finished ? ParkourLayout.ROOMS : Math.max(0, p.room - 1);
        s.levelBar.setName(Text.empty()
                .append(Text.literal("ПРОЙДЕНО ").formatted(Formatting.WHITE, Formatting.BOLD))
                .append(Text.literal(String.valueOf(done)).formatted(Formatting.GREEN, Formatting.BOLD))
                .append(Text.literal(" / ").formatted(Formatting.WHITE, Formatting.BOLD))
                .append(Text.literal(String.valueOf(ParkourLayout.ROOMS)).formatted(Formatting.LIGHT_PURPLE, Formatting.BOLD)));
        s.levelBar.setColor(p.finished ? BossBar.Color.GREEN : BossBar.Color.PURPLE);
        s.levelBar.setPercent(done / (float) ParkourLayout.ROOMS);
    }

    /** Текст индикатора уровня (для проверок). */
    public String levelBarText(ServerPlayerEntity player) {
        Session s = sessions.get(player.getUuid());
        return s == null || s.levelBar == null ? "" : s.levelBar.getName().getString();
    }

    // ---------------------------------------------------------------- тики

    public void tick() {
        tick++;
        scheduler.run(tick);
        temp.tick(world, tick);
        if (state.built) actions.tick(tick);
        if (!state.built) return;
        enableCheats();
        for (ServerPlayerEntity player : world.getPlayers()) {
            tickPlayer(player);
        }
    }

    /**
     * На карте паркура читы включены: /time, /weather, /gamemode и другие
     * команды работают без «Открыть для сети». Включаются один раз, игрокам
     * сразу обновляется список команд.
     */
    void enableCheats() {
        var players = world.getServer().getPlayerManager();
        if (players.areCheatsAllowed()) return;
        players.setCheatsAllowed(true);
        for (ServerPlayerEntity player : players.getPlayerList()) {
            players.sendCommandTree(player);
        }
    }

    public void tickPlayer(ServerPlayerEntity player) {
        if (player.isSpectator()) return;
        // В заезде «Небесного разлома» игроком управляет режим полёта.
        if (dev.dirronlive.sky.SkyWorld.isPilot(server, player.getUuid())) return;
        PlayerProgress p = progress(player);
        boolean firstSight = !sessions.containsKey(player.getUuid());
        Session s = session(player);
        RoomPlan plan = plan(p.room);
        if (state.variant == 2) atmosphere.tick(world, player, p.room, server.getTicks());
        if (firstSight) {
            // Вход в мир: если игрок не в своей комнате (новый мир, старое
            // сохранение) — ставим его на чекпоинт.
            if (!plan.contains(player.getX(), player.getY(), player.getZ())) teleportToCheckpoint(player);
            updateStatus(player);
            return;
        }
        if (player.interactionManager.getGameMode() == GameMode.SURVIVAL) {
            player.changeGameMode(GameMode.ADVENTURE);
        }
        if (!p.finished) p.ticks++;

        double x = player.getX(), y = player.getY(), z = player.getZ();
        boolean onGround = player.isOnGround();

        // Страховочная платформа: появляется под падающим игроком.
        if (s.safetySeconds > 0 && !onGround && player.getVelocity().y < -0.35 && s.lastStable != null
                && y < s.lastStable.getY() - 0.5 && y > plan.fallY) {
            BlockPos center = BlockPos.ofFloored(x, y - 1, z);
            List<BlockPos> pad = new ArrayList<>();
            for (int dx = -1; dx <= 1; dx++) {
                for (int dz = -1; dz <= 1; dz++) {
                    BlockPos at = center.add(dx, 0, dz);
                    if (world.getBlockState(at).isAir()) pad.add(at);
                }
            }
            temp.place(world, pad, Blocks.LIME_STAINED_GLASS.getDefaultState(), tick, s.safetySeconds * 20);
            s.safetySeconds = 0;
            actionbar(player, Text.literal("Страховочная платформа!").formatted(Formatting.GREEN));
        }

        // Падение: ниже порога комнаты или в воду рифов.
        if (y < plan.fallY || (player.isTouchingWater() && y < plan.start().y())) {
            handleFall(player, p, s);
            return;
        }

        if (onGround) {
            BlockPos below = player.getBlockPos().down();
            if (!temp.isTemporary(below) && !world.getBlockState(below).isAir()
                    && plan.blueprint.has(below.getX(), below.getY(), below.getZ())) {
                s.lastStable = below.toImmutable();
                s.lastStableYaw = player.getYaw();
            }
            if (!s.wasOnGround && !s.onLanding.isEmpty()) {
                List<Runnable> pending = new ArrayList<>(s.onLanding);
                s.onLanding.clear();
                pending.forEach(Runnable::run);
            }
        }
        // Финиш: ноги над золотой площадкой (без проверки onGround — сервер
        // узнаёт о касании с задержкой, а над финишем больше негде оказаться).
        if (plan.isOnFinish(x, y, z) && (onGround || player.getVelocity().y <= 0.1)) {
            completeRoom(player, p);
            return;
        }
        s.wasOnGround = onGround;
        tickBars(player, s);
        if (tick % 20 == 0) updateStatus(player);
    }

    public void handleFall(ServerPlayerEntity player, PlayerProgress p, Session s) {
        p.falls++;
        p.roomFalls++;
        state.markDirty();
        if (p.rescueCharges > 0 && s.lastStable != null) {
            p.rescueCharges--;
            BlockPos at = s.lastStable;
            teleport(player, at.getX() + 0.5, at.getY() + 1, at.getZ() + 0.5, s.lastStableYaw);
            actionbar(player, Text.literal("Спасение от падения сработало").formatted(Formatting.GREEN));
        } else {
            teleportToCheckpoint(player);
        }
        world.playSound(null, player.getBlockPos(), SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.PLAYERS, 0.5f, 1.4f);
        updateStatus(player);
    }

    public void completeRoom(ServerPlayerEntity player, PlayerProgress p) {
        if (p.room < ParkourLayout.ROOMS) {
            world.playSound(null, player.getBlockPos(), SoundEvents.ENTITY_PLAYER_LEVELUP, SoundCategory.PLAYERS, 0.7f, 1.2f);
            moveToRoom(player, p.room + 1);
            return;
        }
        if (p.finished) return;
        p.finished = true;
        p.bestRoom = ParkourLayout.ROOMS;
        if (p.bestTicks == 0 || p.ticks < p.bestTicks) p.bestTicks = p.ticks;
        state.markDirty();
        lightEyes(true);
        RoomPlan plan = plan(ParkourLayout.ROOMS);
        Platform f = plan.finish();
        world.spawnParticles(ParticleTypes.FIREWORK, f.centerX(), f.y() + 3, f.centerZ(), 200, 3, 3, 3, 0.2);
        world.playSound(null, player.getBlockPos(), SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, SoundCategory.PLAYERS, 1f, 1f);
        long seconds = p.ticks / 20;
        title(player, Text.literal("ПОБЕДА!").formatted(Formatting.GREEN, Formatting.BOLD),
                Text.literal(String.format("100 комнат за %d:%02d · падений: %d · заново через 10 с",
                        seconds / 60, seconds % 60, p.falls)));
        updateStatus(player);
        // Через 10 секунд — заново с первого уровня.
        scheduler.at(now() + 200, () -> {
            if (!player.isRemoved() && progress(player).finished) {
                progress(player).ticks = 0;
                progress(player).falls = 0;
                moveToRoom(player, 1);
            }
        });
    }

    /** Глаза логотипа в комнате 100: зелёные после победы. */
    public void lightEyes(boolean lit) {
        state.eyesLit = lit;
        state.markDirty();
        RoomPlan plan = plan(ParkourLayout.ROOMS);
        for (int[] e : plan.eyes) {
            BlockPos pos = new BlockPos(e[0], e[1], e[2]);
            world.setBlockState(pos, blueprintState(pos), Block.NOTIFY_LISTENERS);
        }
    }

    // ------------------------------------------------------- полосы таймеров

    public void showBar(ServerPlayerEntity player, String id, String title, int ticks, BossBar.Color color) {
        Session s = session(player);
        s.bars.removeIf(b -> {
            if (b.id.equals(id)) {
                b.bar.clearPlayers();
                return true;
            }
            return false;
        });
        TimedBar bar = new TimedBar(id, title, tick, tick + ticks, color);
        bar.bar.addPlayer(player);
        s.bars.add(bar);
    }

    public void hideBar(ServerPlayerEntity player, String id) {
        session(player).bars.removeIf(b -> {
            if (b.id.equals(id)) {
                b.bar.clearPlayers();
                return true;
            }
            return false;
        });
    }

    void tickBars(ServerPlayerEntity player, Session s) {
        s.bars.removeIf(b -> {
            if (tick >= b.end) {
                b.bar.clearPlayers();
                return true;
            }
            float left = (b.end - tick) / 20f;
            b.bar.setPercent(Math.max(0f, (b.end - tick) / (float) Math.max(1, b.end - b.start)));
            if (tick % 2 == 0) b.bar.setName(Text.literal(String.format("%s — %.1f с", b.title, left)));
            return false;
        });
    }

    /** Обратный отсчёт от Dirronlive («Второй шанс от чата»): полоса у всех игроков. */
    public void countdown(String id, String title, int seconds) {
        for (ServerPlayerEntity player : world.getPlayers()) {
            if (seconds > 0) {
                showBar(player, "countdown:" + id, title, seconds * 20, BossBar.Color.PINK);
            } else {
                hideBar(player, "countdown:" + id);
                if (!title.isEmpty()) actionbar(player, Text.literal(title).formatted(Formatting.AQUA));
            }
        }
    }

    /** Остановка сервера: убрать временные блоки, чтобы в сохранении была чистая карта. */
    public void shutdown() {
        temp.clearAll(world);
        actions.clear();
        for (Session s : sessions.values()) {
            s.bars.forEach(b -> b.bar.clearPlayers());
            if (s.levelBar != null) s.levelBar.clearPlayers();
        }
        scheduler.clear();
    }
}
