package dev.dirronlive.sky;

import dev.dirronlive.bridge.BridgeProtocol;

/** Настройки режима из программы (общие для клиента и сервера в одиночной игре). */
public final class SkyConfig {
    private SkyConfig() {}

    public static volatile BridgeProtocol.SkySettings settings = new BridgeProtocol.SkySettings("balance", "R", false);

    /** Предел частиц для профиля: Производительность / Баланс / Красота. */
    public static int particleBudget() {
        return switch (settings.profile()) {
            case "performance" -> 80;
            case "beauty" -> 300;
            default -> 160;
        };
    }
}
