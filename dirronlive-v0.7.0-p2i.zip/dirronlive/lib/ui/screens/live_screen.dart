import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/events/gift_event.dart';
import '../../features/events/event_log.dart';
import '../../features/events/test_gift.dart';
import '../../features/minecraft/minecraft_link.dart';
import '../../features/modes/modes_catalog.dart';
import '../../features/navigation/app_section.dart';
import '../../features/parkour/parkour_rules.dart';
import '../../features/tiktok/tiktok_controller.dart';
import '../theme/app_colors.dart';
import '../widgets/common.dart';
import '../widgets/event_tile.dart';
import '../widgets/test_gift_button.dart';

/// «Эфир» — стартовый экран для работы во время стрима.
///
/// Сверху узкая полоса состояния, ниже две колонки: слева (треть ширины)
/// текущий режим и проверка подарка, справа лента событий. Лента
/// прокручивается сама по себе, кнопка остаётся на месте.
class LiveScreen extends ConsumerWidget {
  const LiveScreen({super.key});

  static const emptyHint = 'Нажми „Тестовый подарок“, чтобы проверить журнал';
  static const feedKey = Key('event-feed');

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final saveError = ref.watch(eventLogProvider.select((s) => s.saveError));

    return Padding(
      padding: const EdgeInsets.fromLTRB(24, 16, 24, 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const StatusStrip(),
          const SizedBox(height: 16),
          if (saveError != null) ...[
            ErrorBanner(message: saveError),
            const SizedBox(height: 12),
          ],
          const Expanded(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Expanded(flex: 1, child: _LeftColumn()),
                SizedBox(width: 20),
                Expanded(flex: 2, child: _EventFeed()),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// Полоса состояния: TikTok LIVE и Minecraft. Нажатие ведёт в настройки
/// именно этого подключения.
class StatusStrip extends ConsumerWidget {
  const StatusStrip({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final tiktok = ref.watch(tiktokProvider);
    final link = ref.watch(minecraftLinkProvider);
    final navigation = ref.read(currentSectionProvider.notifier);

    return Row(
      children: [
        // Статус Minecraft длиннее, поэтому ему больше места.
        Flexible(
          flex: 2,
          child: _StripItem(
            key: const Key('strip-tiktok'),
            title: 'TikTok LIVE',
            label: tiktok.label,
            color: tiktok.phase.color,
            icon: tiktok.phase.icon,
            onTap: () => navigation.openSettings(SettingsSection.tiktok),
          ),
        ),
        const SizedBox(width: 12),
        Flexible(
          flex: 3,
          child: _StripItem(
            key: const Key('strip-minecraft'),
            title: 'Minecraft',
            label: link.label,
            color: link.phase.color,
            icon: link.phase.icon,
            onTap: () => navigation.openSettings(SettingsSection.minecraft),
          ),
        ),
      ],
    );
  }
}

class _StripItem extends StatelessWidget {
  const _StripItem({
    super.key,
    required this.title,
    required this.label,
    required this.color,
    required this.icon,
    required this.onTap,
  });

  final String title;
  final String label;
  final Color color;
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final radius = BorderRadius.circular(12);
    return Material(
      color: AppColors.surface,
      borderRadius: radius,
      child: InkWell(
        borderRadius: radius,
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            borderRadius: radius,
            border: Border.all(color: color.withAlpha(100)),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 18, color: color),
              const SizedBox(width: 8),
              Text(
                title,
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                  color: AppColors.text,
                ),
              ),
              const SizedBox(width: 10),
              Flexible(
                child: Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    color: color,
                  ),
                ),
              ),
              const SizedBox(width: 6),
              const Icon(
                Icons.chevron_right_rounded,
                size: 18,
                color: AppColors.textFaint,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _LeftColumn extends ConsumerWidget {
  const _LeftColumn();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final worldReady = ref.watch(minecraftLinkProvider.select((s) => s.worldReady));
    final parkour = ref.watch(minecraftLinkProvider.select((s) => s.parkour));
    final rules = ref.watch(parkourRulesProvider);
    final navigation = ref.read(currentSectionProvider.notifier);
    final enabledRules = rules.rules.where((r) => r.enabled).length;

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Panel(
            key: const Key('current-mode'),
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const _BlockTitle(
                  icon: Icons.sports_esports_rounded,
                  title: 'Текущий режим',
                ),
                const SizedBox(height: 10),
                Text(
                  rules.modeActive ? 'Dirron Parkour: 100 комнат' : 'Режим не выбран',
                  key: const Key('current-mode-title'),
                  style: const TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.w700,
                    color: AppColors.text,
                  ),
                ),
                const SizedBox(height: 12),
                OutlinedButton.icon(
                  key: const Key('view-modes'),
                  onPressed: () {
                    ref.read(openModeProvider.notifier).open(null);
                    navigation.open(AppSection.modes);
                  },
                  icon: const Icon(Icons.grid_view_rounded, size: 18),
                  label: Text(rules.modeActive
                      ? 'Правил: $enabledRules${parkour.available ? ' · комната ${parkour.room}' : ''}'
                      : 'Посмотреть режимы'),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Panel(
            key: const Key('gift-check'),
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const _BlockTitle(
                  icon: Icons.card_giftcard_rounded,
                  title: 'Проверка подарка',
                ),
                const SizedBox(height: 6),
                Text(
                  worldReady
                      ? 'Мир готов: подарок появится в игре.'
                      : 'Мир не готов: подарок попадёт только в журнал.',
                  style: TextStyle(
                    fontSize: 13,
                    color: worldReady ? AppColors.success : AppColors.textMuted,
                  ),
                ),
                const SizedBox(height: 14),
                TestGiftButton(
                  onPressed: () => ref.read(testGiftSenderProvider).send(),
                ),
                const SizedBox(height: 10),
                const _TestComboButton(),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// «Тестовое комбо ×10»: серия из 10 «Роз» за 3 секунды, как в TikTok.
class _TestComboButton extends ConsumerWidget {
  const _TestComboButton();

  static const buttonKey = Key('test-combo-button');

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final combo = ref.watch(testComboProvider);
    return OutlinedButton.icon(
      key: buttonKey,
      onPressed: combo.running
          ? null
          : () => ref.read(testComboProvider.notifier).start(),
      style: OutlinedButton.styleFrom(
        foregroundColor: AppColors.accentAlt,
        side: const BorderSide(color: AppColors.accentAlt),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      ),
      icon: const Icon(Icons.bolt_rounded, size: 20),
      label: Text(
        combo.running
            ? 'Комбо идёт… ×${combo.count}'
            : 'Тестовое комбо ×${TestComboController.steps}',
      ),
    );
  }
}

class _BlockTitle extends StatelessWidget {
  const _BlockTitle({required this.icon, required this.title});

  final IconData icon;
  final String title;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(icon, size: 20, color: AppColors.accent),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            title,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w700,
              color: AppColors.text,
            ),
          ),
        ),
      ],
    );
  }
}

class _EventFeed extends ConsumerStatefulWidget {
  const _EventFeed();

  @override
  ConsumerState<_EventFeed> createState() => _EventFeedState();
}

class _EventFeedState extends ConsumerState<_EventFeed> {
  static const highlightFor = Duration(milliseconds: 700);

  /// Записи, которые уже были на экране (их не подсвечиваем).
  late final Set<String> _known;

  /// Только что пришедшие записи — подсвечены 0,7 с.
  final Set<String> _fresh = {};
  final List<Timer> _timers = [];

  @override
  void initState() {
    super.initState();
    _known = {for (final e in ref.read(eventLogProvider).events) e.id};
  }

  @override
  void dispose() {
    for (final timer in _timers) {
      timer.cancel();
    }
    super.dispose();
  }

  void _onEvents(List<GiftEvent> events) {
    final arrived = [
      for (final e in events)
        if (_known.add(e.id)) e.id,
    ];
    if (arrived.isEmpty || !mounted) return;
    setState(() => _fresh.addAll(arrived));
    _timers.add(Timer(highlightFor, () {
      if (!mounted) return;
      setState(() => _fresh.removeAll(arrived));
    }));
  }

  @override
  Widget build(BuildContext context) {
    ref.listen<List<GiftEvent>>(
      eventLogProvider.select((s) => s.events),
      (previous, next) => _onEvents(next),
    );
    final events = ref.watch(eventLogProvider.select((s) => s.events));
    final navigation = ref.read(currentSectionProvider.notifier);

    return Panel(
      padding: const EdgeInsets.fromLTRB(14, 12, 12, 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  'Последние события',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: Theme.of(context).textTheme.titleMedium,
                ),
              ),
              Text(
                'Всего: ${events.length}',
                key: const Key('events-total'),
                style: const TextStyle(fontSize: 13, color: AppColors.textMuted),
              ),
              const SizedBox(width: 4),
              TextButton(
                key: const Key('open-history'),
                onPressed: () => navigation.open(AppSection.history),
                child: const Text('Вся история'),
              ),
            ],
          ),
          const Divider(height: 12, color: AppColors.border),
          Expanded(
            child: events.isEmpty
                ? const _EmptyHint()
                : ListView.separated(
                    key: LiveScreen.feedKey,
                    padding: const EdgeInsets.only(right: 8),
                    itemCount: events.length,
                    separatorBuilder: (context, index) =>
                        const Divider(height: 1, color: AppColors.border),
                    itemBuilder: (context, index) => EventTile(
                      key: ValueKey(events[index].id),
                      event: events[index],
                      highlighted: _fresh.contains(events[index].id),
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}

class _EmptyHint extends StatelessWidget {
  const _EmptyHint();

  @override
  Widget build(BuildContext context) {
    return const Center(
      key: Key('empty-hint'),
      child: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.touch_app_rounded, color: AppColors.accent, size: 32),
            SizedBox(height: 10),
            Text(
              LiveScreen.emptyHint,
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 15, color: AppColors.textMuted),
            ),
          ],
        ),
      ),
    );
  }
}
