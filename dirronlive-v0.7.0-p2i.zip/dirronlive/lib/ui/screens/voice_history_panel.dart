import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../features/chat/chat_voice.dart';
import '../theme/app_colors.dart';
import '../widgets/common.dart';

/// История озвучки: кто, что, когда, через сколько секунд прозвучало,
/// каким голосом, что пропущено и почему. Можно повторить сообщение.
class VoiceHistoryPanel extends ConsumerWidget {
  const VoiceHistoryPanel({super.key});

  static const shown = 60;

  static String _time(DateTime t) =>
      '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}:${t.second.toString().padLeft(2, '0')}';

  static String _wait(int ms) => '${(ms / 1000).toStringAsFixed(1).replaceAll('.', ',')} с';

  static (String, Color) _status(String s) => switch (s) {
        'spoken' => ('озвучено', AppColors.success),
        'skipped' => ('пропущено', AppColors.warning),
        _ => ('ошибка', AppColors.danger),
      };

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final entries = ref.watch(voiceHistoryProvider);
    final relay = ref.watch(chatRelayProvider);
    final avg = ref.read(voiceHistoryProvider.notifier).averageWaitMs();
    final spoken = entries.where((e) => e.status == 'spoken').length;
    final skipped = entries.where((e) => e.status == 'skipped').length;
    return Column(
      key: const Key('voice-history'),
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Expanded(
              child: Text('История озвучки',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.text)),
            ),
            if (entries.isNotEmpty)
              TextButton(
                key: const Key('voice-history-clear'),
                onPressed: () => ref.read(voiceHistoryProvider.notifier).clear(),
                child: const Text('Очистить'),
              ),
          ],
        ),
        const SizedBox(height: 4),
        Wrap(
          spacing: 8,
          runSpacing: 6,
          children: [
            TagChip(label: 'озвучено $spoken', color: AppColors.success),
            if (skipped > 0) TagChip(label: 'пропущено $skipped', color: AppColors.warning),
            TagChip(label: 'в очереди ${relay.queued}', color: AppColors.accent),
            if (avg != null)
              TagChip(
                key: const Key('voice-history-avg'),
                label: 'средняя задержка ${_wait(avg)}',
                color: avg <= 3000 ? AppColors.success : AppColors.warning,
              ),
          ],
        ),
        const SizedBox(height: 10),
        if (entries.isEmpty)
          const Text(
            'Здесь будут озвученные сообщения: ник, текст, через сколько секунд прозвучало и каким голосом. '
            'Нажмите «Проверить» выше, чтобы попробовать.',
            style: TextStyle(fontSize: 13, color: AppColors.textFaint),
          ),
        for (final (i, e) in entries.take(shown).indexed)
          Padding(
            key: Key('voice-history-$i'),
            padding: const EdgeInsets.symmetric(vertical: 5),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  width: 70,
                  child: Text(_time(e.at), style: const TextStyle(fontSize: 12, color: AppColors.textFaint)),
                ),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text.rich(
                        TextSpan(children: [
                          if (e.viewer.isNotEmpty)
                            TextSpan(
                              text: '${e.viewer}: ',
                              style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.text),
                            ),
                          TextSpan(text: e.message, style: const TextStyle(color: AppColors.text)),
                        ]),
                        style: const TextStyle(fontSize: 14),
                      ),
                      Text(
                        [
                          if (e.status == 'spoken') 'через ${_wait(e.waitMs)}',
                          if (e.status == 'skipped') e.reason,
                          if (e.engine.isNotEmpty) e.engine,
                        ].join(' · '),
                        style: const TextStyle(fontSize: 12, color: AppColors.textMuted),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                TagChip(label: _status(e.status).$1, color: _status(e.status).$2),
                IconButton(
                  key: Key('voice-replay-$i'),
                  tooltip: 'Повторить',
                  onPressed: () => ref.read(chatRelayProvider.notifier).replay(e),
                  icon: const Icon(Icons.replay_rounded, size: 18),
                ),
              ],
            ),
          ),
        if (entries.length > shown)
          Text('Показаны последние $shown из ${entries.length}',
              style: const TextStyle(fontSize: 12, color: AppColors.textFaint)),
      ],
    );
  }
}
