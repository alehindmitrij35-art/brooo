import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../features/overlays/overlay_kind.dart';
import '../../../features/overlays/overlay_models.dart';
import '../../../features/overlays/overlay_server.dart';
import '../../../features/overlays/overlay_settings.dart';
import '../../../features/overlays/stream_stats.dart';
import '../../theme/app_colors.dart';
import '../../theme/app_theme.dart';
import '../parkour/gift_catalog_dialog.dart';
import 'overlay_preview.dart';

/// «Настроить» оверлей: подписи, цель, стороны батла, вопрос голосования,
/// испытание и т. п. Если коннектор не даёт данных — конкретная причина.
class OverlayConfigDialog extends ConsumerStatefulWidget {
  const OverlayConfigDialog({super.key, required this.kind});

  final OverlayKind kind;

  static Future<void> show(BuildContext context, OverlayKind kind) =>
      showDialog<void>(context: context, builder: (_) => OverlayConfigDialog(kind: kind));

  @override
  ConsumerState<OverlayConfigDialog> createState() => _OverlayConfigDialogState();
}

class _OverlayConfigDialogState extends ConsumerState<OverlayConfigDialog> {
  final Map<String, TextEditingController> _text = {};

  OverlayKind get kind => widget.kind;

  TextEditingController _ctl(String key, String fallback) => _text.putIfAbsent(
        key,
        () => TextEditingController(text: '${ref.read(overlaySettingsProvider).of(kind)[key] ?? fallback}'),
      );

  @override
  void dispose() {
    for (final c in _text.values) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _set(String key, Object? value) => ref.read(overlaySettingsProvider.notifier).set(kind, key, value);

  Widget _field(String key, String label, String fallback, {String? hint, bool number = false}) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: TextField(
          key: Key('cfg-$key'),
          controller: _ctl(key, fallback),
          keyboardType: number ? TextInputType.number : TextInputType.text,
          inputFormatters: number ? [FilteringTextInputFormatter.digitsOnly] : null,
          style: const TextStyle(fontSize: 15, color: AppColors.text),
          decoration: appInputDecoration(label: label, hint: hint),
          onChanged: (v) => _set(key, number ? (int.tryParse(v) ?? 0) : v),
        ),
      );

  Future<void> _pickGift(String nameKey, String idKey) async {
    final gift = await GiftCatalogDialog.show(context, pick: true);
    if (gift == null) return;
    await ref.read(overlaySettingsProvider.notifier).update(kind, {
      nameKey: gift.displayName,
      idKey: gift.id.isEmpty ? null : gift.id,
    });
  }

  /// «Внешний вид» — общий для всех оверлеев: рамка, размер, цвет, фон,
  /// заголовок, выравнивание и сброс.
  List<Widget> _lookSection(OverlaySettings settings) {
    final style = overlayStyle(settings, kind);
    final frame = OverlayFrame.fromId(style['frame']);
    final scale = (style['scale']! as int).toDouble();
    final bg = (style['bg']! as int).toDouble();
    const muted = TextStyle(fontSize: 13, color: AppColors.textMuted);
    return [
      const SizedBox(height: 16),
      const Text('Внешний вид',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: AppColors.text)),
      const SizedBox(height: 8),
      Wrap(spacing: 6, runSpacing: 6, children: [
        for (final f in OverlayFrame.values)
          ChoiceChip(
            key: Key('cfg-frame-${f.id}'),
            label: Text(f.label),
            selected: f == frame,
            onSelected: (_) => _set('frame', f.id),
          ),
      ]),
      const SizedBox(height: 10),
      Text('Размер: ${scale.round()}%', key: const Key('cfg-scale-label'), style: muted),
      Slider(
        key: const Key('cfg-scale'),
        value: scale,
        min: 50,
        max: 200,
        divisions: 30,
        label: '${scale.round()}%',
        onChanged: (v) => _set('scale', v.round()),
      ),
      if (frame != OverlayFrame.none) ...[
        Text('Непрозрачность фона: ${bg.round()}%', style: muted),
        Slider(
          key: const Key('cfg-bg'),
          value: bg,
          min: 0,
          max: 100,
          divisions: 20,
          label: '${bg.round()}%',
          onChanged: (v) => _set('bg', v.round()),
        ),
      ],
      const Text('Цвет рамки и заголовка', style: muted),
      const SizedBox(height: 6),
      Wrap(spacing: 8, runSpacing: 8, children: [
        for (final e in overlayAccents.entries)
          Tooltip(
            message: e.value,
            child: InkWell(
              key: Key('cfg-accent-${e.key.substring(1)}'),
              borderRadius: BorderRadius.circular(20),
              onTap: () => _set('accent', e.key),
              child: Container(
                width: 30,
                height: 30,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Color(int.parse('FF${e.key.substring(1)}', radix: 16)),
                  border: Border.all(
                    color: style['accent'] == e.key ? AppColors.text : Colors.transparent,
                    width: 3,
                  ),
                ),
              ),
            ),
          ),
      ]),
      const SizedBox(height: 10),
      SwitchListTile(
        key: const Key('cfg-show-title'),
        contentPadding: EdgeInsets.zero,
        title: const Text('Показывать заголовок', style: TextStyle(fontSize: 14, color: AppColors.text)),
        value: style['showTitle'] == true,
        onChanged: (v) => _set('showTitle', v),
      ),
      Wrap(spacing: 6, runSpacing: 6, crossAxisAlignment: WrapCrossAlignment.center, children: [
        const Text('Выравнивание:', style: muted),
        for (final a in const [('left', 'Слева'), ('center', 'По центру'), ('right', 'Справа')])
          ChoiceChip(
            key: Key('cfg-align-${a.$1}'),
            label: Text(a.$2),
            selected: style['align'] == a.$1,
            onSelected: (_) => _set('align', a.$1),
          ),
      ]),
      const SizedBox(height: 10),
      TextButton.icon(
        key: const Key('cfg-look-reset'),
        onPressed: () => ref.read(overlaySettingsProvider.notifier).update(kind, {
          'frame': null,
          'scale': null,
          'bg': null,
          'accent': null,
          'showTitle': null,
          'align': null,
        }),
        icon: const Icon(Icons.restart_alt_rounded, size: 18),
        label: const Text('Вернуть вид по умолчанию'),
      ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    final settings = ref.watch(overlaySettingsProvider);
    final inputs = ref.watch(overlayInputsProvider);
    final server = ref.watch(overlayServerProvider);
    final issue = overlayDataIssue(kind, inputs);
    final test = settings.testMode;
    final stats = ref.read(streamStatsProvider.notifier);

    final fields = <Widget>[
      _field('title', 'Заголовок', '', hint: 'по умолчанию — «${kind.title}»'),
    ];
    switch (kind) {
      case OverlayKind.topLikers:
      case OverlayKind.topDonors:
        fields.add(_field('count', 'Сколько мест показывать (1–10)', '5', number: true));
      case OverlayKind.streamTime:
        fields.add(_field('manualStart', 'Начало трансляции вручную (ЧЧ:ММ)', '',
            hint: 'если TikTok не прислал время, например 19:30'));
      case OverlayKind.goal:
        final type = GoalType.fromId(settings.get<String>(kind, 'type', GoalType.anyGifts.id));
        fields.add(Wrap(
          spacing: 6,
          runSpacing: 6,
          children: [
            for (final t in GoalType.values)
              ChoiceChip(
                key: Key('cfg-goal-${t.id}'),
                label: Text(t.label),
                selected: t == type,
                onSelected: (_) => _set('type', t.id),
              ),
          ],
        ));
        fields.add(const SizedBox(height: 10));
        fields.add(_field('target', 'Цель (число)', '100', number: true));
        if (type == GoalType.specificGift) {
          fields.add(OutlinedButton.icon(
            key: const Key('cfg-goal-gift'),
            onPressed: () => _pickGift('giftName', 'giftId'),
            icon: const Icon(Icons.redeem_rounded, size: 18),
            label: Text('Подарок: ${settings.get<String>(kind, 'giftName', 'Роза')}'),
          ));
        }
      case OverlayKind.giftBattle:
        final running = settings.get(kind, 'running', false);
        fields
          ..add(_field('leftName', 'Левая сторона', 'Красные'))
          ..add(OutlinedButton.icon(
            key: const Key('cfg-battle-left-gift'),
            onPressed: () => _pickGift('leftGift', 'leftGiftId'),
            icon: const Icon(Icons.redeem_rounded, size: 18),
            label: Text('Подарок левых: ${settings.get<String>(kind, 'leftGift', 'Роза')}'),
          ))
          ..add(const SizedBox(height: 10))
          ..add(_field('rightName', 'Правая сторона', 'Синие'))
          ..add(OutlinedButton.icon(
            key: const Key('cfg-battle-right-gift'),
            onPressed: () => _pickGift('rightGift', 'rightGiftId'),
            icon: const Icon(Icons.redeem_rounded, size: 18),
            label: Text('Подарок правых: ${settings.get<String>(kind, 'rightGift', 'Сердце')}'),
          ))
          ..add(const SizedBox(height: 12))
          ..add(Wrap(spacing: 8, children: [
            FilledButton(
              key: const Key('cfg-battle-start'),
              onPressed: running
                  ? null
                  : () async {
                      stats.startBattle(test: test);
                      await _set('running', true);
                    },
              child: const Text('Запустить раунд'),
            ),
            OutlinedButton(
              key: const Key('cfg-battle-stop'),
              onPressed: running ? () => _set('running', false) : null,
              child: const Text('Завершить раунд'),
            ),
          ]));
      case OverlayKind.chatVote:
        final running = settings.get(kind, 'running', false);
        fields
          ..add(_field('question', 'Вопрос', 'Куда идём дальше?'))
          ..add(_field('option1', 'Вариант 1', 'Вперёд'))
          ..add(_field('option2', 'Вариант 2', 'Назад'))
          ..add(Wrap(spacing: 8, children: [
            FilledButton(
              key: const Key('cfg-vote-start'),
              onPressed: running
                  ? null
                  : () async {
                      stats.startVote(test: test);
                      await _set('running', true);
                    },
              child: const Text('Начать голосование'),
            ),
            OutlinedButton(
              key: const Key('cfg-vote-stop'),
              onPressed: running ? () => _set('running', false) : null,
              child: const Text('Завершить'),
            ),
          ]));
      case OverlayKind.challenge:
        fields
          ..add(_field('text', 'Задача на эфир', 'Пройти 10 комнат без падений'))
          ..add(Wrap(spacing: 8, children: [
            FilledButton(
              key: const Key('cfg-challenge-done'),
              onPressed: () => _set('status', 'done'),
              child: const Text('Выполнено'),
            ),
            OutlinedButton(
              key: const Key('cfg-challenge-failed'),
              onPressed: () => _set('status', 'failed'),
              child: const Text('Провалено'),
            ),
            TextButton(
              key: const Key('cfg-challenge-reset'),
              onPressed: () => _set('status', 'active'),
              child: const Text('Снова в процессе'),
            ),
          ]));
      case OverlayKind.viewerAction:
        fields.add(TextField(
          key: const Key('cfg-streamer'),
          controller: _text.putIfAbsent('streamer', () => TextEditingController(text: settings.streamerName)),
          style: const TextStyle(fontSize: 15, color: AppColors.text),
          decoration: appInputDecoration(label: 'Имя стримера во фразе', hint: 'Dirron'),
          onChanged: (v) => ref.read(overlaySettingsProvider.notifier).setStreamerName(v),
        ));
      case OverlayKind.skyRift:
        fields.add(Row(
          children: [
            const Expanded(
              child: Text('Меньше вспышек (без анимации уведомлений)',
                  style: TextStyle(fontSize: 14, color: AppColors.text)),
            ),
            Switch(
              key: const Key('cfg-sky-calm'),
              value: settings.get(kind, 'calm', false),
              onChanged: (v) => _set('calm', v),
            ),
          ],
        ));
      default:
        break;
    }
    fields.addAll(_lookSection(settings));

    return Dialog(
      key: Key('overlay-config-dialog-${kind.slug}'),
      backgroundColor: AppColors.surface,
      insetPadding: const EdgeInsets.all(24),
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: 980, maxHeight: MediaQuery.sizeOf(context).height - 48),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Text(kind.title,
                          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: AppColors.text)),
                      const SizedBox(height: 4),
                      SelectableText('TikTok LIVE Studio: ${server.linkFor(kind)}',
                          style: const TextStyle(fontSize: 13, color: AppColors.accent)),
                      SelectableText('OBS: ${server.localLinkFor(kind)}',
                          style: const TextStyle(fontSize: 12, color: AppColors.textMuted)),
                      const SizedBox(height: 12),
                      if (issue != null) ...[
                        Container(
                          key: const Key('cfg-issue'),
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: AppColors.warning.withAlpha(25),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: AppColors.warning.withAlpha(120)),
                          ),
                          child: Text(issue, style: const TextStyle(fontSize: 13, color: AppColors.text)),
                        ),
                        const SizedBox(height: 12),
                      ],
                      ...fields,
                      const SizedBox(height: 12),
                      Align(
                        alignment: Alignment.centerRight,
                        child: TextButton(
                          key: const Key('cfg-close'),
                          onPressed: () => Navigator.of(context).pop(),
                          child: const Text('Готово'),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 18),
              Container(
                width: 360,
                decoration: BoxDecoration(
                  color: const Color(0xFF0B0812),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: OverlayPreview(model: buildOverlayModel(kind, inputs)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
