import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../features/chat/chat_settings.dart';
import '../../features/chat/chat_voice.dart';
import '../theme/app_colors.dart';

/// Настройки: чат TikTok в чате Minecraft и выразительная озвучка чата.
class ChatSettingsPanel extends ConsumerStatefulWidget {
  const ChatSettingsPanel({super.key});

  @override
  ConsumerState<ChatSettingsPanel> createState() => _ChatSettingsPanelState();
}

class _ChatSettingsPanelState extends ConsumerState<ChatSettingsPanel> {
  final _allow = TextEditingController();
  final _block = TextEditingController();
  bool _filled = false;

  @override
  void dispose() {
    _allow.dispose();
    _block.dispose();
    super.dispose();
  }

  void _change(ChatSettings Function(ChatSettings s) f) => ref.read(chatSettingsProvider.notifier).change(f);

  /// Несколько групп сразу. «Всех» снимает остальные; без отметок — снова «Всех».
  Widget _who(String keyPrefix, Set<ChatWho> value, ValueChanged<Set<ChatWho>> onPick) => Wrap(
        spacing: 6,
        runSpacing: 6,
        children: [
          for (final w in ChatWho.values)
            FilterChip(
              key: Key('$keyPrefix-${w.id}'),
              label: Text(w.label),
              selected: value.contains(w),
              onSelected: (on) {
                if (w == ChatWho.all) {
                  onPick({ChatWho.all});
                  return;
                }
                final next = {...value}..remove(ChatWho.all);
                on ? next.add(w) : next.remove(w);
                onPick(next.isEmpty ? {ChatWho.all} : next);
              },
            ),
        ],
      );

  @override
  Widget build(BuildContext context) {
    final s = ref.watch(chatSettingsProvider);
    final relay = ref.watch(chatRelayProvider);
    if (!_filled) {
      _allow.text = s.allow.join(', ');
      _block.text = s.block.join(', ');
      _filled = s.allow.isNotEmpty || s.block.isNotEmpty;
    }
    const muted = TextStyle(fontSize: 13, color: AppColors.textMuted);
    const label = TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.text);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SwitchRow(
          key: const Key('chat-minecraft'),
          title: const Text('Чат TikTok в чате Minecraft', style: label),
          subtitle: const Text('«[TikTok] Mira: привет» — у каждого зрителя свой цвет ника', style: muted),
          value: s.minecraft,
          onChanged: (v) => _change((s) => s.copyWith(minecraft: v)),
        ),
        if (s.minecraft) ...[
          const Text('Кого показывать в игре (можно несколько)', style: muted),
          const SizedBox(height: 6),
          _who('chat-mc-who', s.minecraftWho, (w) => _change((s) => s.copyWith(minecraftWho: w))),
        ],
        const Divider(height: 28),
        SwitchRow(
          key: const Key('chat-voice'),
          title: const Text('Озвучка чата', style: label),
          subtitle: const Text(
              'Живые нейроголоса Microsoft (нужен интернет), без интернета — голос Windows. '
              'Интонация по сообщению: «!» — бодрее, «?» — вопросом, КАПС — громче, смех — весело.',
              style: muted),
          value: s.voice,
          onChanged: (v) => _change((s) => s.copyWith(voice: v)),
        ),
        if (s.voice) ...[
          const Text('Кого озвучивать (можно несколько)', style: muted),
          const SizedBox(height: 6),
          _who('chat-voice-who', s.voiceWho, (w) => _change((s) => s.copyWith(voiceWho: w))),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            key: const Key('chat-voice-name'),
            value: s.voiceName,
            decoration: const InputDecoration(labelText: 'Голос'),
            items: [
              for (final e in chatVoices.entries) DropdownMenuItem(value: e.key, child: Text(e.value)),
            ],
            onChanged: (v) => _change((s) => s.copyWith(voiceName: v)),
          ),
          const SizedBox(height: 10),
          Text('Скорость: ${s.rate >= 0 ? '+' : ''}${s.rate}%', style: muted),
          Slider(
            key: const Key('chat-voice-rate'),
            value: s.rate.toDouble(),
            min: -50,
            max: 100,
            divisions: 30,
            onChanged: (v) => _change((s) => s.copyWith(rate: v.round())),
          ),
          Text('Громкость: ${s.volume}%', style: muted),
          Slider(
            key: const Key('chat-voice-volume'),
            value: s.volume.toDouble(),
            min: 0,
            max: 100,
            divisions: 20,
            onChanged: (v) => _change((s) => s.copyWith(volume: v.round())),
          ),
          SwitchRow(
            title: const Text('Называть ник перед сообщением', style: TextStyle(fontSize: 14, color: AppColors.text)),
            value: s.readNames,
            onChanged: (v) => _change((s) => s.copyWith(readNames: v)),
          ),
          SwitchRow(
            title: const Text('Выразительно (интонация по сообщению)',
                style: TextStyle(fontSize: 14, color: AppColors.text)),
            value: s.expressive,
            onChanged: (v) => _change((s) => s.copyWith(expressive: v)),
          ),
          SwitchRow(
            title: const Text('Не читать ссылки', style: TextStyle(fontSize: 14, color: AppColors.text)),
            value: s.skipLinks,
            onChanged: (v) => _change((s) => s.copyWith(skipLinks: v)),
          ),
          const SizedBox(height: 6),
          Text('Не озвучивать сообщения, которые ждут дольше:', style: muted),
          DropdownButton<int>(
            key: const Key('chat-max-delay'),
            value: const [0, 3, 5, 8, 15, 30, 60].contains(s.maxDelay) ? s.maxDelay : 15,
            items: const [
              DropdownMenuItem(value: 3, child: Text('3 секунды (только свежие сообщения)')),
              DropdownMenuItem(value: 5, child: Text('5 секунд')),
              DropdownMenuItem(value: 8, child: Text('8 секунд')),
              DropdownMenuItem(value: 15, child: Text('15 секунд')),
              DropdownMenuItem(value: 30, child: Text('30 секунд')),
              DropdownMenuItem(value: 60, child: Text('1 минуты')),
              DropdownMenuItem(value: 0, child: Text('Озвучивать всё, даже с задержкой')),
            ],
            onChanged: (v) {
              if (v != null) _change((s) => s.copyWith(maxDelay: v));
            },
          ),
        ],
        const SizedBox(height: 12),
        TextField(
          key: const Key('chat-allow'),
          controller: _allow,
          decoration: const InputDecoration(
            labelText: 'Всегда озвучивать и показывать (ники через запятую)',
            hintText: 'mira, alex',
          ),
          onChanged: (v) => _change((s) => s.copyWith(allow: ChatSettings.normalizeNames(v))),
        ),
        const SizedBox(height: 10),
        TextField(
          key: const Key('chat-block'),
          controller: _block,
          decoration: const InputDecoration(
            labelText: 'Никогда не озвучивать и не показывать (ники через запятую)',
            hintText: 'spam_bot',
          ),
          onChanged: (v) => _change((s) => s.copyWith(block: ChatSettings.normalizeNames(v))),
        ),
        const SizedBox(height: 12),
        Wrap(
          spacing: 12,
          runSpacing: 8,
          crossAxisAlignment: WrapCrossAlignment.center,
          children: [
            FilledButton.icon(
              key: const Key('chat-test'),
              onPressed: () => ref.read(chatRelayProvider.notifier).test(),
              icon: const Icon(Icons.record_voice_over_rounded, size: 18),
              label: const Text('Проверить'),
            ),
            if (relay.engine != null)
              Text('Голос: ${relay.engine}',
                  key: const Key('chat-engine'),
                  style: TextStyle(
                      fontSize: 13,
                      color: relay.engine!.startsWith('нейроголос ') ? AppColors.success : AppColors.warning)),
            Text(
              relay.lastSpoken == null
                  ? 'Озвучено: ${relay.spoken}'
                  : 'Озвучено: ${relay.spoken} · в очереди: ${relay.queued} · последнее: «${relay.lastSpoken}»',
              style: muted,
            ),
          ],
        ),
      ],
    );
  }
}

/// Строка «текст + переключатель» (без ListTile: тот не рисуется на цветном фоне).
class SwitchRow extends StatelessWidget {
  const SwitchRow({super.key, required this.title, this.subtitle, required this.value, required this.onChanged});

  final Widget title;
  final Widget? subtitle;
  final bool value;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [title, if (subtitle != null) ...[const SizedBox(height: 2), subtitle!]],
              ),
            ),
            const SizedBox(width: 12),
            Switch(value: value, onChanged: onChanged),
          ],
        ),
      );
}
