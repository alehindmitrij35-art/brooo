package dev.dirronlive.sky.core;

import java.util.ArrayList;
import java.util.List;

/**
 * Один заезд по трассе: отсчёт, полёт, кольца, сектора, ошибки, пауза,
 * финиш. Только логика — телепорт, скорость и надписи делает игра по
 * событиям, которые возвращает {@link #tick}.
 *
 * <p>Кольца идут строго по порядку и засчитываются один раз: номер
 * следующего кольца только растёт. Пролёт мимо ожидаемого кольца сразу в
 * следующее засчитывает следующее, а пропущенное — как промах (чтобы игрок
 * не застрял, если чуть задел край).
 */
public final class SkyRun {
    public enum Phase { IDLE, COUNTDOWN, RUNNING, PAUSED, RESUMING, FINISHED }

    public enum EventType { COUNTDOWN, LAUNCH, RING, BOOST, MISS, SHIELD, WRONG_WAY, SECTOR, FINISH, RETURN, PAUSE, RESUME }

    /** {@code value}: секунда отсчёта, номер кольца или сектора (с 0); {@code reason} — причина возврата. */
    public record Event(EventType type, int value, String reason) {}

    /** Состояние игрока в тике. Точки — центр тела. */
    public record Sample(V3 from, V3 to, boolean teleported, boolean onGround, boolean crashed) {}

    public static final int COUNTDOWN_TICKS = 60;
    /** Длиннее этого за тик — не полёт, а телепорт: кольца не проверяем. */
    public static final double MAX_STEP = 12;

    public final Track track;
    private Phase phase = Phase.IDLE;
    private Phase pausedFrom = Phase.IDLE;
    private int next;
    private int sector;
    private int countdown;
    private int protection;
    private long ticks;
    private int misses;
    private int crashes;
    private long bestTicks;
    private double ringScale = 1;
    private boolean shield;
    private final boolean[] passed;
    private final boolean[] missed;

    public SkyRun(Track track) {
        this.track = track;
        this.passed = new boolean[track.ringCount()];
        this.missed = new boolean[track.ringCount()];
    }

    // ------------------------------------------------------------ команды

    /** Старт (и быстрый рестарт): всё с нуля, отсчёт 3 секунды на первой контрольной точке. */
    public List<Event> start() {
        next = 0;
        sector = 0;
        ticks = 0;
        misses = 0;
        crashes = 0;
        protection = 0;
        java.util.Arrays.fill(passed, false);
        java.util.Arrays.fill(missed, false);
        ringScale = 1;
        shield = false;
        phase = Phase.COUNTDOWN;
        countdown = COUNTDOWN_TICKS;
        return List.of(new Event(EventType.COUNTDOWN, 3, ""));
    }

    public boolean pause() {
        if (phase != Phase.RUNNING && phase != Phase.COUNTDOWN && phase != Phase.RESUMING) return false;
        pausedFrom = phase == Phase.RESUMING ? Phase.RUNNING : phase;
        phase = Phase.PAUSED;
        return true;
    }

    /** Продолжить после паузы: снова отсчёт 3 секунды. */
    public List<Event> resume() {
        if (phase != Phase.PAUSED) return List.of();
        countdown = COUNTDOWN_TICKS;
        phase = pausedFrom == Phase.COUNTDOWN ? Phase.COUNTDOWN : Phase.RESUMING;
        return List.of(new Event(EventType.COUNTDOWN, 3, ""));
    }

    /** Закончить заезд без результата. */
    public void stop() {
        phase = Phase.IDLE;
        protection = 0;
    }

    /** Вернуться на контрольную точку вручную (без штрафа). */
    public List<Event> toCheckpoint() {
        if (phase != Phase.RUNNING) return List.of();
        protection = track.protectionTicks;
        return List.of(new Event(EventType.RETURN, sector, "manual"));
    }

    // ---------------------------------------------------------------- тик

    public List<Event> tick(Sample s) {
        switch (phase) {
            case COUNTDOWN, RESUMING -> {
                countdown--;
                if (countdown > 0 && countdown % 20 == 0) return List.of(new Event(EventType.COUNTDOWN, countdown / 20, ""));
                if (countdown > 0) return List.of();
                boolean resume = phase == Phase.RESUMING;
                phase = Phase.RUNNING;
                protection = track.protectionTicks;
                return List.of(new Event(resume ? EventType.RESUME : EventType.LAUNCH, sector, ""));
            }
            case RUNNING -> {
                return running(s);
            }
            default -> {
                return List.of();
            }
        }
    }

    private List<Event> running(Sample s) {
        ticks++;
        if (protection > 0) protection--;
        List<Event> out = null;
        boolean step = !s.teleported() && s.from() != null && s.to() != null && s.from().distance(s.to()) <= MAX_STEP;
        if (step && next < track.ringCount()) {
            Ring want = track.rings.get(next);
            RingCheck.Result r = RingCheck.cross(s.from(), s.to(), want, ringScale);
            Ring after = next + 1 < track.ringCount() ? track.rings.get(next + 1) : null;
            if (r == RingCheck.Result.NONE && after != null
                    && RingCheck.cross(s.from(), s.to(), after, ringScale) == RingCheck.Result.HIT) {
                out = add(out, miss(want));
                out = advance(out, want);
                out = pass(out, after);
            } else if (r == RingCheck.Result.HIT) {
                out = pass(out, want);
            } else if (r == RingCheck.Result.MISS) {
                if (track.onMiss == Track.OnMiss.CHECKPOINT) {
                    if (shield) {
                        shield = false;
                        out = add(out, new Event(EventType.SHIELD, want.order(), "miss"));
                        out = advance(out, want);
                    } else {
                        misses++;
                        missed[want.order()] = true;
                        protection = track.protectionTicks;
                        return List.of(new Event(EventType.MISS, want.order(), ""), new Event(EventType.RETURN, sector, "miss"));
                    }
                } else {
                    out = add(out, miss(want));
                    out = advance(out, want);
                }
            } else if (r == RingCheck.Result.BACKWARD) {
                out = add(out, new Event(EventType.WRONG_WAY, want.order(), ""));
            }
        }
        if (phase != Phase.RUNNING) return out == null ? List.of() : out;
        String reason = null;
        if (s.to() != null && s.to().y() < track.minY) reason = "void";
        else if (s.to() != null && !track.inside(s.to())) reason = "bounds";
        else if (protection == 0 && s.crashed()) reason = "crash";
        else if (protection == 0 && s.onGround()) reason = "ground";
        if (reason != null) {
            boolean penalty = protection == 0;
            if (penalty && shield) {
                shield = false;
                penalty = false;
                out = add(out, new Event(EventType.SHIELD, sector, reason));
            }
            if (penalty) crashes++;
            protection = track.protectionTicks;
            out = add(out, new Event(EventType.RETURN, sector, reason));
        }
        return out == null ? List.of() : out;
    }

    private Event miss(Ring ring) {
        missed[ring.order()] = true;
        if (shield) {
            shield = false;
            return new Event(EventType.SHIELD, ring.order(), "miss");
        }
        misses++;
        return new Event(EventType.MISS, ring.order(), "");
    }

    /** Штраф извне (мимо ворот слалома): ошибка или щит ангела. */
    public Event penalty(String reason) {
        if (shield) {
            shield = false;
            return new Event(EventType.SHIELD, -1, reason);
        }
        misses++;
        return new Event(EventType.MISS, -1, reason);
    }

    public void setRingScale(double scale) {
        ringScale = scale;
    }

    public double ringScale() {
        return ringScale;
    }

    public void setShield(boolean on) {
        shield = on;
    }

    public boolean shield() {
        return shield;
    }

    private List<Event> pass(List<Event> out, Ring ring) {
        passed[ring.order()] = true;
        out = add(out, new Event(ring.isBoost() ? EventType.BOOST : EventType.RING, ring.order(), ""));
        return advance(out, ring);
    }

    /** Кольцо позади (пройдено или пропущено): дальше следующее, конец сектора, финиш. */
    private List<Event> advance(List<Event> out, Ring ring) {
        next = ring.order() + 1;
        if (track.isLastInSector(ring)) {
            if (next >= track.ringCount()) {
                phase = Phase.FINISHED;
                protection = 0;
                if (bestTicks == 0 || ticks < bestTicks) bestTicks = ticks;
                return add(out, new Event(EventType.FINISH, ring.sector(), ""));
            }
            sector = ring.sector() + 1;
            out = add(out, new Event(EventType.SECTOR, sector, ""));
        }
        return out;
    }

    private static List<Event> add(List<Event> out, Event e) {
        if (out == null) out = new ArrayList<>(3);
        out.add(e);
        return out;
    }

    // -------------------------------------------------------------- данные

    public Phase phase() {
        return phase;
    }

    public boolean active() {
        return phase != Phase.IDLE && phase != Phase.FINISHED;
    }

    public int sector() {
        return sector;
    }

    /** Номер следующего кольца по всей трассе (с 0). */
    public int nextRing() {
        return next;
    }

    /** Пройдено (или пропущено) колец в текущем секторе. */
    public int ringInSector() {
        if (phase == Phase.FINISHED) return track.sectors.get(track.sectors.size() - 1).rings().size();
        return next - track.sectors.get(sector).first();
    }

    public int ringsInSector() {
        return track.sectors.get(Math.min(sector, track.sectors.size() - 1)).rings().size();
    }

    public long ticks() {
        return ticks;
    }

    public int misses() {
        return misses;
    }

    public int crashes() {
        return crashes;
    }

    public int errors() {
        return misses + crashes;
    }

    public int protection() {
        return protection;
    }

    public long bestTicks() {
        return bestTicks;
    }

    public void setBestTicks(long best) {
        bestTicks = best;
    }

    public boolean passed(int order) {
        return passed[order];
    }

    public boolean missed(int order) {
        return missed[order];
    }

    public Checkpoint checkpoint() {
        return track.sectors.get(Math.min(sector, track.sectors.size() - 1)).checkpoint();
    }

    public int countdownSeconds() {
        return (phase == Phase.COUNTDOWN || phase == Phase.RESUMING) ? (countdown + 19) / 20 : 0;
    }
}
