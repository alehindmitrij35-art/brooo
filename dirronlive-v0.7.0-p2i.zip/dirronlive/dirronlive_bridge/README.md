# Dirronlive Bridge 2.1.0

Мод для Minecraft Java 1.21.1 (Fabric). Связывает игру с программой
Dirronlive и содержит карту «Dirron Parkour: 100 комнат»:

- подарки из программы появляются над панелью быстрого доступа;
- 23 действия за подарки выполняются на карте (комнаты, эффекты, толчки,
  мост, срезка, щит…), результат уходит в Dirronlive («Комната 12 → 11»);
- карта следит за падениями, чекпоинтами, финишем комнат и победой.

Требования: Minecraft 1.21.1, Fabric Loader 0.16+, Java 21. Fabric API не
обязателен: нужные модули уже внутри jar.

Установка: `DirronliveBridge-2.1.0.jar` в папку `mods`, папку мира
`DirronParkour` (из `DirronParkour-world.zip`) — в папку `saves`.

Команды: `/parkour room <1–100>`, `/parkour stats`, `/parkour reset`,
`/parkour action <id> [направление]`, `/parkour build` (построить карту в
своём мире).

Сборка:

- `gradlew.bat build` или `build-mod.bat` — мод в `build\libs`;
- `gradlew.bat runGametest` — проверки карты в настоящем Minecraft
  (строки `PARKOUR_CHECK ok|fail` в журнале);
- `gradlew.bat worldZip` — готовый мир в `build\installer\DirronParkour-world.zip`.

Мод подключается к `ws://127.0.0.1:8765/dirronlive` и переподключается
каждые 2 секунды. Порт можно поменять: `-Ddirronlive.port=…`.
Подробности — в README.md программы.
