import 'dart:io';

import 'package:dirronlive/ui/widgets/app_logo.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'support/memory_store.dart';
import 'support/test_app.dart';

void main() {
  test('значок для верхней строки — PNG', () {
    final bytes = File(AppLogo.assetPath).readAsBytesSync();
    expect(bytes.sublist(0, 4), [0x89, 0x50, 0x4E, 0x47]);
  });

  test('иконка Windows — настоящий ICO с размером 256×256', () {
    final bytes = File('assets/icon/app_icon.ico').readAsBytesSync();
    expect(bytes.sublist(0, 4), [0, 0, 1, 0]); // заголовок ICO
    final count = bytes[4] | (bytes[5] << 8);
    expect(count, greaterThanOrEqualTo(4));
    // В ICO ширина 256 записывается как 0.
    final widths = [for (var i = 0; i < count; i++) bytes[6 + i * 16]];
    expect(widths, containsAll([16, 32, 48, 0]));
  });

  testWidgets('значок и название слева в верхней строке', (tester) async {
    final container = await pumpDirronlive(tester, MemoryJsonStore());
    final logo = tester.getRect(find.byKey(AppLogo.logoKey));
    final title = tester.getRect(find.text('Dirronlive'));
    final firstTab = tester.getRect(find.byKey(const Key('nav-live')));
    final settings = tester.getRect(find.byKey(const Key('nav-settings')));

    expect(logo.right, lessThan(title.left));
    expect(title.right, lessThan(firstTab.left));
    expect(logo.top, lessThan(64));
    expect(settings.right, greaterThan(1800)); // «Настройки» справа
    // Вкладки примерно по центру окна.
    final tabsCenter = (firstTab.left +
            tester.getRect(find.byKey(const Key('nav-history'))).right) /
        2;
    expect((tabsCenter - 960).abs(), lessThan(40));
    expect(tester.takeException(), isNull);

    await closeDirronlive(tester, container);
  });
}
