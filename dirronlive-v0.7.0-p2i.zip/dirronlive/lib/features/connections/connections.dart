/// Состояние подключения к внешней системе.
enum ConnectionStatus {
  disconnected('Не подключено'),
  connecting('Подключение…'),
  connected('Подключено'),
  error('Ошибка подключения');

  const ConnectionStatus(this.label);

  final String label;
}

const minecraftTargetVersion = 'Java 1.21.1 · Fabric';
const minecraftWorldType = 'Одиночный мир';
