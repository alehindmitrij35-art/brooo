import '../../core/events/gift_event.dart';
import '../../core/storage/json_store.dart';
import '../../core/storage/storage_exception.dart';

class HistoryLoadResult {
  const HistoryLoadResult(this.events, this.warnings);

  /// События, новые сверху.
  final List<GiftEvent> events;
  final List<String> warnings;
}

/// Чтение и запись `history.json`. События хранятся новыми сверху.
class EventHistoryRepository {
  EventHistoryRepository(this.store);

  static const fileName = 'history.json';
  static const formatVersion = 1;

  final JsonStore store;

  Future<HistoryLoadResult> load() async {
    Map<String, Object?>? json;
    try {
      json = await store.read(fileName);
    } on StorageException catch (e) {
      return HistoryLoadResult(
          const [], ['История событий не загружена. ${e.message}']);
    } on FormatException {
      return HistoryLoadResult(const [], [await _brokenFileMessage()]);
    }
    if (json == null) return const HistoryLoadResult([], []);

    final rawEvents = json['events'];
    if (rawEvents is! List) {
      return HistoryLoadResult(const [], [await _brokenFileMessage()]);
    }

    final events = <GiftEvent>[];
    final seenIds = <String>{};
    var skipped = 0;
    for (final item in rawEvents) {
      try {
        final event = GiftEvent.fromJson(item);
        if (seenIds.add(event.id)) {
          events.add(event);
        }
      } on FormatException {
        skipped++;
      }
    }

    return HistoryLoadResult(List.unmodifiable(events), [
      if (skipped > 0) 'В истории пропущено повреждённых записей: $skipped.',
    ]);
  }

  Future<void> save(List<GiftEvent> eventsNewestFirst) =>
      store.write(fileName, {
        'version': formatVersion,
        'events': [for (final event in eventsNewestFirst) event.toJson()],
      });

  Future<String> _brokenFileMessage() async {
    final backup = await store.quarantine(fileName);
    final saved =
        backup == null ? '' : ' Копия старого файла сохранена как «$backup».';
    return 'Файл истории событий повреждён и не может быть прочитан.$saved '
        'Начата новая история.';
  }
}
